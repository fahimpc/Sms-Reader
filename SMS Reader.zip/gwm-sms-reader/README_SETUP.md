# GWM SMS Reader — Complete Setup Guide

A production-ready private SMS payment reader application for **bKash**, **Nagad**, and **Rocket** that parses incoming payment SMS messages and atomically syncs verified transactions to Firebase Realtime Database at `XNXANIKPAY/<TRX_ID>`.

---

## 20-Step Deployment & Verification Checklist

1. **Open project:**
   Open this root directory or the exported ZIP directly in Android Studio Ladybug or newer.

2. **Put google-services.json in `app/`:**
   Copy your production `google-services.json` (for package `gwm.topup`, project `topupbd-9f02e`) into `app/google-services.json`.

3. **Enable Firebase Anonymous Authentication:**
   In Firebase Console -> Build -> **Authentication** -> **Sign-in method** -> Enable **Anonymous**.

4. **Confirm Realtime Database:**
   Confirm Realtime Database is created at:
   `https://topupbd-9f02e-default-rtdb.firebaseio.com`

5. **Configure paymentSettings in Firebase:**
   In your Realtime Database console, add initial nodes:
   ```json
   {
     "paymentSettings": {
       "bkash": {
         "number": "017XXXXXXXX",
         "enabled": true
       },
       "nagad": {
         "number": "018XXXXXXXX",
         "enabled": true
       },
       "rocket": {
         "number": "019XXXXXXXX",
         "enabled": true
       }
     }
   }
   ```

6. **Configure / Merge Firebase Security Rules:**
   Review `firebase_rules_example.json` and merge it into your Firebase Realtime Database rules. It allows authenticated readers to create absent transactions (`!data.exists()`) while allowing website server / admin to update `used = true`.

7. **Change PIN:**
   Open `app/src/main/java/gwm/topup/AppConfig.java` to view or change `DEFAULT_PIN` (currently set to `"1212"`).

8. **Build APK:**
   Run `./gradlew assembleRelease` or `./gradlew assembleDebug` in Android Studio.

9. **Install:**
   Install the APK on the dedicated Android device with SIM card receiving payments.

10. **Allow SMS permission:**
    When prompted, grant the `RECEIVE_SMS` permission.

11. **Allow notification permission:**
    On Android 13+, grant notification permission for the persistent status bar service.

12. **Check Reader UID:**
    Open the app, enter your PIN, and check that a unique Firebase Anonymous Auth UID appears under **Reader UID**. Tap to copy it.

13. **Test Firebase:**
    Tap the **[ TEST FIREBASE CONNECTION ]** button. You should see `Firebase: CONNECTED` and the authenticated UID.

14. **Send / Test bKash payment:**
    Send a test payment to the SIM or test with sample SMS:
    `You have received Tk 510.00 from 01737078264. Ref 22222. Fee Tk 0.00. Balance Tk 2,989.12. TrxID DJ118THL8D at 01/10/2026 18:42`

15. **Check `XNXANIKPAY/<TrxID>` in Firebase Console:**
    Confirm that `XNXANIKPAY/DJ118THL8D` was created with:
    - `type: "B"`
    - `provider: "bKash"`
    - `amount: "510.00"`
    - `agent: "01737078264"`
    - `txid: "DJ118THL8D"`
    - `used: false`
    - `receivedAt: <timestamp>`

16. **Test Nagad:**
    Verify both Format 1 (Cash In) and Format 2 (Money Received). Check Firebase node `XNXANIKPAY/<TxnID>`.

17. **Test Rocket:**
    Verify both P2P payment and Cash-Out formats. Check Firebase node `XNXANIKPAY/<TxnId>`.

18. **Verify duplicate protection:**
    Re-receive the exact same SMS or tap **[ ADD / RETRY TO FIREBASE ]**.
    Verify that the app reports **"Already saved"** and does NOT overwrite existing database fields (especially `used`, `usedBy`).

19. **Verify Admin number real-time update:**
    From your website Admin panel or Firebase Console, change `paymentSettings/bkash/number` or set `enabled: false`.
    Verify that the Android app updates in real time without restarting the APK.

20. **Retire old SMS reader apps:**
    Only after completing and validating all of the above tests, uninstall the legacy SMS reader apps.

---

## Architecture Summary
- **Language:** Java only
- **UI:** XML Layouts with ViewBinding
- **Package ID:** `gwm.topup`
- **Branding:** Primary pink `#EB4899`, dark modern console layout
- **Provider Logos:** 1:1 aspect ratio square assets for bKash, Nagad, and Rocket
- **Duplicate Protection:** Firebase atomic `runTransaction` with `Transaction.abort()` on existing nodes
- **Background Execution:** `BroadcastReceiver` for `SMS_RECEIVED` and `BOOT_COMPLETED` with persistent status notification
