<?php
/**
 * Connection Test Endpoint
 * Endpoint: POST /connection_test.php
 */

declare(strict_types=1);

require_once __DIR__ . '/db_config.php';

$input = getJsonInput();
$deviceId = trim($input['device_id'] ?? '');
$deviceSecret = trim($input['device_secret'] ?? '');

if (empty($deviceId) || empty($deviceSecret)) {
    sendJsonResponse(false, 'MISSING_FIELDS', 'device_id and device_secret are required', [], 400);
}

if (!authenticateDevice($deviceId, $deviceSecret)) {
    sendJsonResponse(false, 'AUTH_FAILED', 'Invalid device_id or device_secret', [], 401);
}

// Ensure device record exists in database
try {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("INSERT INTO devices (device_id, device_name, status)
                           VALUES (:device_id, 'Android SMS Reader', 'ACTIVE')
                           ON DUPLICATE KEY UPDATE last_active_at = NOW()");
    $stmt->execute(['device_id' => $deviceId]);
} catch (Exception $e) {
    // Non-critical logging
}

sendJsonResponse(true, 'OK', 'Connection test successful! PHP API is active.', [
    'device_id' => $deviceId,
    'backend'   => 'PHP MySQL API Mode'
]);
