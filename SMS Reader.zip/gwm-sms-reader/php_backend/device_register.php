<?php
/**
 * Device Registration & Pairing Endpoint
 * Endpoint: POST /device_register.php
 */

declare(strict_types=1);

require_once __DIR__ . '/db_config.php';

$input = getJsonInput();
$deviceId = trim($input['device_id'] ?? '');
$deviceName = trim($input['device_name'] ?? 'Android Reader Device');
$masterSecret = trim($input['master_secret'] ?? '');

if (empty($deviceId)) {
    sendJsonResponse(false, 'MISSING_DEVICE_ID', 'device_id is required', [], 400);
}

if (!empty(MASTER_DEVICE_SECRET) && $masterSecret !== MASTER_DEVICE_SECRET) {
    sendJsonResponse(false, 'INVALID_MASTER_SECRET', 'Master secret key verification failed', [], 401);
}

try {
    $pdo = getDbConnection();

    // Generate device secret
    $generatedSecret = 'gwm_sec_' . bin2hex(random_bytes(16));
    $hash = password_hash($generatedSecret, PASSWORD_BCRYPT);

    $pdo->beginTransaction();

    $stmt1 = $pdo->prepare("INSERT INTO devices (device_id, device_name, status)
                            VALUES (:device_id, :device_name, 'ACTIVE')
                            ON DUPLICATE KEY UPDATE device_name = :device_name, last_active_at = NOW()");
    $stmt1->execute(['device_id' => $deviceId, 'device_name' => $deviceName]);

    $stmt2 = $pdo->prepare("INSERT INTO device_credentials (device_id, device_secret_hash, is_revoked)
                            VALUES (:device_id, :hash, 0)
                            ON DUPLICATE KEY UPDATE device_secret_hash = :hash, is_revoked = 0, token_issued_at = NOW()");
    $stmt2->execute(['device_id' => $deviceId, 'hash' => $hash]);

    $pdo->commit();

    sendJsonResponse(true, 'OK', 'Device paired and registered successfully', [
        'device_id'     => $deviceId,
        'device_secret' => $generatedSecret
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    sendJsonResponse(false, 'SERVER_ERROR', $e->getMessage(), [], 500);
}
