<?php
/**
 * Database Configuration & PDO Helper
 * GWM SMS Reader PHP Backend
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=UTF-8');

// Database credentials for cPanel / MySQL Server
define('DB_HOST', 'localhost');
define('DB_NAME', 'gwm_sms_reader_db');
define('DB_USER', 'gwm_db_user');
define('DB_PASS', 'YourStrongDbPassword123!');
define('DB_CHARSET', 'utf8mb4');

// Default Device Pairing Secret (Change this or issue per-device keys)
define('MASTER_DEVICE_SECRET', 'GWM_READER_SECRET_KEY_2025');

/**
 * Get PDO Database Connection Instance
 */
function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf("mysql:host=%s;dbname=%s;charset=%s", DB_HOST, DB_NAME, DB_CHARSET);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            sendJsonResponse(false, 'DATABASE_ERROR', 'Database connection failed: ' . $e->getMessage(), [], 500);
            exit;
        }
    }
    return $pdo;
}

/**
 * Standard JSON Response Sender
 */
function sendJsonResponse(bool $success, string $errorCode, string $message, array $data = [], int $httpCode = 200): void {
    http_response_code($httpCode);
    $response = array_merge([
        'success'    => $success,
        'error_code' => $errorCode,
        'message'    => $message,
        'timestamp'  => time()
    ], $data);
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Reads JSON payload from input stream
 */
function getJsonInput(): array {
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return [];
    }

    // The Android app wraps the real payload as {"b64": "<base64 of JSON>"}.
    // Accept both the wrapped and the plain format.
    if (isset($decoded['b64']) && is_string($decoded['b64'])) {
        $inner = base64_decode($decoded['b64'], true);
        $innerDecoded = ($inner !== false) ? json_decode($inner, true) : null;
        if (is_array($innerDecoded)) {
            return $innerDecoded;
        }
    }
    return $decoded;
}

/**
 * Validates Device Authentication Secret
 */
function authenticateDevice(string $deviceId, string $deviceSecret): bool {
    if (empty($deviceId) || empty($deviceSecret)) {
        return false;
    }

    // Check master key
    if ($deviceSecret === MASTER_DEVICE_SECRET) {
        return true;
    }

    // Check database device_credentials
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("SELECT device_secret_hash, is_revoked FROM device_credentials WHERE device_id = :device_id LIMIT 1");
        $stmt->execute(['device_id' => $deviceId]);
        $row = $stmt->fetch();

        if ($row && intval($row['is_revoked']) === 0) {
            return password_verify($deviceSecret, $row['device_secret_hash']);
        }
    } catch (Exception $e) {
        // Fallback check
    }

    return false;
}
