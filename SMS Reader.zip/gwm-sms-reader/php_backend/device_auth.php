<?php
/**
 * Device Authentication Verification Endpoint
 * Endpoint: POST /device_auth.php
 */

declare(strict_types=1);

require_once __DIR__ . '/db_config.php';

$input = getJsonInput();
$deviceId = trim($input['device_id'] ?? '');
$deviceSecret = trim($input['device_secret'] ?? '');

if (empty($deviceId) || empty($deviceSecret)) {
    sendJsonResponse(false, 'MISSING_FIELDS', 'device_id and device_secret are required', [], 400);
}

if (authenticateDevice($deviceId, $deviceSecret)) {
    sendJsonResponse(true, 'AUTHENTICATED', 'Device authentication valid', [
        'device_id' => $deviceId,
        'status'    => 'ACTIVE'
    ]);
} else {
    sendJsonResponse(false, 'AUTH_FAILED', 'Device authentication failed or revoked', [], 401);
}
