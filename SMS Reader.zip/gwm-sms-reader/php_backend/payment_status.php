<?php
/**
 * Payment Status & Settlement Verification Endpoint for Website Integration
 * Endpoint: GET or POST /payment_status.php
 */

declare(strict_types=1);

require_once __DIR__ . '/db_config.php';

$input = getJsonInput();
$txid = strtoupper(trim($_REQUEST['txid'] ?? $input['txid'] ?? ''));
$providerCode = strtolower(trim($_REQUEST['provider_code'] ?? $input['provider_code'] ?? ''));

if (empty($txid)) {
    sendJsonResponse(false, 'MISSING_TXID', 'Transaction ID (txid) is required', [], 400);
}

try {
    $pdo = getDbConnection();

    $query = "SELECT id, provider, provider_code, txid, amount, status, used_by, used_at, received_at
              FROM payment_transactions
              WHERE txid = :txid";
    $params = ['txid' => $txid];

    if (!empty($providerCode)) {
        $query .= " AND provider_code = :provider_code";
        $params['provider_code'] = $providerCode;
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $transaction = $stmt->fetch();

    if (!$transaction) {
        sendJsonResponse(false, 'NOT_FOUND', 'Transaction ID not found in database', ['txid' => $txid], 404);
    }

    sendJsonResponse(true, 'OK', 'Transaction details retrieved', [
        'transaction' => $transaction
    ]);

} catch (Exception $e) {
    sendJsonResponse(false, 'SERVER_ERROR', $e->getMessage(), [], 500);
}
