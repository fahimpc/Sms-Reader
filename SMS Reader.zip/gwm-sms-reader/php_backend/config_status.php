<?php
/**
 * Configuration & Server Status Endpoint
 * Endpoint: GET /config_status.php
 */

declare(strict_types=1);

require_once __DIR__ . '/db_config.php';

sendJsonResponse(true, 'OK', 'GWM SMS Reader PHP Backend API is online', [
    'app_name'    => 'GWM SMS Reader PHP MySQL API',
    'version'     => '1.0.0',
    'php_version' => PHP_VERSION,
    'server_time' => date('Y-m-d H:i:s P')
]);
