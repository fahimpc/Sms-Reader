<?php
/**
 * Payment SMS Receiver Endpoint
 * Endpoint: POST /payment_receiver.php
 *
 * Implements strict deduplication, atomic MySQL transactions,
 * and double-settlement protection.
 */

declare(strict_types=1);

require_once __DIR__ . '/db_config.php';

$input = getJsonInput();

$deviceId       = trim($input['device_id'] ?? '');
$deviceSecret   = trim($input['device_secret'] ?? '');
$provider       = trim($input['provider'] ?? '');
$providerCode   = strtolower(trim($input['provider_code'] ?? ''));
$sender         = trim($input['sender'] ?? '');
$amount         = floatval($input['amount'] ?? 0);
$txid           = strtoupper(trim($input['txid'] ?? ''));
$receivedAccount= trim($input['received_account'] ?? '');
$rawSms         = trim($input['raw_sms'] ?? '');
$clientEventId  = trim($input['client_event_id'] ?? '');

if (empty($providerCode)) {
    $providerCode = strtolower($provider);
}

// 1. Authenticate Request
if (empty($deviceId) || empty($deviceSecret)) {
    sendJsonResponse(false, 'MISSING_AUTH', 'device_id and device_secret are required', [], 400);
}

if (!authenticateDevice($deviceId, $deviceSecret)) {
    sendJsonResponse(false, 'AUTH_FAILED', 'Invalid device credentials', [], 401);
}

// 2. Validate Payment Payload
if (empty($txid) || $amount <= 0 || empty($providerCode)) {
    sendJsonResponse(false, 'INVALID_PAYLOAD', 'Invalid payment data (txid, amount, provider_code required)', [], 400);
}

$pdo = getDbConnection();

// 3. Idempotency & Duplicate Check
try {
    $pdo->beginTransaction();

    // Check if provider + txid already exists in payment_transactions
    $checkStmt = $pdo->prepare("SELECT id, status, amount FROM payment_transactions WHERE provider_code = :provider_code AND txid = :txid LIMIT 1 FOR UPDATE");
    $checkStmt->execute([
        'provider_code' => $providerCode,
        'txid'          => $txid
    ]);
    $existing = $checkStmt->fetch();

    if ($existing) {
        $pdo->commit();
        sendJsonResponse(true, 'ALREADY_EXISTS', 'Transaction already exists in database', [
            'txid'           => $txid,
            'provider'       => $provider,
            'already_exists' => true,
            'status'         => $existing['status']
        ]);
    }

    // Insert into sms_payment_events log
    $eventStmt = $pdo->prepare("INSERT INTO sms_payment_events (client_event_id, device_id, provider, provider_code, sender, amount, txid, received_account, raw_sms)
                                VALUES (:client_event_id, :device_id, :provider, :provider_code, :sender, :amount, :txid, :received_account, :raw_sms)
                                ON DUPLICATE KEY UPDATE id=id");
    $eventStmt->execute([
        'client_event_id'  => !empty($clientEventId) ? $clientEventId : 'evt_' . time() . '_' . $txid,
        'device_id'        => $deviceId,
        'provider'         => $provider,
        'provider_code'    => $providerCode,
        'sender'           => $sender,
        'amount'           => $amount,
        'txid'             => $txid,
        'received_account' => $receivedAccount,
        'raw_sms'          => $rawSms
    ]);

    // Insert authoritative record into payment_transactions
    $txStmt = $pdo->prepare("INSERT INTO payment_transactions (provider, provider_code, txid, amount, sender_number, received_account, device_id, status)
                             VALUES (:provider, :provider_code, :txid, :amount, :sender_number, :received_account, :device_id, 'PENDING')");
    $txStmt->execute([
        'provider'         => $provider,
        'provider_code'    => $providerCode,
        'txid'             => $txid,
        'amount'           => $amount,
        'sender_number'    => $sender,
        'received_account' => $receivedAccount,
        'device_id'        => $deviceId
    ]);

    // Log action
    $logStmt = $pdo->prepare("INSERT INTO payment_processing_logs (txid, provider, action, message, ip_address)
                              VALUES (:txid, :provider, 'RECEIVED', 'Parsed SMS payment uploaded by Android Reader', :ip)");
    $logStmt->execute([
        'txid'     => $txid,
        'provider' => $provider,
        'ip'       => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
    ]);

    $pdo->commit();

    sendJsonResponse(true, 'OK', 'Payment transaction successfully recorded in MySQL', [
        'txid'           => $txid,
        'provider'       => $provider,
        'amount'         => $amount,
        'already_exists' => false
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    sendJsonResponse(false, 'SERVER_ERROR', 'Database error: ' . $e->getMessage(), [], 500);
}
