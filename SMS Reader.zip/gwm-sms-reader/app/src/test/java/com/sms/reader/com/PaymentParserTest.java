package com.sms.reader.com;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit tests for PaymentParser covering all real sample formats and negative test cases.
 */
public class PaymentParserTest {

    @Test
    public void testBkashWithRef() {
        String sms = "You have received Tk 510.00 from 01737078264. Ref 22222. Fee Tk 0.00. Balance Tk 2,989.12. TrxID DJ118THL8D at 01/10/2026 18:42";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());

        assertNotNull("bKash payment data must not be null", data);
        assertEquals(Provider.BKASH, data.getProvider());
        assertEquals("B", data.getTypeCode());
        assertEquals("510.00", data.getAmount());
        assertEquals("01737078264", data.getAgent());
        assertEquals("DJ118THL8D", data.getTxid());
    }

    @Test
    public void testBkashWithoutRef() {
        String sms = "You have received Tk 1,233.00 from 01601172005. Fee Tk 0.00. Balance Tk 4,227.12. TrxID DJ36C8YE58 at 03/10/2026 12:14";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());

        assertNotNull("bKash payment data without ref must not be null", data);
        assertEquals(Provider.BKASH, data.getProvider());
        assertEquals("B", data.getTypeCode());
        assertEquals("1233.00", data.getAmount());
        assertEquals("01601172005", data.getAgent());
        assertEquals("DJ36C8YE58", data.getTxid());
    }

    @Test
    public void testNagadFormat1CashIn() {
        String sms = "Cash In Received.\n" +
                "Amount: Tk 1287.00\n" +
                "Uddokta: 01402378800\n" +
                "TxnID: 75KDFBXJ\n" +
                "Balance: 1304.01\n" +
                "24/06/2026 20:52";
        PaymentData data = PaymentParser.parse("16167", sms, System.currentTimeMillis());

        assertNotNull("Nagad format 1 must not be null", data);
        assertEquals(Provider.NAGAD, data.getProvider());
        assertEquals("N", data.getTypeCode());
        assertEquals("1287.00", data.getAmount());
        assertEquals("01402378800", data.getAgent());
        assertEquals("75KDFBXJ", data.getTxid());
    }

    @Test
    public void testNagadFormat2MoneyReceived() {
        String sms = "Money Received.\n" +
                "Amount: Tk 1318.00\n" +
                "Sender: 01714929542\n" +
                "Ref: N/A\n" +
                "TxnID: 75KUWMLH\n" +
                "Balance: Tk 2422.01\n" +
                "27/06/2026 14:03";
        PaymentData data = PaymentParser.parse("Nagad", sms, System.currentTimeMillis());

        assertNotNull("Nagad format 2 must not be null", data);
        assertEquals(Provider.NAGAD, data.getProvider());
        assertEquals("N", data.getTypeCode());
        assertEquals("1318.00", data.getAmount());
        assertEquals("01714929542", data.getAgent());
        assertEquals("75KUWMLH", data.getTxid());
    }

    @Test
    public void testRocketP2PPersonal() {
        String sms = "Tk20.00 received from A/C:***583 Fee:Tk0, Your A/C Balance: Tk25.97 TxnId:7011827020 Date:04-OCT-26 10:51:51 am.";
        PaymentData data = PaymentParser.parse("16216", sms, System.currentTimeMillis());

        assertNotNull("Rocket personal payment must not be null", data);
        assertEquals(Provider.ROCKET, data.getProvider());
        assertEquals("R", data.getTypeCode());
        assertEquals("20.00", data.getAmount());
        assertEquals("***583", data.getAgent());
        assertEquals("7011827020", data.getTxid());
    }

    @Test
    public void testRocketCashInUserSample() {
        String sms = "Cash-In from A/C: ***222 Tk20.00 Fee: Tk.00, Your A/C Balance: Tk55.64.TxnId:7015175802 Date:05-OCT-26 11:52:38 am. Download https://bit.ly/nexuspay";
        PaymentData data = PaymentParser.parse("16216", sms, System.currentTimeMillis());

        assertNotNull("Rocket Cash-In user sample must be accepted", data);
        assertEquals(Provider.ROCKET, data.getProvider());
        assertEquals("R", data.getTypeCode());
        assertEquals("20.00", data.getAmount());
        assertEquals("***222", data.getAgent());
        assertEquals("7015175802", data.getTxid());
    }

    @Test
    public void testRocketCashOutRejected() {
        String sms = "Cash-Out from A/C: ***896 Tk5,000.00 Comm:Tk21.01; A/C Balance: Tk7,690.83. TxnId: 7010127919";
        PaymentData data = PaymentParser.parse("Rocket", sms, System.currentTimeMillis());
        assertNull("Rocket Cash-Out must be strictly rejected per user request", data);
    }

    @Test
    public void testNegativeOtpMessage() {
        String otpSms = "Your bKash verification code is 482910. Do not share this OTP with anyone.";
        PaymentData data = PaymentParser.parse("bKash", otpSms, System.currentTimeMillis());
        assertNull("OTP message must be strictly rejected", data);
    }

    @Test
    public void testNegativeRandomSpamMessage() {
        String randomSms = "Enjoy 1GB internet for only 24 Tk! Dial *121*1# to activate this special offer.";
        PaymentData data = PaymentParser.parse("GP", randomSms, System.currentTimeMillis());
        assertNull("Random marketing SMS must be rejected", data);
    }

    @Test
    public void testNegativeMalformedPaymentMessage() {
        String malformedSms = "You have received Tk from 01737078264 without amount or TrxID";
        PaymentData data = PaymentParser.parse("bKash", malformedSms, System.currentTimeMillis());
        assertNull("Malformed message missing TrxID must be rejected", data);
    }

    // -------------------------------------------------------------
    // STRICT NEGATIVE TESTS: OUTGOING TRANSACTIONS (Send Money, Cash Out, Recharge, etc.)
    // MUST BE 100% REJECTED!
    // -------------------------------------------------------------

    @Test
    public void testBkashSendMoneyTransferredRejected() {
        String sms = "You have transferred Tk 500.00 to 01711223344. Fee Tk 5.00. Balance Tk 1,234.56. TrxID 9A8B7C6D at 09/10/2026 15:30";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());
        assertNull("bKash Send Money / Transferred must be strictly rejected", data);
    }

    @Test
    public void testBkashSendMoneyPattern2Rejected() {
        String sms = "Send Money Tk 500.00 to 01711223344 successful. Ref . Fee Tk 5.00. Balance Tk 1,234.56. TrxID 9A8B7C6D at 09/10/2026 15:30";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());
        assertNull("bKash Send Money must be strictly rejected", data);
    }

    @Test
    public void testBkashCashOutRejected() {
        String sms = "Cash Out Tk 1,000.00 to 01711223344. Fee Tk 18.50. Balance Tk 500.00. TrxID 9A8B7C6D at 09/10/2026 15:30";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());
        assertNull("bKash Cash Out must be strictly rejected", data);
    }

    @Test
    public void testBkashMobileRechargeRejected() {
        String sms = "Mobile Recharge Tk 50.00 to 01711223344 successful. TrxID 9A8B7C6D at 09/10/2026 15:30";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());
        assertNull("bKash Mobile Recharge must be strictly rejected", data);
    }

    @Test
    public void testBkashPaymentToMerchantRejected() {
        String sms = "Payment Tk 350.00 to 01711223344 successful. Ref 111. Balance Tk 500.00. TrxID 9A8B7C6D at 09/10/2026 15:30";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());
        assertNull("bKash Payment to merchant must be strictly rejected", data);
    }

    @Test
    public void testNagadSendMoneyRejected() {
        String sms = "Send Money to 01711223344 successful. Amount: Tk 500.00. Fee: Tk 5.00. TxnID: 75KXXXXX. Balance: Tk 1000.00";
        PaymentData data = PaymentParser.parse("Nagad", sms, System.currentTimeMillis());
        assertNull("Nagad Send Money must be strictly rejected", data);
    }

    @Test
    public void testNagadCashOutRejected() {
        String sms = "Cash Out to Uddokta 01811223344 successful. Amount: Tk 1000.00. Fee: Tk 15.00. TxnID: 75KYYYYY";
        PaymentData data = PaymentParser.parse("Nagad", sms, System.currentTimeMillis());
        assertNull("Nagad Cash Out must be strictly rejected", data);
    }

    @Test
    public void testNagadMobileRechargeRejected() {
        String sms = "Mobile Recharge to 01711223344 successful. Amount: Tk 50.00. TxnID: 75KZZZZZ";
        PaymentData data = PaymentParser.parse("Nagad", sms, System.currentTimeMillis());
        assertNull("Nagad Mobile Recharge must be strictly rejected", data);
    }

    @Test
    public void testRocketSendMoneyRejected() {
        String sms = "Send Money to A/C: 01711223344 Tk 500.00 successful. TxnId: 7011999999";
        PaymentData data = PaymentParser.parse("Rocket", sms, System.currentTimeMillis());
        assertNull("Rocket Send Money must be strictly rejected", data);
    }

    @Test
    public void testRocketCashOutToRejected() {
        String sms = "Cash Out to A/C: 01711223344 Tk 1,000.00. TxnId: 7011999999";
        PaymentData data = PaymentParser.parse("Rocket", sms, System.currentTimeMillis());
        assertNull("Rocket Cash Out must be strictly rejected", data);
    }

    @Test
    public void testBkashPaymentReceivedSuccess() {
        String sms = "Payment received Tk 500.00 from 01737078264. Ref 22222. Balance Tk 3,000.00. TrxID DJ118THL8D at 09/10/2026 12:00";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());
        assertNotNull("bKash Payment Received must succeed", data);
        assertEquals("500.00", data.getAmount());
        assertEquals("01737078264", data.getAgent());
        assertEquals("DJ118THL8D", data.getTxid());
    }

    @Test
    public void testNagadPaymentReceivedSuccess() {
        String sms = "Payment Received.\nAmount: Tk 500.00\nCustomer: 01714929542\nRef: N/A\nTxnID: 75KUWMLH\nBalance: Tk 2422.01\n27/06/2026 14:03";
        PaymentData data = PaymentParser.parse("Nagad", sms, System.currentTimeMillis());
        assertNotNull("Nagad Payment Received must succeed", data);
        assertEquals("500.00", data.getAmount());
        assertEquals("01714929542", data.getAgent());
        assertEquals("75KUWMLH", data.getTxid());
    }

    // -------------------------------------------------------------
    // Upay (U) Tests - Exact Samples and Edge Cases
    // -------------------------------------------------------------

    @Test
    public void testUpayPersonalMoneyReceivedSample() {
        String sms = "Tk. 14.00 has been received from 01787882701. Ref-. Balance Tk. 14.00. TrxID 01M4NBDPA3 at 11/10/2026 17:26.";
        PaymentData data = PaymentParser.parse("upay", sms, System.currentTimeMillis());

        assertNotNull("Upay personal received must be accepted", data);
        assertEquals(Provider.UPAY, data.getProvider());
        assertEquals("U", data.getTypeCode());
        assertEquals("14.00", data.getAmount());
        assertEquals("01787882701", data.getAgent());
        assertEquals("01M4NBDPA3", data.getTxid());
    }

    @Test
    public void testUpayAgentCashInSample() {
        String sms = "Cash-In of Tk. 290.00 from 01838607027 is successful. Balance Tk. 292.68. TrxID 01M4NMPMMK at 11/10/2026 20:08.";
        PaymentData data = PaymentParser.parse("upay", sms, System.currentTimeMillis());

        assertNotNull("Upay Cash-In must be accepted", data);
        assertEquals(Provider.UPAY, data.getProvider());
        assertEquals("U", data.getTypeCode());
        assertEquals("290.00", data.getAmount());
        assertEquals("01838607027", data.getAgent());
        assertEquals("01M4NMPMMK", data.getTxid());
    }

    @Test
    public void testUpayCashOutRejected() {
        String sms = "Cash-out of Tk. 290.00 from 01838607027 is successful. Fee Tk. 2.32. Balance Tk. 2.68. TrxID 01M4NMMVSE at 11/10/2026 20:07.";
        PaymentData data = PaymentParser.parse("upay", sms, System.currentTimeMillis());
        assertNull("Upay Cash-out must be strictly rejected", data);
    }

    @Test
    public void testUpaySendMoneyRejected() {
        String sms = "Send money of Tk. 14.00 to 01787882701 is successful. Fee Tk. 0.0. Balance Tk. 0.00. Ref-. TrxID 01M4NBHDW5 at 11/10/2026 17:28.";
        PaymentData data = PaymentParser.parse("upay", sms, System.currentTimeMillis());
        assertNull("Upay Send Money must be strictly rejected", data);
    }

    @Test
    public void testUpayNonPhoneReceivedFromRocketNotClassifiedAsRocket() {
        String sms = "Tk.295.00 has been received from Rocket. Balance Tk.295.00. TrxID 01M4NMKAM5 at 11/10/2026 20:06.";
        Provider detected = ProviderDetector.detect("upay", sms);
        // Must never be classified as Rocket just because body has 'from Rocket'
        assertNotNull(detected);
        Assert.assertNotEquals(Provider.ROCKET, detected);
    }

    @Test
    public void testUpayOtpAndPromoRejected() {
        String otpSms = "Your Upay OTP is 123456. Do not share this PIN with anyone.";
        assertNull("OTP must be rejected", PaymentParser.parse("upay", otpSms, System.currentTimeMillis()));

        String promoSms = "Cash reward Tk 50.00 added to your Upay account. Enjoy shopping.";
        assertNull("Cash reward must be rejected", PaymentParser.parse("upay", promoSms, System.currentTimeMillis()));
    }

    @Test
    public void testAllProviderTypeCodesDistinct() {
        assertEquals("B", Provider.BKASH.getTypeCode());
        assertEquals("N", Provider.NAGAD.getTypeCode());
        assertEquals("R", Provider.ROCKET.getTypeCode());
        assertEquals("U", Provider.UPAY.getTypeCode());
        assertEquals("UNKNOWN", Provider.UNKNOWN.getTypeCode());
    }

    // -------------------------------------------------------------
    // STRICT bKash SENDER ID VALIDATION TEST SUITE
    // -------------------------------------------------------------

    @Test
    public void testGenuineBkashExample1Received() {
        String sms = "You have received Tk 510.00 from 01607042219. Fee Tk 0.00. Balance Tk 17,825.87. TrxID DJL3C9YE5T at 21/10/2026 17:15";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());

        assertNotNull("Genuine bKash SMS from sender 'bKash' MUST be allowed", data);
        assertEquals(Provider.BKASH, data.getProvider());
        assertEquals("510.00", data.getAmount());
        assertEquals("01607042219", data.getAgent());
        assertEquals("DJL3C9YE5T", data.getTxid());
    }

    @Test
    public void testGenuineBkashExample2Ref() {
        String sms = "You have received Tk 2,010.00 from 01795930773. Ref 1122. Fee Tk 0.00. Balance Tk 19,835.87. TrxID DJM0DGD2YM at 22/10/2026 11:50";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());

        assertNotNull("Genuine bKash SMS with Ref field from sender 'bKash' MUST be allowed", data);
        assertEquals(Provider.BKASH, data.getProvider());
        assertEquals("2010.00", data.getAmount());
        assertEquals("01795930773", data.getAgent());
        assertEquals("DJM0DGD2YM", data.getTxid());
    }

    @Test
    public void testGenuineBkashExample3CashIn() {
        String sms = "Cash In Tk 484.00 from 01757171746 successful. Fee Tk 0.00. Balance Tk 20,319.87. TrxID DJN2FPKI3Q at 23/10/2026 19:16. Download App: https://bk.a.sh/8app";
        PaymentData data = PaymentParser.parse("bKash", sms, System.currentTimeMillis());

        assertNotNull("Genuine bKash Cash In SMS from sender 'bKash' MUST be allowed", data);
        assertEquals(Provider.BKASH, data.getProvider());
        assertEquals("484.00", data.getAmount());
        assertEquals("01757171746", data.getAgent());
        assertEquals("DJN2FPKI3Q", data.getTxid());
    }

    @Test
    public void testFakeBkashSMSFromPersonalNumberRejected() {
        String fakeSms = "Cash In Tk 20,400.00 from 01936399539 successful. Fee Tk 0.00. Balance Tk 20,400.00. TrxID CC21A9A5BB 30/10/2026 Download App: https://bkash/8app";

        assertNull("Fake bKash SMS from '+8801936399539' MUST be strictly rejected", PaymentParser.parse("+8801936399539", fakeSms, System.currentTimeMillis()));
        assertNull("Fake bKash SMS from '01936399539' MUST be strictly rejected", PaymentParser.parse("01936399539", fakeSms, System.currentTimeMillis()));
        assertNull("Fake bKash SMS from '+8801700000000' MUST be strictly rejected", PaymentParser.parse("+8801700000000", fakeSms, System.currentTimeMillis()));
    }

    @Test
    public void testFakeBkashSenderNameVariationsRejected() {
        String sms = "You have received Tk 500.00 from 01700000000. Fee Tk 0.00. Balance Tk 500.00. TrxID 9A8B7C6D5E";

        assertNull("Sender 'FakebKash' MUST be rejected", PaymentParser.parse("FakebKash", sms, System.currentTimeMillis()));
        assertNull("Sender 'bKashSupport' MUST be rejected", PaymentParser.parse("bKashSupport", sms, System.currentTimeMillis()));
        assertNull("Sender 'MybKash' MUST be rejected", PaymentParser.parse("MybKash", sms, System.currentTimeMillis()));
        assertNull("Sender 'bKash123' MUST be rejected", PaymentParser.parse("bKash123", sms, System.currentTimeMillis()));
        assertNull("Null sender MUST be rejected", PaymentParser.parse(null, sms, System.currentTimeMillis()));
        assertNull("Empty sender MUST be rejected", PaymentParser.parse("", sms, System.currentTimeMillis()));
    }

    @Test
    public void testAllowedBkashSenderCasing() {
        String sms = "You have received Tk 510.00 from 01607042219. Fee Tk 0.00. Balance Tk 17,825.87. TrxID DJL3C9YE5T at 21/10/2026 17:15";

        assertNotNull("BKASH upper case MUST be allowed", PaymentParser.parse("BKASH", sms, System.currentTimeMillis()));
        assertNotNull("bkash lower case MUST be allowed", PaymentParser.parse("bkash", sms, System.currentTimeMillis()));
        assertNotNull("bKash mixed case MUST be allowed", PaymentParser.parse("bKash", sms, System.currentTimeMillis()));
    }
}
