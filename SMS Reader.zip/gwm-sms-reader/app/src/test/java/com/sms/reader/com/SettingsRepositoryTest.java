package com.sms.reader.com;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit tests for SettingsRepository provider key matching and ProviderSetting states.
 */
public class SettingsRepositoryTest {

    @Test
    public void testBkashKeyMatchingVariants() {
        assertTrue("bKash casing should match", SettingsRepository.matchesProviderKey(Provider.BKASH, "bKash"));
        assertTrue("bkash lowercase should match", SettingsRepository.matchesProviderKey(Provider.BKASH, "bkash"));
        assertTrue("BKASH uppercase should match", SettingsRepository.matchesProviderKey(Provider.BKASH, "BKASH"));
        assertTrue("Bkash capitalized should match", SettingsRepository.matchesProviderKey(Provider.BKASH, "Bkash"));
        assertTrue("bkash_number with suffix should match", SettingsRepository.matchesProviderKey(Provider.BKASH, "bkash_number"));
        assertTrue("admin_bkash with prefix should match", SettingsRepository.matchesProviderKey(Provider.BKASH, "admin_bkash"));

        // Must not match other providers
        assertFalse("bKash must not match nagad", SettingsRepository.matchesProviderKey(Provider.BKASH, "nagad"));
        assertFalse("bKash must not match rocket", SettingsRepository.matchesProviderKey(Provider.BKASH, "rocket"));
        assertFalse("bKash must not match upay", SettingsRepository.matchesProviderKey(Provider.BKASH, "upay"));
    }

    @Test
    public void testNagadKeyMatchingVariants() {
        assertTrue("Nagad casing should match", SettingsRepository.matchesProviderKey(Provider.NAGAD, "Nagad"));
        assertTrue("nagad lowercase should match", SettingsRepository.matchesProviderKey(Provider.NAGAD, "nagad"));
        assertTrue("NAGAD uppercase should match", SettingsRepository.matchesProviderKey(Provider.NAGAD, "NAGAD"));
        assertTrue("nagad_personal should match", SettingsRepository.matchesProviderKey(Provider.NAGAD, "nagad_personal"));

        assertFalse("Nagad must not match bkash", SettingsRepository.matchesProviderKey(Provider.NAGAD, "bKash"));
        assertFalse("Nagad must not match rocket", SettingsRepository.matchesProviderKey(Provider.NAGAD, "Rocket"));
        assertFalse("Nagad must not match upay", SettingsRepository.matchesProviderKey(Provider.NAGAD, "Upay"));
    }

    @Test
    public void testRocketKeyMatchingVariants() {
        assertTrue("Rocket casing should match", SettingsRepository.matchesProviderKey(Provider.ROCKET, "Rocket"));
        assertTrue("rocket lowercase should match", SettingsRepository.matchesProviderKey(Provider.ROCKET, "rocket"));
        assertTrue("ROCKET uppercase should match", SettingsRepository.matchesProviderKey(Provider.ROCKET, "ROCKET"));
        assertTrue("rocket_agent should match", SettingsRepository.matchesProviderKey(Provider.ROCKET, "rocket_agent"));

        assertFalse("Rocket must not match bkash", SettingsRepository.matchesProviderKey(Provider.ROCKET, "bKash"));
        assertFalse("Rocket must not match nagad", SettingsRepository.matchesProviderKey(Provider.ROCKET, "Nagad"));
        assertFalse("Rocket must not match upay", SettingsRepository.matchesProviderKey(Provider.ROCKET, "upay"));
    }

    @Test
    public void testUpayKeyMatchingVariants() {
        assertTrue("upay lowercase should match", SettingsRepository.matchesProviderKey(Provider.UPAY, "upay"));
        assertTrue("Upay capitalized should match", SettingsRepository.matchesProviderKey(Provider.UPAY, "Upay"));
        assertTrue("UPAY uppercase should match", SettingsRepository.matchesProviderKey(Provider.UPAY, "UPAY"));
        assertTrue("upay_number should match", SettingsRepository.matchesProviderKey(Provider.UPAY, "upay_number"));

        assertFalse("Upay must not match bkash", SettingsRepository.matchesProviderKey(Provider.UPAY, "bKash"));
        assertFalse("Upay must not match nagad", SettingsRepository.matchesProviderKey(Provider.UPAY, "Nagad"));
        assertFalse("Upay must not match rocket", SettingsRepository.matchesProviderKey(Provider.UPAY, "Rocket"));
    }

    @Test
    public void testProviderSettingState() {
        // Valid configured number
        SettingsRepository.ProviderSetting configured = new SettingsRepository.ProviderSetting("01787882701", true);
        assertEquals("01787882701", configured.getNumber());
        assertTrue(configured.isConfigured());
        assertTrue(configured.isEnabled());

        // Configured but disabled
        SettingsRepository.ProviderSetting disabled = new SettingsRepository.ProviderSetting("01787882701", false);
        assertEquals("01787882701", disabled.getNumber());
        assertTrue(disabled.isConfigured());
        assertFalse(disabled.isEnabled());

        // Not configured
        SettingsRepository.ProviderSetting notConfigured = new SettingsRepository.ProviderSetting("Not configured", true);
        assertEquals("Not configured", notConfigured.getNumber());
        assertFalse(notConfigured.isConfigured());
        assertFalse(notConfigured.isEnabled());

        // Null / empty
        SettingsRepository.ProviderSetting empty = new SettingsRepository.ProviderSetting("", true);
        assertEquals("Not configured", empty.getNumber());
        assertFalse(empty.isConfigured());
        assertFalse(empty.isEnabled());
    }
}
