package com.sms.reader.com;

import static org.junit.Assert.assertNotNull;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.ImageView;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class LogoLoaderTest {

    private Context context;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
        LogoLoader.clearCache();
    }

    @Test
    public void testGetLogoBitmapReturnsBitmapOrFallback() {
        Bitmap bitmap = LogoLoader.getLogoBitmap(context);
        // Should decode from assets/logo.png or logo.jpg successfully
        assertNotNull("Logo bitmap from assets should not be null", bitmap);
    }

    @Test
    public void testLoadLogoIntoImageView() {
        ImageView imageView = new ImageView(context);
        LogoLoader.loadLogoInto(imageView, context);
        assertNotNull("ImageView drawable should not be null after loading logo", imageView.getDrawable());
    }

    @Test
    public void testNotificationUsesCustomLogo() {
        android.app.Notification notification = NotificationHelper.getInstance(context).getForegroundNotification();
        assertNotNull("Foreground notification should not be null", notification);
    }
}
