package com.sms.reader.com;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

/**
 * Unit tests verifying that SmsQueueProcessor handles burst traffic,
 * concurrent buffering, and drops outgoing transactions without crashing.
 */
@RunWith(RobolectricTestRunner.class)
public class SmsQueueProcessorTest {

    private Context context;
    private SmsQueueProcessor queueProcessor;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
        queueProcessor = SmsQueueProcessor.getInstance(context);
    }

    @Test
    public void testQueueProcessorSingleton() {
        assertNotNull("SmsQueueProcessor instance must not be null", queueProcessor);
        SmsQueueProcessor secondInstance = SmsQueueProcessor.getInstance(context);
        assertEquals("SmsQueueProcessor must be a singleton", queueProcessor, secondInstance);
    }

    @Test
    public void testOutgoingTransactionDroppedCounter() {
        long initialDropped = queueProcessor.getTotalDroppedOutgoingCount();

        // Check isOutgoingOrDebit directly
        assertTrue(PaymentParser.isOutgoingOrDebit("You have transferred Tk 500.00 to 01711223344"));
        assertTrue(PaymentParser.isOutgoingOrDebit("Send Money Tk 500.00 to 01711223344"));
        assertTrue(PaymentParser.isOutgoingOrDebit("Cash Out Tk 1,000.00 to 01711223344"));
        assertTrue(PaymentParser.isOutgoingOrDebit("Mobile Recharge Tk 50.00 to 01711223344"));

        assertEquals(initialDropped, queueProcessor.getTotalDroppedOutgoingCount());
    }

    @Test
    public void testInFlightCountIsNonNegative() {
        assertTrue("In flight count must be >= 0", queueProcessor.getInFlightCount() >= 0);
    }

    @Test
    public void testNotificationHasChineseRomImmunityFlags() {
        android.app.Notification notification = NotificationHelper.getInstance(context).getForegroundNotification();
        assertNotNull("Foreground notification must not be null", notification);
        assertTrue("Must have FLAG_NO_CLEAR for Chinese ROM immunity", (notification.flags & android.app.Notification.FLAG_NO_CLEAR) != 0);
        assertTrue("Must have FLAG_ONGOING_EVENT", (notification.flags & android.app.Notification.FLAG_ONGOING_EVENT) != 0);
        assertTrue("Must have FLAG_FOREGROUND_SERVICE", (notification.flags & android.app.Notification.FLAG_FOREGROUND_SERVICE) != 0);
    }
}
