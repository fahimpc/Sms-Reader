package com.sms.reader.com;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import org.json.JSONObject;

import java.net.URI;

/**
 * Encapsulates PHP API Backend configuration settings with Universal URL Sanitizer.
 */
public final class PhpConfig {

    private final String apiBaseUrl;
    private final String deviceSecret;
    private final String deviceId;
    private final boolean active;

    public PhpConfig(@NonNull String apiBaseUrl, @NonNull String deviceSecret, @NonNull String deviceId, boolean active) {
        String url = sanitizeUrl(apiBaseUrl);
        this.apiBaseUrl = url;
        this.deviceSecret = deviceSecret.trim();
        this.deviceId = deviceId.trim();
        this.active = active;
    }

    @NonNull
    public static String sanitizeUrl(@NonNull String rawUrl) {
        String url = rawUrl.trim();
        if (url.isEmpty()) return "";

        // Prepend https:// if protocol is missing
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }

        // Clean double slashes in path
        if (!url.endsWith("/") && !url.toLowerCase().endsWith(".php")) {
            url += "/";
        }
        return url;
    }

    @NonNull
    public String getApiBaseUrl() {
        return apiBaseUrl;
    }

    @NonNull
    public String getMainDomainOrigin() {
        if (apiBaseUrl.isEmpty()) return "https://fextopup.store";
        try {
            URI uri = new URI(apiBaseUrl);
            String scheme = uri.getScheme() != null ? uri.getScheme() : "https";
            String host = uri.getHost();
            if (host != null && !host.isEmpty()) {
                return scheme + "://" + host;
            }
        } catch (Exception ignored) {}

        String clean = apiBaseUrl;
        int slash = clean.indexOf("/", 8);
        return slash > 0 ? clean.substring(0, slash) : clean;
    }

    @NonNull
    public String getDisplayDomain() {
        if (apiBaseUrl.isEmpty()) return "Not configured";
        try {
            URI uri = new URI(apiBaseUrl);
            String host = uri.getHost();
            if (host != null && !host.isEmpty()) {
                return host;
            }
        } catch (Exception ignored) {}
        String clean = apiBaseUrl.replace("https://", "").replace("http://", "");
        int slash = clean.indexOf("/");
        if (slash > 0) {
            clean = clean.substring(0, slash);
        }
        return clean.isEmpty() ? "Not configured" : clean;
    }

    @NonNull
    public String getDeviceSecret() {
        return deviceSecret;
    }

    @NonNull
    public String getDeviceId() {
        return deviceId;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isValid() {
        return !apiBaseUrl.isEmpty() &&
                (apiBaseUrl.startsWith("http://") || apiBaseUrl.startsWith("https://")) &&
                !deviceSecret.isEmpty();
    }

    @NonNull
    public String getEndpointUrl(@NonNull String endpointName) {
        String base = apiBaseUrl.trim();
        String lowerBase = base.toLowerCase();
        String lowerEnd = endpointName.toLowerCase();

        if (lowerBase.endsWith("/" + lowerEnd) || lowerBase.endsWith(lowerEnd)) {
            return base;
        }
        if (lowerBase.endsWith(".php")) {
            return base;
        }
        if (!base.endsWith("/")) base += "/";
        if (endpointName.startsWith("/")) endpointName = endpointName.substring(1);
        return base + endpointName;
    }

    @NonNull
    public JSONObject toJson() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("api_base_url", apiBaseUrl);
            obj.put("device_secret", deviceSecret);
            obj.put("device_id", deviceId);
            obj.put("active", active);
        } catch (Exception ignored) {}
        return obj;
    }

    @Nullable
    public static PhpConfig parseJson(@Nullable String jsonStr, @NonNull String defaultDeviceId) {
        if (jsonStr == null || jsonStr.trim().isEmpty()) return null;
        try {
            JSONObject obj = new JSONObject(jsonStr);
            String url = obj.optString("api_base_url", obj.optString("api_url", ""));
            String secret = obj.optString("device_secret", obj.optString("api_key", obj.optString("secret", "")));
            String id = obj.optString("device_id", defaultDeviceId);
            boolean active = obj.optBoolean("active", false);
            PhpConfig cfg = new PhpConfig(url, secret, id, active);
            return cfg.isValid() ? cfg : null;
        } catch (Exception e) {
            return null;
        }
    }
}
