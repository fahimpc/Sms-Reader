package com.sms.reader.com;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Central Sync Engine for Payment SMS Sync Center V1.0.
 *
 * Manages durable local SQLite queueing, network connectivity callbacks,
 * automatic backoff retries, and manual retry triggers.
 */
public final class SmsSyncManager {

    public interface SyncCallback {
        void onSyncCompleted(int successCount, int failedCount);
    }

    private static final String PREF_NAME = "gwm_sms_sync_prefs";
    private static final String KEY_AUTO_SYNC = "auto_sync_enabled";
    public static final String ACTION_SYNC_QUEUE_UPDATED = "com.sms.reader.com.ACTION_SYNC_QUEUE_UPDATED";

    private static SmsSyncManager instance;

    private final Context appContext;
    private final SharedPreferences prefs;
    private final SmsSyncSQLiteHelper dbHelper;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean isSyncing = new AtomicBoolean(false);

    public static synchronized SmsSyncManager getInstance(Context context) {
        if (instance == null) {
            instance = new SmsSyncManager(context.getApplicationContext());
        }
        return instance;
    }

    private SmsSyncManager(Context context) {
        this.appContext = context;
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.dbHelper = SmsSyncSQLiteHelper.getInstance(context);

        registerNetworkCallback();
    }

    public boolean isAutoSyncEnabled() {
        return prefs.getBoolean(KEY_AUTO_SYNC, true);
    }

    public void setAutoSyncEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_AUTO_SYNC, enabled).apply();
        AppLogger.log("Auto Sync set to: " + (enabled ? "ON" : "OFF"));
        notifySyncQueueUpdated();

        if (enabled && isNetworkConnected()) {
            syncPendingQueue(null);
        }
    }

    public boolean isNetworkConnected() {
        try {
            ConnectivityManager cm = (ConnectivityManager) appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                Network network = cm.getActiveNetwork();
                if (network != null) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                    return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                            || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                            || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Enqueues an eligible payment SMS into the durable local SQLite queue.
     */
    public synchronized void enqueuePaymentSms(@NonNull PaymentData data) {
        String backendMode = BackendManager.getInstance(appContext).getActiveMode().name();
        String devId = PhpConfigManager.getInstance(appContext).getOrCreateDeviceId();
        String idKey = backendMode + "_" + data.getProviderName() + "_" + data.getTxid();

        SmsSyncEntity record = new SmsSyncEntity();
        record.setIdempotencyKey(idKey);
        record.setDeviceId(devId);
        record.setProvider(data.getProvider().name());
        record.setReceivingNumber(data.getAgent());
        record.setSender(data.getSender());
        record.setAmount(data.getAmount());
        record.setTxid(data.getTxid());
        record.setTimestamp(data.getTimestamp());
        record.setRawSms(data.getRawSms());
        record.setBackendMode(backendMode);

        boolean online = isNetworkConnected();
        record.setStatus(online ? "PENDING" : "OFFLINE");
        record.setFailureReason(online ? "Pending Synchronization" : "No Internet Connection");

        long rowId = dbHelper.insertRecord(record);
        AppLogger.log("Enqueued Payment SMS to Sync Center (ID: " + rowId + ", Status: " + record.getStatus() + ")");
        notifySyncQueueUpdated();

        if (isAutoSyncEnabled() && online) {
            syncPendingQueue(null);
        }
    }

    /**
     * Attempts to synchronize all pending, offline, and server_failed records.
     */
    public void syncPendingQueue(@Nullable final SyncCallback callback) {
        if (!isSyncing.compareAndSet(false, true)) {
            if (callback != null) callback.onSyncCompleted(0, 0);
            return;
        }

        executor.execute(() -> {
            int successCount = 0;
            int failedCount = 0;

            try {
                if (!isNetworkConnected()) {
                    AppLogger.log("Sync Center: Internet unavailable. Pending records kept in OFFLINE state.");
                    notifySyncQueueUpdated();
                    return;
                }

                List<SmsSyncEntity> pendingList = dbHelper.getPendingRetryableRecords();
                if (pendingList.isEmpty()) {
                    notifySyncQueueUpdated();
                    return;
                }

                AppLogger.log("Sync Center: Starting sync for " + pendingList.size() + " pending payment SMS records...");

                for (int i = 0; i < pendingList.size(); i++) {
                    SmsSyncEntity record = pendingList.get(i);
                    if ("NEEDS_ATTENTION".equals(record.getStatus())) {
                        continue; // Skip permanent auth/pairing failure records
                    }

                    // Enforce 3-second Sequential Gap between requests to pass Imunify360 rate limits
                    if (i > 0) {
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException ignored) {}
                    }

                    dbHelper.updateStatus(record.getId(), "SYNCING", "Syncing to server...", record.getRetryCount(), 0L);
                    notifySyncQueueUpdated();

                    boolean success = uploadSingleRecordSync(record);
                    if (success) {
                        successCount++;
                        dbHelper.markSynced(record.getId(), "Server Acknowledged OK");
                    } else {
                        failedCount++;
                        int newRetry = record.getRetryCount() + 1;
                        long backoffDelay = calculateExponentialBackoff(newRetry);
                        long backoffTime = System.currentTimeMillis() + backoffDelay;
                        dbHelper.updateStatus(record.getId(), "SERVER_FAILED", "Server Unavailable (Retry #" + newRetry + ")", newRetry, backoffTime);
                    }
                    notifySyncQueueUpdated();
                }

            } catch (Exception e) {
                AppLogger.error("Sync Center Exception: " + e.getMessage(), e);
            } finally {
                isSyncing.set(false);
                notifySyncQueueUpdated();

                final int finalSuccess = successCount;
                final int finalFailed = failedCount;
                if (callback != null) {
                    mainHandler.post(() -> callback.onSyncCompleted(finalSuccess, finalFailed));
                }
            }
        });
    }

    public void retrySingleRecord(long id, @Nullable SyncCallback callback) {
        executor.execute(() -> {
            List<SmsSyncEntity> all = dbHelper.getAllRecords();
            SmsSyncEntity target = null;
            for (SmsSyncEntity item : all) {
                if (item.getId() == id) {
                    target = item;
                    break;
                }
            }

            if (target != null && !"SYNCED".equals(target.getStatus())) {
                boolean online = isNetworkConnected();
                if (!online) {
                    dbHelper.updateStatus(id, "OFFLINE", "No Internet Connection", 0, 0L);
                    notifySyncQueueUpdated();
                    if (callback != null) mainHandler.post(() -> callback.onSyncCompleted(0, 1));
                    return;
                }

                // Reset retry count to 0 for fresh manual retry
                dbHelper.updateStatus(id, "SYNCING", "Manual Retry in Progress...", 0, 0L);
                notifySyncQueueUpdated();

                boolean success = uploadSingleRecordSync(target);
                if (success) {
                    dbHelper.markSynced(id, "Manual Retry Successful");
                    notifySyncQueueUpdated();
                    if (callback != null) mainHandler.post(() -> callback.onSyncCompleted(1, 0));
                } else {
                    dbHelper.updateStatus(id, "SERVER_FAILED", "Manual Retry Failed - Server Firewall / HTTP Error", 1, System.currentTimeMillis() + 15_000L);
                    notifySyncQueueUpdated();
                    if (callback != null) mainHandler.post(() -> callback.onSyncCompleted(0, 1));
                }
            }
        });
    }

    private boolean uploadSingleRecordSync(SmsSyncEntity record) {
        Provider p = Provider.fromString(record.getProvider());
        PaymentData data = new PaymentData(p, record.getAmount(), record.getReceivingNumber(), record.getTxid(), record.getRawSms(), record.getSender(), record.getTimestamp());

        final AtomicBoolean successResult = new AtomicBoolean(false);
        final Object lock = new Object();

        if ("PHP_MYSQL".equalsIgnoreCase(record.getBackendMode()) || BackendManager.getInstance(appContext).isPhpMode()) {
            PhpWriter.uploadTransaction(appContext, data, new FirebaseWriter.UploadCallback() {
                @Override public void onSuccess(String txid) {
                    successResult.set(true);
                    synchronized (lock) { lock.notifyAll(); }
                }
                @Override public void onAlreadyExists(String txid) {
                    successResult.set(true);
                    synchronized (lock) { lock.notifyAll(); }
                }
                @Override public void onError(String errorCode, String message) {
                    successResult.set(false);
                    synchronized (lock) { lock.notifyAll(); }
                }
            });
        } else {
            FirebaseWriter.uploadTransaction(appContext, data, new FirebaseWriter.UploadCallback() {
                @Override public void onSuccess(String txid) {
                    successResult.set(true);
                    synchronized (lock) { lock.notifyAll(); }
                }
                @Override public void onAlreadyExists(String txid) {
                    successResult.set(true);
                    synchronized (lock) { lock.notifyAll(); }
                }
                @Override public void onError(String errorCode, String message) {
                    successResult.set(false);
                    synchronized (lock) { lock.notifyAll(); }
                }
            });
        }

        synchronized (lock) {
            try {
                lock.wait(12000); // 12 second wait timeout per record
            } catch (InterruptedException ignored) {}
        }

        return successResult.get();
    }

    public static long calculateExponentialBackoff(int retryCount) {
        switch (retryCount) {
            case 1:
                return 15_000L; // 1st retry after 15 seconds
            case 2:
                return 45_000L; // 2nd retry after 45 seconds
            case 3:
                return 120_000L; // 3rd retry after 2 minutes
            case 4:
            default:
                return 300_000L; // 4th+ retry after 5 minutes
        }
    }

    public int getOfflineCount() { return dbHelper.getCountByStatus("OFFLINE"); }
    public int getFailedCount() { return dbHelper.getCountByStatus("SERVER_FAILED"); }
    public int getPendingCount() { return dbHelper.getCountByStatus("PENDING"); }
    public int getSyncedCount() { return dbHelper.getCountByStatus("SYNCED"); }
    public int getNeedsAttentionCount() { return dbHelper.getCountByStatus("NEEDS_ATTENTION"); }

    public long getLastSyncedTimestamp() { return dbHelper.getLastSyncedTimestamp(); }

    public List<SmsSyncEntity> getRecordsForFilter(String filter) {
        return dbHelper.getRecordsByStatusFilter(filter);
    }

    private void notifySyncQueueUpdated() {
        try {
            Intent intent = new Intent(ACTION_SYNC_QUEUE_UPDATED);
            intent.setPackage(appContext.getPackageName());
            appContext.sendBroadcast(intent);
        } catch (Exception ignored) {}
    }

    private void registerNetworkCallback() {
        try {
            ConnectivityManager cm = (ConnectivityManager) appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build();

                cm.registerNetworkCallback(request, new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(@NonNull Network network) {
                        AppLogger.log("Sync Center: Internet connectivity restored.");
                        notifySyncQueueUpdated();
                        if (isAutoSyncEnabled()) {
                            syncPendingQueue(null);
                        }
                    }

                    @Override
                    public void onLost(@NonNull Network network) {
                        AppLogger.log("Sync Center: Internet lost.");
                        notifySyncQueueUpdated();
                    }
                });
            }
        } catch (Exception ignored) {}
    }
}
