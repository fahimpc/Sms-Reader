package com.sms.reader.com;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewpager2.widget.ViewPager2;

/**
 * Nagad-style smooth horizontal page-sliding transformer for ViewPager2.
 * Provides 60fps hardware-accelerated horizontal slide transitions with subtle scale and alpha depth,
 * without overriding native ViewPager2 translation or causing blank/overlapping page artifacts.
 */
public final class NagadPageTransformer implements ViewPager2.PageTransformer {

    private static final float MIN_ALPHA = 0.85f;
    private static final float MIN_SCALE = 0.96f;

    @Override
    public void transformPage(@NonNull View page, float position) {
        if (position < -1f) {
            // Off-screen to the left
            page.setAlpha(0f);
        } else if (position <= 1f) {
            // [-1, 1] Active transition viewport
            float factor = 1.0f - Math.abs(position);

            // Scale effect (Nagad subtle depth)
            float scaleFactor = MIN_SCALE + (1.0f - MIN_SCALE) * factor;
            page.setScaleX(scaleFactor);
            page.setScaleY(scaleFactor);

            // Alpha fade (0.85 to 1.0)
            float alpha = MIN_ALPHA + (1.0f - MIN_ALPHA) * factor;
            page.setAlpha(alpha);

            // Enable hardware layer acceleration during animation
            if (position == 0f) {
                page.setLayerType(View.LAYER_TYPE_NONE, null);
            } else {
                page.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            }
        } else {
            // Off-screen to the right
            page.setAlpha(0f);
        }
    }
}
