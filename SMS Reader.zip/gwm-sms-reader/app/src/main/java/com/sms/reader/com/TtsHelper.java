package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.Locale;

/**
 * Text-To-Speech (TTS) & Sound Alert Voice Manager.
 *
 * Speaks clear voice announcements and plays chime alerts when payment SMS
 * (bKash, Nagad, Rocket, Upay) are received.
 * Example speech: "bKash e 500 Taka pawa geche" or "bKash 500 Taka Received"
 */
public final class TtsHelper implements TextToSpeech.OnInitListener {

    private static final String PREFS_NAME = "gwm_tts_settings";
    private static final String KEY_TTS_ENABLED = "tts_voice_enabled";

    private static TtsHelper instance;

    private final Context appContext;
    private final SharedPreferences prefs;
    private TextToSpeech tts;
    private boolean isInitialized = false;
    private boolean isBengaliSupported = false;
    private String pendingSpeech = null;

    public static synchronized TtsHelper getInstance(@NonNull Context context) {
        if (instance == null) {
            instance = new TtsHelper(context.getApplicationContext());
        }
        return instance;
    }

    private TtsHelper(Context context) {
        this.appContext = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        initTtsEngine();
    }

    private synchronized void initTtsEngine() {
        try {
            if (tts == null) {
                tts = new TextToSpeech(appContext, this);
            }
        } catch (Exception e) {
            AppLogger.error("Failed to initialize TextToSpeech engine: " + e.getMessage(), e);
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true;
            try {
                // Try Bengali Locale first
                Locale bnLocale = new Locale("bn", "BD");
                int result = tts.setLanguage(bnLocale);

                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                    isBengaliSupported = false;
                    AppLogger.log("TTS: Bengali voice package unavailable, using English TTS fallback.");
                } else {
                    isBengaliSupported = true;
                    AppLogger.log("TTS Engine initialized with Bengali Locale.");
                }

                tts.setSpeechRate(0.95f); // Natural speaking speed

                if (pendingSpeech != null) {
                    speakInternal(pendingSpeech);
                    pendingSpeech = null;
                }
            } catch (Exception e) {
                AppLogger.error("Error setting TTS language: " + e.getMessage(), e);
            }
        } else {
            isInitialized = false;
            AppLogger.log("TTS Engine initialization failed with status: " + status);
        }
    }

    public boolean isTtsEnabled() {
        return prefs.getBoolean(KEY_TTS_ENABLED, true);
    }

    public void setTtsEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_TTS_ENABLED, enabled).apply();
        AppLogger.log("Voice Alerts " + (enabled ? "ENABLED" : "DISABLED"));
    }

    /**
     * Plays system notification chime sound.
     */
    public void playNotificationSound() {
        try {
            Uri notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone ringtone = RingtoneManager.getRingtone(appContext, notificationUri);
            if (ringtone != null) {
                ringtone.play();
            }
        } catch (Exception e) {
            AppLogger.error("Failed to play notification chime sound: " + e.getMessage(), e);
        }
    }

    /**
     * Announces incoming payment transaction via Voice Alert Text-To-Speech.
     */
    public void speakPayment(@Nullable PaymentData data) {
        if (data == null || !isTtsEnabled()) return;

        String providerName = data.getProviderName();
        String amountStr = data.getAmount();

        if (providerName.isEmpty() || amountStr.isEmpty()) return;

        String cleanAmount = amountStr.replace(".00", "").trim();

        String speechText;
        if (isBengaliSupported) {
            speechText = providerName + " এ " + cleanAmount + " টাকা পাওয়া গেছে";
        } else {
            speechText = providerName + " " + cleanAmount + " Taka Received";
        }

        speakText(speechText);
    }

    public synchronized void speakText(@NonNull String text) {
        if (!isTtsEnabled() || text.trim().isEmpty()) return;

        AppLogger.log("VOICE ALERT: " + text);

        if (!isInitialized || tts == null) {
            pendingSpeech = text;
            initTtsEngine();
            return;
        }

        speakInternal(text);
    }

    private static final AudioAttributes SPEECH_AUDIO_ATTRIBUTES = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build();

    private void speakInternal(String text) {
        try {
            playNotificationSound();

            if (tts != null) {
                tts.setAudioAttributes(SPEECH_AUDIO_ATTRIBUTES);
                Bundle params = new Bundle();
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "gwm_tts_utt_" + System.currentTimeMillis());
            }
        } catch (Exception e) {
            AppLogger.error("Error uttering speech: " + e.getMessage(), e);
        }
    }

    public synchronized void shutdown() {
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {}
            tts = null;
            isInitialized = false;
        }
    }
}
