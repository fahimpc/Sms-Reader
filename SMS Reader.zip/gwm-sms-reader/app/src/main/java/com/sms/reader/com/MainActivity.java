package com.sms.reader.com;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.view.animation.DecelerateInterpolator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.sms.reader.com.databinding.ActivityMainBinding;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Main Dashboard Activity for GWM SMS Reader.
 * High-performance, zero-lag UI with responsive layouts and guaranteed touch event handling.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private SmsStore smsStore;
    private SettingsRepository settingsRepo;
    private FirebaseProvider fbProvider;
    private FirebaseConfigManager configManager;

    private HomeFragment homeFragment;
    private FirebaseFragment firebaseFragment;
    private PhpFragment phpFragment;
    private SettingsFragment settingsFragment;
    private Fragment activeFragment;

    private Provider selectedProvider = Provider.BKASH;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);

    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockRunnable = new Runnable() {
        @Override
        public void run() {
            if (binding != null && binding.tvHeaderClock != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a", Locale.US);
                binding.tvHeaderClock.setText(sdf.format(new Date()));
            }
            clockHandler.postDelayed(this, 1000);
        }
    };

    private ActivityResultLauncher<String[]> permissionLauncher;
    private ActivityResultLauncher<String> jsonFilePickerLauncher;
    private ActivityResultLauncher<String> logoPickerLauncher;
    private ActivityResultLauncher<PickVisualMediaRequest> photoPickerLauncher;

    // References to currently open dialog views if any
    private EditText currentDialogRawJson;
    private EditText currentDialogProjectId;
    private EditText currentDialogDatabaseUrl;
    private EditText currentDialogApiKey;
    private EditText currentDialogAppId;
    private TextView currentDialogStatus;
    private ProgressBar currentDialogProgress;
    private View currentDialogLayoutTestStatus;
    private Button currentDialogBtnTestAndSwitch;
    private View currentDialogLayoutPurgeCheckbox;
    private Button currentDialogBtnResetDefault;
    private Button currentDialogBtnRollback;
    private Button currentDialogBtnPurgeDefault;
    private TextView currentDialogTvActiveBadge;
    private TextView currentDialogTvActiveProjectId;
    private TextView currentDialogTvActiveDbUrl;
    private CheckBox currentDialogCbPurgeDefault;

    private final BroadcastReceiver smsBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String action = intent.getAction();
            if (AppConfig.ACTION_SMS_PROCESSED.equals(action)) {
                String providerName = intent.getStringExtra(AppConfig.EXTRA_PROVIDER);
                Provider p = Provider.fromString(providerName);
                if (p != Provider.UNKNOWN) {
                    selectProvider(p);
                    if (homeFragment != null) {
                        homeFragment.setSelectedProvider(p);
                    }
                }
                notifyHomeDashboardUpdated();
            } else if (AppConfig.ACTION_FIREBASE_STATE_CHANGED.equals(action)) {
                notifyHomeDashboardUpdated();
            }
        }
    };

    private final FirebaseProvider.StateListener fbStateListener = new FirebaseProvider.StateListener() {
        @Override
        public void onConnectionStateChanged(FirebaseProvider.ConnectionState state) {
            notifyHomeDashboardUpdated();
        }

        @Override
        public void onAuthUidChanged(String uid) {
            runOnUiThread(() -> updateReaderUidUi(uid));
        }
    };

    private final SettingsRepository.SettingsListener settingsListener = (provider, setting) -> {
        notifyHomeDashboardUpdated();
    };

    // Incremental log listener for zero lag
    private final AppLogger.LogListener logListener = (newEntry, fullLog) -> {
        if (binding != null && binding.tvLogConsole != null) {
            if (newEntry != null) {
                if (binding.tvLogConsole.getLineCount() > 150) {
                    binding.tvLogConsole.setText(AppLogger.getFullLog());
                } else {
                    binding.tvLogConsole.append(newEntry + "\n");
                }
            } else {
                binding.tvLogConsole.setText(fullLog != null ? fullLog : "");
            }
            binding.scrollLog.post(() -> binding.scrollLog.fullScroll(View.FOCUS_DOWN));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Edge-to-edge system window management for all modern devices
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat insetsController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
            insetsController.setAppearanceLightNavigationBars(false);
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        applyCurrentThemeUi();

        // Load custom logo from assets if provided
        LogoLoader.loadLogoInto(binding.ivMainAppLogo, this);
        LogoLoader.loadLogoInto(binding.ivFooterLogo, this);

        // Safe area padding for status bar, camera hole punch / notch, and navigation bar
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
            );
            v.setPadding(insets.left, insets.top, insets.right, insets.bottom);
            return windowInsets;
        });

        // Responsive max width constraint for tablets and wide foldables
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int maxContentWidth = (int) (680 * getResources().getDisplayMetrics().density);
        if (screenWidth > maxContentWidth && binding.mainContentContainer != null) {
            ViewGroup.LayoutParams lp = binding.mainContentContainer.getLayoutParams();
            if (lp != null) {
                lp.width = maxContentWidth;
                binding.mainContentContainer.setLayoutParams(lp);
            }
        }

        smsStore = new SmsStore(this);
        settingsRepo = SettingsRepository.getInstance(this);
        fbProvider = FirebaseProvider.getInstance(this);
        configManager = FirebaseConfigManager.getInstance(this);

        // Ensure persistent background service is active
        SmsReaderForegroundService.startService(this);

        initLaunchers();
        setupListeners();
        setupTabs();
        setupPages();

        updateActiveProjectUi();
        updateFirebaseStatusUi(fbProvider.getCurrentState());
        updateReaderUidUi(fbProvider.getCurrentUid());

        // Default to bKash tab initially
        selectProvider(Provider.BKASH);

        // Populate initial log
        binding.tvLogConsole.setText(AppLogger.getFullLog());
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Check session protection
        if (!smsStore.isUnlocked()) {
            redirectToPin();
            return;
        }

        fbProvider.addListener(fbStateListener);
        settingsRepo.addListener(settingsListener);
        AppLogger.setListener(logListener);

        IntentFilter filter = new IntentFilter();
        filter.addAction(AppConfig.ACTION_SMS_PROCESSED);
        filter.addAction(AppConfig.ACTION_FIREBASE_STATE_CHANGED);

        ContextCompat.registerReceiver(this, smsBroadcastReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);

        updateReaderStatusUi();
        updateActiveProjectUi();
        clockHandler.post(clockRunnable);
    }

    @Override
    protected void onStop() {
        super.onStop();
        clockHandler.removeCallbacks(clockRunnable);
        try {
            unregisterReceiver(smsBroadcastReceiver);
        } catch (Exception ignored) {}
        fbProvider.removeListener(fbStateListener);
        settingsRepo.removeListener(settingsListener);
        AppLogger.setListener(null);
    }

    private void redirectToPin() {
        Intent intent = new Intent(this, PinActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void initLaunchers() {
        permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    updateReaderStatusUi();
                    Boolean smsGranted = result.get(Manifest.permission.RECEIVE_SMS);
                    if (Boolean.TRUE.equals(smsGranted)) {
                        AppLogger.log("SMS Permission granted.");
                        NotificationHelper.getInstance(this).showActiveNotification();
                        SmsReaderForegroundService.startService(this);
                    } else {
                        AppLogger.error("RECEIVE_SMS permission denied by user.", null);
                    }
                }
        );

        jsonFilePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        importJsonFromUri(uri);
                    }
                }
        );

        logoPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        boolean saved = LogoLoader.saveCustomLogo(MainActivity.this, uri);
                        if (saved) {
                            refreshAllAppLogos();
                            Toast.makeText(MainActivity.this, "✓ App Logo Updated Successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "❌ Failed to update logo", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        photoPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.PickVisualMedia(),
                uri -> {
                    if (uri != null) {
                        boolean saved = LogoLoader.saveCustomLogo(MainActivity.this, uri);
                        if (saved) {
                            refreshAllAppLogos();
                            Toast.makeText(MainActivity.this, "✓ App Logo Updated Successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "❌ Failed to update logo", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        checkAndRequestPermissions();
    }

    private void checkAndRequestPermissions() {
        List<String> neededPermissions = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            neededPermissions.add(Manifest.permission.RECEIVE_SMS);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (!neededPermissions.isEmpty()) {
            permissionLauncher.launch(neededPermissions.toArray(new String[0]));
        }
    }

    private void setupListeners() {
        // App Logo Click Listener (Change/Upload Logo from Gallery)
        binding.ivMainAppLogo.setOnClickListener(v -> promptChangeAppLogo());

        // Developer Facebook Profile Listener
        View.OnClickListener openFacebookListener = v -> {
            try {
                String fbUrl = "https://www.facebook.com/share/1BM4waZmSS/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(fbUrl));
                startActivity(intent);
                AppLogger.log("Opening developer Facebook profile: " + fbUrl);
            } catch (Exception e) {
                Toast.makeText(this, "Could not open Facebook link: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        binding.layoutFooter.setOnClickListener(openFacebookListener);
        binding.tvFooterDeveloper.setOnClickListener(openFacebookListener);

        // Lock button
        binding.btnLock.setOnClickListener(v -> {
            AppLogger.log("Locking application...");
            smsStore.lockSession();
            redirectToPin();
        });

        // Firebase Config Manager buttons
        binding.btnFirebaseConfig.setOnClickListener(v -> {
            AppLogger.log("Opening Firebase Config Manager...");
            showFirebaseConfigDialog();
        });
        binding.btnQuickSwitch.setOnClickListener(v -> {
            AppLogger.log("Opening Firebase Config Manager...");
            showFirebaseConfigDialog();
        });
        binding.btnPhpConfig.setOnClickListener(v -> {
            AppLogger.log("Opening PHP MySQL API Backend Manager...");
            showPhpConfigDialog();
        });

        // Voice Alert Toggle Button
        final TtsHelper ttsHelper = TtsHelper.getInstance(this);
        Runnable updateTtsUi = () -> {
            boolean isEnabled = ttsHelper.isTtsEnabled();
            if (isEnabled) {
                binding.btnVoiceAlertToggle.setImageResource(android.R.drawable.ic_lock_silent_mode_off);
                binding.btnVoiceAlertToggle.setColorFilter(ContextCompat.getColor(this, R.color.status_green));
            } else {
                binding.btnVoiceAlertToggle.setImageResource(android.R.drawable.ic_lock_silent_mode);
                binding.btnVoiceAlertToggle.setColorFilter(ContextCompat.getColor(this, R.color.status_red));
            }
        };
        updateTtsUi.run();

        binding.btnVoiceAlertToggle.setOnClickListener(v -> {
            boolean newState = !ttsHelper.isTtsEnabled();
            ttsHelper.setTtsEnabled(newState);
            updateTtsUi.run();
            if (newState) {
                Toast.makeText(this, "📢 Voice Alert ENABLED", Toast.LENGTH_SHORT).show();
                ttsHelper.speakText("Voice alert enabled");
            } else {
                Toast.makeText(this, "🔇 Voice Alert DISABLED (Muted)", Toast.LENGTH_SHORT).show();
            }
        });

        // Background Reliability Button
        binding.btnReliability.setOnClickListener(v -> {
            AppLogger.log("Opening Background Reliability guide...");
            showBackgroundReliabilityDialog();
        });

        // Copy UID when tapped
        View.OnClickListener copyUidListener = v -> {
            String uid = fbProvider.getCurrentUid();
            if (uid != null && !uid.isEmpty()) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Reader UID", uid);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "Reader UID copied to clipboard", Toast.LENGTH_SHORT).show();
                AppLogger.log("Copied Reader UID: " + uid);
            }
        };
        binding.layoutReaderUid.setOnClickListener(copyUidListener);
        binding.tvReaderUid.setOnClickListener(copyUidListener);

        // Copy TrxID when tapped
        View.OnClickListener copyTxidListener = v -> {
            String txid = binding.tvParsedTxid.getText() != null ? binding.tvParsedTxid.getText().toString().trim() : "";
            if (!txid.isEmpty() && !txid.equals("—")) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("TrxID", txid);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "TrxID " + txid + " copied", Toast.LENGTH_SHORT).show();
                AppLogger.log("Copied TrxID: " + txid);
            }
        };
        binding.layoutParsedTxid.setOnClickListener(copyTxidListener);
        binding.tvParsedTxid.setOnClickListener(copyTxidListener);

        // Manual Retry / Add to Firebase button
        binding.btnRetryFirebase.setOnClickListener(v -> {
            AppLogger.log("ADD / RETRY button clicked");
            onRetryAddClicked();
        });

        // Test Firebase button
        binding.btnTestFirebase.setOnClickListener(v -> {
            AppLogger.log("TEST FIREBASE button clicked");
            onTestFirebaseClicked();
        });

        // Clear Log button
        binding.btnClearLog.setOnClickListener(v -> {
            AppLogger.clear();
            binding.tvLogConsole.setText("");
        });

        // Terminal Card click listener
        binding.cardTerminalStatus.setOnClickListener(v -> {
            if (BackendManager.getInstance(this).isPhpMode()) {
                selectNavTab(2);
            } else {
                selectNavTab(1);
            }
        });

        // View All Transactions click listener
        binding.tvViewAllTxn.setOnClickListener(v -> {
            showAllTransactionsDialog();
        });

        // Bottom Navigation Tabs
        binding.navTabHome.setOnClickListener(v -> selectNavTab(0));
        binding.navTabFirebase.setOnClickListener(v -> selectNavTab(1));
        binding.navTabPhp.setOnClickListener(v -> selectNavTab(2));
        binding.navTabSettings.setOnClickListener(v -> selectNavTab(3));
    }

    private void setupPages() {
        homeFragment = new HomeFragment();
        firebaseFragment = new FirebaseFragment();
        phpFragment = new PhpFragment();
        settingsFragment = new SettingsFragment();

        getSupportFragmentManager().beginTransaction()
                .add(R.id.pageContainer, settingsFragment, "4").hide(settingsFragment)
                .add(R.id.pageContainer, phpFragment, "3").hide(phpFragment)
                .add(R.id.pageContainer, firebaseFragment, "2").hide(firebaseFragment)
                .add(R.id.pageContainer, homeFragment, "1")
                .commitAllowingStateLoss();

        activeFragment = homeFragment;
    }

    private ObjectAnimator indicatorAnimator;
    private int currentTabIndex = 0;

    private void updateNavIndicatorPosition(int tabIndex, boolean animate) {
        if (binding == null || binding.bottomNavContainer == null || binding.navActiveIndicator == null) return;

        binding.bottomNavContainer.post(() -> {
            if (binding == null || binding.bottomNavContainer == null) return;
            int totalWidth = binding.bottomNavContainer.getWidth();
            if (totalWidth <= 0) return;

            int paddingOffset = (int) (10 * getResources().getDisplayMetrics().density);
            int availableWidth = totalWidth - (paddingOffset * 2);
            int tabWidth = availableWidth / 4;
            if (tabWidth <= 0) tabWidth = totalWidth / 4;

            ViewGroup.LayoutParams lp = binding.navActiveIndicator.getLayoutParams();
            if (lp != null && lp.width != tabWidth) {
                lp.width = tabWidth;
                binding.navActiveIndicator.setLayoutParams(lp);
            }

            float targetX = paddingOffset + (tabIndex * tabWidth);

            if (indicatorAnimator != null && indicatorAnimator.isRunning()) {
                indicatorAnimator.cancel();
            }

            if (animate) {
                indicatorAnimator = ObjectAnimator.ofFloat(binding.navActiveIndicator, View.TRANSLATION_X, binding.navActiveIndicator.getTranslationX(), targetX);
                indicatorAnimator.setDuration(180); // Exact 180ms Active Indicator Glide
                indicatorAnimator.setInterpolator(new DecelerateInterpolator()); // Ease-Out Curve
                indicatorAnimator.start();
            } else {
                binding.navActiveIndicator.setTranslationX(targetX);
            }
        });
    }

    public void selectNavTab(int tabIndex) {
        if (binding == null) return;
        if (currentTabIndex == tabIndex && activeFragment != null && activeFragment.isVisible()) return;

        int themeColor = ThemeManager.getInstance(this).getPrimaryColor();

        // 1. Instantly update active tab label color so active icon ALWAYS matches latest selection
        binding.tvNavLabelHome.setTextColor(tabIndex == 0 ? themeColor : Color.parseColor("#94A3B8"));
        binding.tvNavLabelFirebase.setTextColor(tabIndex == 1 ? themeColor : Color.parseColor("#94A3B8"));
        binding.tvNavLabelPhp.setTextColor(tabIndex == 2 ? themeColor : Color.parseColor("#94A3B8"));
        binding.tvNavLabelSettings.setTextColor(tabIndex == 3 ? themeColor : Color.parseColor("#94A3B8"));

        // 2. Animate Active Indicator Pill Gliding horizontally (180ms Ease-Out)
        updateNavIndicatorPosition(tabIndex, true);

        // 3. Instant 0ms Page Switch (No page slide/fade/zoom/scale)
        Fragment targetFragment = homeFragment;
        if (tabIndex == 1) targetFragment = firebaseFragment;
        else if (tabIndex == 2) targetFragment = phpFragment;
        else if (tabIndex == 3) targetFragment = settingsFragment;

        if (targetFragment != null && activeFragment != targetFragment) {
            getSupportFragmentManager().beginTransaction()
                    .hide(activeFragment)
                    .show(targetFragment)
                    .commitAllowingStateLoss();

            activeFragment = targetFragment;
            currentTabIndex = tabIndex;
        }
    }

    public void notifyHomeDashboardUpdated() {
        runOnUiThread(() -> {
            if (homeFragment != null && homeFragment.isAdded()) {
                homeFragment.updateDashboardUi();
            }
            if (firebaseFragment != null && firebaseFragment.isAdded()) {
                firebaseFragment.updateUi();
            }
            if (phpFragment != null && phpFragment.isAdded()) {
                phpFragment.updateUi();
            }
            if (settingsFragment != null && settingsFragment.isAdded()) {
                settingsFragment.updateUi();
            }
            updateActiveProjectUi();
        });
    }

    private void setupTabs() {
        View.OnClickListener bkashClick = v -> selectProvider(Provider.BKASH);
        binding.tabBkash.setOnClickListener(bkashClick);
        binding.ivBkashLogo.setOnClickListener(bkashClick);
        binding.tvBkashLabel.setOnClickListener(bkashClick);

        View.OnClickListener nagadClick = v -> selectProvider(Provider.NAGAD);
        binding.tabNagad.setOnClickListener(nagadClick);
        binding.ivNagadLogo.setOnClickListener(nagadClick);
        binding.tvNagadLabel.setOnClickListener(nagadClick);

        View.OnClickListener rocketClick = v -> selectProvider(Provider.ROCKET);
        binding.tabRocket.setOnClickListener(rocketClick);
        binding.ivRocketLogo.setOnClickListener(rocketClick);
        binding.tvRocketLabel.setOnClickListener(rocketClick);

        View.OnClickListener upayClick = v -> selectProvider(Provider.UPAY);
        binding.tabUpay.setOnClickListener(upayClick);
        binding.ivUpayLogo.setOnClickListener(upayClick);
        binding.tvUpayLabel.setOnClickListener(upayClick);
    }

    private void selectProvider(@NonNull Provider provider) {
        this.selectedProvider = provider;
        AppLogger.log("Selected tab: " + provider.getDisplayName());

        // Visual Tab Highlighting
        binding.tabBkash.setBackgroundResource(provider == Provider.BKASH ?
                R.drawable.bg_tab_bkash_selected : R.drawable.bg_tab_unselected);
        binding.tvBkashLabel.setTextColor(ContextCompat.getColor(this,
                provider == Provider.BKASH ? R.color.color_bkash : R.color.text_secondary));

        binding.tabNagad.setBackgroundResource(provider == Provider.NAGAD ?
                R.drawable.bg_tab_nagad_selected : R.drawable.bg_tab_unselected);
        binding.tvNagadLabel.setTextColor(ContextCompat.getColor(this,
                provider == Provider.NAGAD ? R.color.color_nagad : R.color.text_secondary));

        binding.tabRocket.setBackgroundResource(provider == Provider.ROCKET ?
                R.drawable.bg_tab_rocket_selected : R.drawable.bg_tab_unselected);
        binding.tvRocketLabel.setTextColor(ContextCompat.getColor(this,
                provider == Provider.ROCKET ? R.color.color_rocket : R.color.text_secondary));

        binding.tabUpay.setBackgroundResource(provider == Provider.UPAY ?
                R.drawable.bg_tab_upay_selected : R.drawable.bg_tab_unselected);
        binding.tvUpayLabel.setTextColor(ContextCompat.getColor(this,
                provider == Provider.UPAY ? R.color.color_upay : R.color.text_secondary));

        updateAdminNumberUi();
        updateSmsAndParsedUi();
    }

    public void updateActiveProjectUi() {
        if (binding == null) return;

        boolean isPhp = BackendManager.getInstance(this).isPhpMode();
        boolean isPhpConnected = isPhp && PhpConfigManager.getInstance(this).isConfigured();
        
        FirebaseConfig active = configManager.getActiveConfig();
        boolean isFbConnected = !isPhp && active != null && active.isValid() && !"DEFAULT_DELETED".equals(active.getProjectId());

        boolean isProjectConnected = isPhpConnected || isFbConnected;

        if (isProjectConnected) {
            binding.tvTopActiveBadge.setText("● ACTIVE");
            binding.tvTopActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.status_green));
        } else {
            binding.tvTopActiveBadge.setText("● DISCONNECTED");
            binding.tvTopActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.status_amber));
        }
    }

    private void updateAdminNumberUi() {
        // Managed dynamically in fragment
    }

    private void updateSmsAndParsedUi() {
        // Managed dynamically in fragment
    }

    public void onRetryAddClicked() {
        String rawBody = smsStore.getRawBody(selectedProvider);
        String sender = smsStore.getSender(selectedProvider);
        long timestamp = smsStore.getTimestamp(selectedProvider);

        if (rawBody.isEmpty()) {
            String msg = "No SMS stored for " + selectedProvider.getDisplayName() + ". Listening for new payment SMS...";
            AppLogger.log(msg);
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            return;
        }

        AppLogger.log("Manual upload attempt for " + selectedProvider.getDisplayName());

        PaymentData parsed = PaymentParser.parse(sender, rawBody, timestamp);
        if (parsed == null) {
            String msg = "Parser failed. Firebase add cancelled.";
            AppLogger.error(msg, null);
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            binding.layoutParserFailed.setVisibility(View.VISIBLE);
            return;
        }

        binding.layoutParserFailed.setVisibility(View.GONE);
        Toast.makeText(this, "Uploading to Firebase...", Toast.LENGTH_SHORT).show();

        FirebaseWriter.uploadTransaction(this, parsed, new FirebaseWriter.UploadCallback() {
            @Override
            public void onSuccess(String txid) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Saved: XNXANIKPAY/" + txid, Toast.LENGTH_SHORT).show();
                    updateSmsAndParsedUi();
                });
            }

            @Override
            public void onAlreadyExists(String txid) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Already saved: XNXANIKPAY/" + txid, Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onError(String errorCode, String message) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Upload failed: " + errorCode, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    public void onTestFirebaseClicked() {
        Toast.makeText(this, "Testing Firebase connectivity...", Toast.LENGTH_SHORT).show();
        AppLogger.log("Testing Firebase connection for " + fbProvider.getActiveConfig().getProjectId() + "...");

        fbProvider.testConnection(new FirebaseProvider.TestCallback() {
            @Override
            public void onSuccess(String uid, boolean isConnected) {
                runOnUiThread(() -> {
                    String statusStr = isConnected ? "CONNECTED" : "READY";
                    String info = "Firebase: " + statusStr + " (" + fbProvider.getActiveConfig().getProjectId() + ")\nReader UID: " + uid;
                    AppLogger.log(info.replace("\n", " • "));
                    Toast.makeText(MainActivity.this, info, Toast.LENGTH_LONG).show();
                    updateFirebaseStatusUi(FirebaseProvider.ConnectionState.CONNECTED);
                    updateReaderUidUi(uid);
                });
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    String err = "Firebase Error: " + message;
                    AppLogger.error(err, null);
                    Toast.makeText(MainActivity.this, err, Toast.LENGTH_LONG).show();
                    updateFirebaseStatusUi(FirebaseProvider.ConnectionState.AUTH_ERROR);
                });
            }
        });
    }

    private void updateReaderStatusUi() {
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
                == PackageManager.PERMISSION_GRANTED;
        if (hasPermission) {
            binding.tvReaderStatus.setText(R.string.status_active);
            binding.tvReaderStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
        } else {
            binding.tvReaderStatus.setText(R.string.status_permission_required);
            binding.tvReaderStatus.setTextColor(ContextCompat.getColor(this, R.color.status_red));
        }
    }

    private void updateFirebaseStatusUi(FirebaseProvider.ConnectionState state) {
        if (binding == null) return;

        binding.tvFirebaseStatusLabel.setText(R.string.label_firebase_status); // "Project Status"

        boolean isPhp = BackendManager.getInstance(this).isPhpMode();
        if (isPhp) {
            boolean isConfigured = PhpConfigManager.getInstance(this).isConfigured();
            if (isConfigured) {
                binding.tvFirebaseStatus.setText("PHP Connected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
            } else {
                binding.tvFirebaseStatus.setText("No Project Connected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(this, R.color.status_amber));
            }
        } else {
            FirebaseConfig active = configManager.getActiveConfig();
            boolean isConfigured = (state == FirebaseProvider.ConnectionState.CONNECTED)
                    && active != null && active.isValid() && !"DEFAULT_DELETED".equals(active.getProjectId());

            if (isConfigured) {
                binding.tvFirebaseStatus.setText("Firebase Connected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
            } else {
                binding.tvFirebaseStatus.setText("No Project Connected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(this, R.color.status_amber));
            }
        }
    }

    private void updateReaderUidUi(String uid) {
        if (binding == null) return;
        if (uid != null && !uid.isEmpty()) {
            binding.tvReaderUid.setText(uid);
        } else {
            binding.tvReaderUid.setText("Authenticating…");
        }
    }

    // =========================================================================
    // RUNTIME FIREBASE CONFIG MANAGER BOTTOM SHEET DIALOG
    // =========================================================================

    public void showFirebaseConfigDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_firebase_config, null);
        final BottomSheetDialog sheet = new BottomSheetDialog(this);
        sheet.setContentView(dialogView);
        if (sheet.getBehavior() != null) {
            sheet.getBehavior().setSkipCollapsed(true);
            sheet.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
            sheet.getBehavior().setPeekHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.85));
        }
        ViewCompat.setOnApplyWindowInsetsListener(dialogView, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
            );
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), insets.bottom + (int) (12 * getResources().getDisplayMetrics().density));
            return windowInsets;
        });

        ImageButton btnClose = dialogView.findViewById(R.id.btnCloseDialog);
        ImageView ivConfigLogo = dialogView.findViewById(R.id.ivConfigDialogLogo);
        LogoLoader.loadLogoInto(ivConfigLogo, this);
        TextView tvActiveProjectId = dialogView.findViewById(R.id.tvActiveProjectId);
        TextView tvActiveDbUrl = dialogView.findViewById(R.id.tvActiveDbUrl);
        TextView tvActiveBadge = dialogView.findViewById(R.id.tvActiveBadge);
        Button btnImportJson = dialogView.findViewById(R.id.btnImportJsonFile);
        EditText etRawJson = dialogView.findViewById(R.id.etRawJson);
        EditText etProjectId = dialogView.findViewById(R.id.etProjectId);
        EditText etDatabaseUrl = dialogView.findViewById(R.id.etDatabaseUrl);
        EditText etApiKey = dialogView.findViewById(R.id.etApiKey);
        EditText etAppId = dialogView.findViewById(R.id.etAppId);
        View layoutTestStatus = dialogView.findViewById(R.id.layoutTestStatus);
        ProgressBar progressBar = dialogView.findViewById(R.id.progressBarConfig);
        TextView tvConfigStatus = dialogView.findViewById(R.id.tvConfigStatus);
        Button btnTestAndSwitch = dialogView.findViewById(R.id.btnTestAndSwitch);
        Button btnRollback = dialogView.findViewById(R.id.btnRollback);
        Button btnResetDefault = dialogView.findViewById(R.id.btnResetDefault);
        Button btnPurgeDefault = dialogView.findViewById(R.id.btnPurgeDefaultConfig);
        CheckBox cbPurgeDefault = dialogView.findViewById(R.id.cbPurgeDefaultOnSwitch);
        View layoutPurgeCheckbox = dialogView.findViewById(R.id.layoutPurgeCheckbox);

        currentDialogRawJson = etRawJson;
        currentDialogProjectId = etProjectId;
        currentDialogDatabaseUrl = etDatabaseUrl;
        currentDialogApiKey = etApiKey;
        currentDialogAppId = etAppId;
        currentDialogStatus = tvConfigStatus;
        currentDialogProgress = progressBar;
        currentDialogLayoutTestStatus = layoutTestStatus;
        currentDialogBtnTestAndSwitch = btnTestAndSwitch;
        currentDialogLayoutPurgeCheckbox = layoutPurgeCheckbox;
        currentDialogBtnResetDefault = btnResetDefault;
        currentDialogBtnRollback = btnRollback;
        currentDialogBtnPurgeDefault = btnPurgeDefault;
        currentDialogTvActiveBadge = tvActiveBadge;
        currentDialogTvActiveProjectId = tvActiveProjectId;
        currentDialogTvActiveDbUrl = tvActiveDbUrl;
        currentDialogCbPurgeDefault = cbPurgeDefault;

        // Populate active config
        FirebaseConfig active = configManager.getActiveConfig();
        boolean isConnected = active != null && active.isValid() && !"DEFAULT_DELETED".equals(active.getProjectId());

        if (!isConnected) {
            tvActiveProjectId.setText("No Project Connected");
            tvActiveDbUrl.setText("Import a google-services.json file below");
            tvActiveBadge.setText("NOT CONFIGURED");
            tvActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.status_amber));

            layoutPurgeCheckbox.setVisibility(View.GONE);
            btnResetDefault.setVisibility(View.GONE);
            btnPurgeDefault.setVisibility(View.GONE);
            btnRollback.setVisibility(View.GONE);
        } else {
            tvActiveProjectId.setText(active.getProjectId());
            tvActiveDbUrl.setText(active.getDatabaseUrl());
            tvActiveBadge.setText("CUSTOM");
            tvActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.primary_pink_light));

            layoutPurgeCheckbox.setVisibility(View.GONE);
            btnResetDefault.setVisibility(View.GONE);
            btnPurgeDefault.setVisibility(View.GONE);

            if (configManager.hasRollbackConfig()) {
                FirebaseConfig rollback = configManager.getRollbackConfig();
                btnRollback.setVisibility(View.VISIBLE);
                btnRollback.setText("↩ ROLLBACK TO " + (rollback != null ? rollback.getProjectId() : "PREVIOUS"));
            } else {
                btnRollback.setVisibility(View.GONE);
            }
        }

        // Permanent Delete Default Config Button Listener
        btnPurgeDefault.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Default Firebase Project?")
                    .setMessage("Are you sure you want to permanently delete 'topupbd-9f02e'?\n\nOnce deleted, this app will NEVER connect or send SMS to the previous website, protecting the old user's website.\n\nYou can then import your new google-services.json.")
                    .setPositiveButton("DELETE PERMANENTLY", (dialog, which) -> {
                        configManager.purgeDefaultConfigPermanently();
                        fbProvider.reloadActiveConfig();
                        updateActiveProjectUi();
                        updateFirebaseStatusUi(fbProvider.getCurrentState());
                        updateReaderUidUi(fbProvider.getCurrentUid());

                        layoutPurgeCheckbox.setVisibility(View.GONE);
                        btnResetDefault.setVisibility(View.GONE);
                        btnRollback.setVisibility(View.GONE);
                        btnPurgeDefault.setEnabled(false);
                        btnPurgeDefault.setText("✓ DEFAULT (topupbd-9f02e) PERMANENTLY PURGED");
                        btnPurgeDefault.setTextColor(ContextCompat.getColor(this, R.color.status_green));

                        FirebaseConfig newActive = configManager.getActiveConfig();
                        tvActiveProjectId.setText(newActive.getProjectId());
                        tvActiveDbUrl.setText(newActive.getDatabaseUrl().isEmpty() ? "None (Import google-services.json)" : newActive.getDatabaseUrl());
                        tvActiveBadge.setText("DEFAULT DELETED");
                        tvActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.status_red));

                        layoutTestStatus.setVisibility(View.VISIBLE);
                        tvConfigStatus.setText("✓ Default Firebase (topupbd-9f02e) has been permanently purged.\nNo SMS data will ever go to the previous website.");
                        tvConfigStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));

                        Toast.makeText(this, "Default Firebase deleted permanently", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("CANCEL", null)
                    .show();
        });

        btnClose.setOnClickListener(v -> sheet.dismiss());

        // File import launcher
        btnImportJson.setOnClickListener(v -> {
            try {
                jsonFilePickerLauncher.launch("*/*");
            } catch (Exception e) {
                Toast.makeText(this, "Could not open file picker: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // Auto-extract when user pastes json into etRawJson
        etRawJson.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                String text = s != null ? s.toString().trim() : "";
                if (text.startsWith("{") && text.contains("project_info")) {
                    try {
                        FirebaseConfig parsed = configManager.parseGoogleServicesJson(text);
                        etProjectId.setText(parsed.getProjectId());
                        etDatabaseUrl.setText(parsed.getDatabaseUrl());
                        etApiKey.setText(parsed.getApiKey());
                        etAppId.setText(parsed.getApplicationId());
                        layoutTestStatus.setVisibility(View.VISIBLE);
                        tvConfigStatus.setText("✓ google-services.json parsed successfully. Ready to test & switch.");
                        tvConfigStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_green));
                        promptPurgeNoticeAfterAutoFill(parsed);
                    } catch (Exception ignored) {}
                }
            }
        });

        // Test and Switch action
        btnTestAndSwitch.setOnClickListener(v -> {
            String pId = etProjectId.getText().toString().trim();
            String dbUrl = etDatabaseUrl.getText().toString().trim();
            String apiKey = etApiKey.getText().toString().trim();
            String appId = etAppId.getText().toString().trim();

            if (pId.isEmpty() || dbUrl.isEmpty() || apiKey.isEmpty() || appId.isEmpty()) {
                layoutTestStatus.setVisibility(View.VISIBLE);
                tvConfigStatus.setText("Please fill all 4 required fields or import google-services.json");
                tvConfigStatus.setTextColor(ContextCompat.getColor(this, R.color.status_red));
                return;
            }

            FirebaseConfig candidate = new FirebaseConfig(
                    pId, appId, apiKey, dbUrl,
                    pId + ".firebasestorage.app", "",
                    "Custom (" + pId + ")", false
            );

            boolean shouldPurgeDefault = cbPurgeDefault != null && cbPurgeDefault.isChecked();
            triggerSwitchCandidate(candidate, shouldPurgeDefault);
        });

        // Rollback action
        btnRollback.setOnClickListener(v -> {
            layoutTestStatus.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);
            btnRollback.setEnabled(false);

            configManager.rollbackToPreviousConfig(new FirebaseConfigManager.SwitchCallback() {
                @Override
                public void onProgress(String status) {
                    runOnUiThread(() -> tvConfigStatus.setText(status));
                }

                @Override
                public void onSuccess(FirebaseConfig newConfig) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        btnRollback.setEnabled(true);
                        tvConfigStatus.setText("✓ Rolled back to " + newConfig.getProjectId());
                        tvConfigStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_green));

                        updateActiveProjectUi();
                        updateFirebaseStatusUi(fbProvider.getCurrentState());
                        updateReaderUidUi(fbProvider.getCurrentUid());
                    });
                }

                @Override
                public void onError(String errorMessage) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        btnRollback.setEnabled(true);
                        tvConfigStatus.setText("❌ Rollback failed: " + errorMessage);
                        tvConfigStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_red));
                    });
                }
            });
        });

        // Reset to Default action
        btnResetDefault.setOnClickListener(v -> {
            layoutTestStatus.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);

            configManager.resetToDefaultConfig(new FirebaseConfigManager.SwitchCallback() {
                @Override
                public void onProgress(String status) {
                    runOnUiThread(() -> tvConfigStatus.setText(status));
                }

                @Override
                public void onSuccess(FirebaseConfig newConfig) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        tvConfigStatus.setText("✓ Reset to packaged default: " + newConfig.getProjectId());
                        tvConfigStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_green));

                        updateActiveProjectUi();
                        updateFirebaseStatusUi(fbProvider.getCurrentState());
                        updateReaderUidUi(fbProvider.getCurrentUid());
                    });
                }

                @Override
                public void onError(String errorMessage) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        tvConfigStatus.setText("❌ Reset failed: " + errorMessage);
                        tvConfigStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_red));
                    });
                }
            });
        });

        sheet.show();
    }

    private void importJsonFromUri(Uri uri) {
        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            String content = sb.toString();
            FirebaseConfig parsed = configManager.parseGoogleServicesJson(content);

            if (currentDialogRawJson != null) currentDialogRawJson.setText(content);
            if (currentDialogProjectId != null) currentDialogProjectId.setText(parsed.getProjectId());
            if (currentDialogDatabaseUrl != null) currentDialogDatabaseUrl.setText(parsed.getDatabaseUrl());
            if (currentDialogApiKey != null) currentDialogApiKey.setText(parsed.getApiKey());
            if (currentDialogAppId != null) currentDialogAppId.setText(parsed.getApplicationId());

            if (currentDialogStatus != null) {
                currentDialogStatus.setText("✓ File loaded: " + parsed.getProjectId() + "\nAuto-filled! Default project will be deleted on switch.");
                currentDialogStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
            }

            Toast.makeText(this, "Loaded " + parsed.getProjectId(), Toast.LENGTH_SHORT).show();
            promptPurgeNoticeAfterAutoFill(parsed);

        } catch (Exception e) {
            AppLogger.error("Failed to parse imported json file: " + e.getMessage(), e);
            if (currentDialogStatus != null) {
                currentDialogStatus.setText("Failed to parse json file: " + e.getMessage());
                currentDialogStatus.setTextColor(ContextCompat.getColor(this, R.color.status_red));
            }
            Toast.makeText(this, "Failed to parse json file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void triggerSwitchCandidate(final FirebaseConfig candidate, final boolean shouldPurgeDefault) {
        if (currentDialogLayoutTestStatus != null) currentDialogLayoutTestStatus.setVisibility(View.VISIBLE);
        if (currentDialogProgress != null) currentDialogProgress.setVisibility(View.VISIBLE);
        if (currentDialogStatus != null) {
            currentDialogStatus.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
            currentDialogStatus.setText("Testing connection to " + candidate.getProjectId() + "...");
        }
        if (currentDialogBtnTestAndSwitch != null) currentDialogBtnTestAndSwitch.setEnabled(false);

        configManager.testAndSwitchConfig(candidate, shouldPurgeDefault, new FirebaseConfigManager.SwitchCallback() {
            @Override
            public void onProgress(String status) {
                runOnUiThread(() -> {
                    if (currentDialogStatus != null) currentDialogStatus.setText(status);
                });
            }

            @Override
            public void onSuccess(FirebaseConfig newConfig) {
                runOnUiThread(() -> {
                    if (currentDialogProgress != null) currentDialogProgress.setVisibility(View.GONE);
                    if (currentDialogBtnTestAndSwitch != null) currentDialogBtnTestAndSwitch.setEnabled(true);

                    if (configManager.isDefaultPurged()) {
                        if (currentDialogLayoutPurgeCheckbox != null) currentDialogLayoutPurgeCheckbox.setVisibility(View.GONE);
                        if (currentDialogBtnResetDefault != null) currentDialogBtnResetDefault.setVisibility(View.GONE);
                        if (currentDialogBtnRollback != null) currentDialogBtnRollback.setVisibility(View.GONE);
                        if (currentDialogBtnPurgeDefault != null) {
                            currentDialogBtnPurgeDefault.setEnabled(false);
                            currentDialogBtnPurgeDefault.setText("✓ DEFAULT (topupbd-9f02e) PERMANENTLY PURGED");
                            currentDialogBtnPurgeDefault.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_green));
                        }
                        if (currentDialogTvActiveBadge != null) {
                            currentDialogTvActiveBadge.setText("CUSTOM (SECURE)");
                            currentDialogTvActiveBadge.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.primary_pink_light));
                        }
                    }

                    if (currentDialogTvActiveProjectId != null) currentDialogTvActiveProjectId.setText(newConfig.getProjectId());
                    if (currentDialogTvActiveDbUrl != null) currentDialogTvActiveDbUrl.setText(newConfig.getDatabaseUrl());
                    if (currentDialogStatus != null) {
                        currentDialogStatus.setText("✓ Successfully switched to " + newConfig.getProjectId() + "!\nAll future SMS will sync to this database.");
                        currentDialogStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_green));
                    }

                    // Switch active backend mode to Firebase & refresh Home Page UI instantly
                    BackendManager.getInstance(MainActivity.this).setBackendMode(BackendManager.BackendMode.FIREBASE);
                    updateActiveProjectUi();
                    updateFirebaseStatusUi(fbProvider.getCurrentState());
                    updateAdminNumberUi();
                    updateReaderUidUi(fbProvider.getCurrentUid());

                    Toast.makeText(MainActivity.this, "Switched to " + newConfig.getProjectId(), Toast.LENGTH_LONG).show();

                    // Pop up notice confirming switch and deletion of old default
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("✓ Firebase Switched & Secured!")
                            .setMessage("Successfully connected to:\n👉 " + newConfig.getProjectId() + "\n\n" +
                                    (configManager.isDefaultPurged()
                                            ? "🗑️ Notice: The old default project (topupbd-9f02e) has been permanently deleted from this device.\n\nThe previous website is 100% safe."
                                            : "Active configuration updated."))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    if (currentDialogProgress != null) currentDialogProgress.setVisibility(View.GONE);
                    if (currentDialogBtnTestAndSwitch != null) currentDialogBtnTestAndSwitch.setEnabled(true);
                    if (currentDialogStatus != null) {
                        currentDialogStatus.setText("❌ " + errorMessage + "\nExisting Firebase configuration remains active.");
                        currentDialogStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_red));
                    }
                });
            }
        });
    }

    private void promptPurgeNoticeAfterAutoFill(final FirebaseConfig parsed) {
        if (configManager.isDefaultPurged()) return;

        new AlertDialog.Builder(this)
                .setTitle("⚠️ Auto-Filled! Delete Old Project?")
                .setMessage("google-services.json has been auto-filled for:\n👉 " + parsed.getProjectId() + "\n\nDo you want to permanently delete the old default project (topupbd-9f02e) now to protect the previous website?")
                .setPositiveButton("YES, DELETE OLD & CONNECT", (dialog, which) -> {
                    triggerSwitchCandidate(parsed, true);
                })
                .setNegativeButton("REVIEW FIELDS FIRST", null)
                .show();
    }

    // =========================================================================
    // BACKGROUND RELIABILITY BOTTOM SHEET DIALOG
    // =========================================================================

    public void onTestPhpClicked() {
        PhpConfig config = PhpConfigManager.getInstance(this).getActiveConfig();
        if (config == null || !config.isValid()) {
            Toast.makeText(this, "PHP API Backend is not configured", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Testing PHP API connection...", Toast.LENGTH_SHORT).show();
        PhpWriter.testConnection(this, config.getApiBaseUrl(), config.getDeviceSecret(), new PhpWriter.ApiCallback() {
            @Override
            public void onSuccess(String deviceId, String message) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "PHP API Connected (" + config.getDisplayDomain() + ")", Toast.LENGTH_LONG).show());
            }

            @Override
            public void onAlreadyExists(String deviceId, String message) {
                onSuccess(deviceId, message);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "PHP Error: " + errorMessage, Toast.LENGTH_LONG).show());
            }
        });
    }

    public void showBackgroundReliabilityDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_background_reliability, null);
        final BottomSheetDialog sheet = new BottomSheetDialog(this);
        sheet.setContentView(dialogView);
        if (sheet.getBehavior() != null) {
            sheet.getBehavior().setSkipCollapsed(true);
            sheet.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
        }
        ViewCompat.setOnApplyWindowInsetsListener(dialogView, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
            );
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), insets.bottom + (int) (16 * getResources().getDisplayMetrics().density));
            return windowInsets;
        });

        ImageButton btnClose = dialogView.findViewById(R.id.btnCloseReliabilityDialog);
        ImageView ivReliabilityLogo = dialogView.findViewById(R.id.ivReliabilityDialogLogo);
        LogoLoader.loadLogoInto(ivReliabilityLogo, this);
        TextView tvBatteryOptStatus = dialogView.findViewById(R.id.tvBatteryOptStatus);
        Button btnDisableBatteryOpt = dialogView.findViewById(R.id.btnDisableBatteryOpt);
        TextView tvOemInstructions = dialogView.findViewById(R.id.tvOemInstructions);
        Button btnOpenOemSettings = dialogView.findViewById(R.id.btnOpenOemSettings);
        Button btnDone = dialogView.findViewById(R.id.btnCloseReliability);

        boolean isIgnored = BackgroundReliabilityHelper.isBatteryOptimizationIgnored(this);
        if (isIgnored) {
            tvBatteryOptStatus.setText("EXEMPTED / UNRESTRICTED (OK)");
            tvBatteryOptStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
            btnDisableBatteryOpt.setEnabled(false);
            btnDisableBatteryOpt.setText("BATTERY OPTIMIZATION ALREADY DISABLED");
        } else {
            tvBatteryOptStatus.setText("RESTRICTED (ACTION NEEDED)");
            tvBatteryOptStatus.setTextColor(ContextCompat.getColor(this, R.color.status_amber));
        }

        tvOemInstructions.setText(BackgroundReliabilityHelper.getOemGuidance());

        btnDisableBatteryOpt.setOnClickListener(v -> {
            BackgroundReliabilityHelper.requestIgnoreBatteryOptimization(this);
            sheet.dismiss();
        });

        btnOpenOemSettings.setOnClickListener(v -> {
            BackgroundReliabilityHelper.openOemAutoStartSettings(this);
            sheet.dismiss();
        });

        btnClose.setOnClickListener(v -> sheet.dismiss());
        btnDone.setOnClickListener(v -> sheet.dismiss());

        sheet.show();
    }

    // =========================================================================
    // PHP MYSQL API BACKEND BOTTOM SHEET DIALOG
    // =========================================================================

    public void showPhpConfigDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_php_config, null);
        final BottomSheetDialog sheet = new BottomSheetDialog(this);
        sheet.setContentView(dialogView);
        if (sheet.getBehavior() != null) {
            sheet.getBehavior().setSkipCollapsed(true);
            sheet.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
            sheet.getBehavior().setPeekHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.85));
        }
        ViewCompat.setOnApplyWindowInsetsListener(dialogView, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
            );
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), insets.bottom + (int) (12 * getResources().getDisplayMetrics().density));
            return windowInsets;
        });

        ImageButton btnClose = dialogView.findViewById(R.id.btnClosePhpDialog);
        ImageView ivLogo = dialogView.findViewById(R.id.ivPhpDialogLogo);
        LogoLoader.loadLogoInto(ivLogo, this);

        TextView tvActiveBadge = dialogView.findViewById(R.id.tvActiveBackendBadge);
        TextView tvActiveUrl = dialogView.findViewById(R.id.tvActivePhpUrl);
        TextView tvDeviceId = dialogView.findViewById(R.id.tvDeviceId);
        View layoutDeviceId = dialogView.findViewById(R.id.layoutDeviceIdContainer);
        ImageButton ibCopyDeviceId = dialogView.findViewById(R.id.ibCopyDeviceId);

        EditText etUrl = dialogView.findViewById(R.id.etPhpApiUrl);
        EditText etSecret = dialogView.findViewById(R.id.etDeviceSecret);

        View layoutStatus = dialogView.findViewById(R.id.layoutPhpTestStatus);
        ProgressBar progressBar = dialogView.findViewById(R.id.progressBarPhp);
        TextView tvStatus = dialogView.findViewById(R.id.tvPhpStatus);

        Button btnTestAndActivate = dialogView.findViewById(R.id.btnTestAndActivatePhp);
        Button btnSwitchToFirebase = dialogView.findViewById(R.id.btnSwitchToFirebase);

        // Populate values
        final BackendManager backendMgr = BackendManager.getInstance(this);
        final PhpConfigManager phpCfgMgr = PhpConfigManager.getInstance(this);

        Runnable updateUiState = () -> {
            BackendManager.BackendMode activeMode = backendMgr.getActiveMode();
            tvActiveBadge.setText(activeMode.getDisplayName());
            if (activeMode == BackendManager.BackendMode.PHP_MYSQL) {
                tvActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.status_green));
            } else {
                tvActiveBadge.setTextColor(ContextCompat.getColor(this, R.color.status_amber));
            }

            PhpConfig config = phpCfgMgr.getActiveConfig();
            if (config != null) {
                tvActiveUrl.setText(config.getApiBaseUrl());
                etUrl.setText(config.getApiBaseUrl());
                etSecret.setText(config.getDeviceSecret());
                tvDeviceId.setText("Device ID: " + config.getDeviceId());
            } else {
                tvActiveUrl.setText("Not configured");
                tvDeviceId.setText("Device ID: " + phpCfgMgr.getOrCreateDeviceId());
            }
        };

        updateUiState.run();

        View.OnClickListener copyDeviceIdListener = v -> {
            String fullDeviceId = phpCfgMgr.getOrCreateDeviceId();
            if (fullDeviceId != null && !fullDeviceId.trim().isEmpty()) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Device ID", fullDeviceId);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(this, "Device ID Copied Successfully!", Toast.LENGTH_SHORT).show();
                    AppLogger.log("Copied Device ID: " + fullDeviceId);
                }
            }
        };

        if (ibCopyDeviceId != null) ibCopyDeviceId.setOnClickListener(copyDeviceIdListener);
        if (layoutDeviceId != null) layoutDeviceId.setOnClickListener(copyDeviceIdListener);

        btnTestAndActivate.setOnClickListener(v -> {
            String url = etUrl.getText().toString().trim();
            String secret = etSecret.getText().toString().trim();

            if (url.isEmpty() || secret.isEmpty()) {
                Toast.makeText(this, "Please enter API URL and Device Secret", Toast.LENGTH_SHORT).show();
                return;
            }

            layoutStatus.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);
            tvStatus.setText("Testing connection to PHP API...");
            tvStatus.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
            btnTestAndActivate.setEnabled(false);

            PhpWriter.testConnection(this, url, secret, new PhpWriter.ApiCallback() {
                @Override
                public void onSuccess(String deviceId, String message) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        btnTestAndActivate.setEnabled(true);
                        tvStatus.setText("✓ " + message + "\nPHP API connection verified!");
                        tvStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_green));

                        phpCfgMgr.saveConfig(url, secret);
                        backendMgr.setBackendMode(BackendManager.BackendMode.PHP_MYSQL);
                        updateUiState.run();

                        // Refresh Home Screen UI immediately
                        updateActiveProjectUi();
                        updateFirebaseStatusUi(fbProvider.getCurrentState());
                        updateAdminNumberUi();

                        Toast.makeText(MainActivity.this, "PHP MySQL Mode Activated!", Toast.LENGTH_SHORT).show();
                    });
                }

                @Override
                public void onAlreadyExists(String txid, String message) {
                    onSuccess(txid, message);
                }

                @Override
                public void onError(String errorCode, String errorMessage) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        btnTestAndActivate.setEnabled(true);
                        tvStatus.setText("❌ Error: " + errorMessage);
                        tvStatus.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.status_red));
                    });
                }
            });
        });

        btnSwitchToFirebase.setOnClickListener(v -> {
            backendMgr.setBackendMode(BackendManager.BackendMode.FIREBASE);
            updateUiState.run();

            // Refresh Home Screen UI immediately
            updateActiveProjectUi();
            updateFirebaseStatusUi(fbProvider.getCurrentState());
            updateAdminNumberUi();

            Toast.makeText(this, "Switched to Firebase Mode", Toast.LENGTH_SHORT).show();
        });

        if (btnClose != null) btnClose.setOnClickListener(v -> sheet.dismiss());
        sheet.show();
    }

    // =========================================================================
    // SETTINGS FUNCTION & THEME PICKER DIALOG (MATCHING SCREENSHOTS)
    // =========================================================================

    public void showSettingsDialog() {
        final BottomSheetDialog sheet = new BottomSheetDialog(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.parseColor("#0F172A"));
        container.setPadding(40, 40, 40, 60);

        // Header: Settings
        TextView tvTitle = new TextView(this);
        tvTitle.setText("⚙️ Settings");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, Typeface.BOLD);
        container.addView(tvTitle);

        boolean isPhp = BackendManager.getInstance(this).isPhpMode();

        // 1. Active Backend Item
        TextView tvBackend = createSettingsItem(this, "Active Backend", isPhp ? "🐬 PHP MySQL Connected" : "🔥 Firebase Connected");
        container.addView(tvBackend);

        // 2. Reader UID Item
        TextView tvUid = createSettingsItem(this, "SMS Reader UID", fbProvider.getCurrentUid());
        tvUid.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Reader UID", fbProvider.getCurrentUid());
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Reader UID copied", Toast.LENGTH_SHORT).show();
        });
        container.addView(tvUid);

        // 3. Project Switch Item
        TextView tvProjectSwitch = createSettingsItem(this, "Project Switch", "Manage project connection");
        tvProjectSwitch.setOnClickListener(v -> {
            sheet.dismiss();
            if (isPhp) showPhpConfigDialog(); else showFirebaseConfigDialog();
        });
        container.addView(tvProjectSwitch);

        // 4. App UI Color Customizer Item
        TextView tvTheme = createSettingsItem(this, "🎨 App UI Color", "Choose App Theme Color (" + ThemeManager.getInstance(this).getThemeName() + ")");
        tvTheme.setOnClickListener(v -> {
            sheet.dismiss();
            showThemePickerDialog();
        });
        container.addView(tvTheme);

        // 5. Switch Backend Card
        Button btnSwitchMode = new Button(this);
        btnSwitchMode.setText(isPhp ? "⇄ Switch to Firebase Project" : "⇄ Switch to PHP MySQL Project");
        btnSwitchMode.setTextColor(Color.WHITE);
        btnSwitchMode.setBackgroundResource(R.drawable.bg_button_primary);
        LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 120);
        lpBtn.setMargins(0, 30, 0, 10);
        btnSwitchMode.setLayoutParams(lpBtn);
        btnSwitchMode.setOnClickListener(v -> {
            sheet.dismiss();
            if (isPhp) {
                BackendManager.getInstance(this).setBackendMode(BackendManager.BackendMode.FIREBASE);
                Toast.makeText(this, "Switched to Firebase Mode", Toast.LENGTH_SHORT).show();
            } else {
                BackendManager.getInstance(this).setBackendMode(BackendManager.BackendMode.PHP_MYSQL);
                Toast.makeText(this, "Switched to PHP MySQL Mode", Toast.LENGTH_SHORT).show();
            }
            updateActiveProjectUi();
            updateFirebaseStatusUi(fbProvider.getCurrentState());
            updateAdminNumberUi();
        });
        container.addView(btnSwitchMode);

        sheet.setContentView(container);
        sheet.show();
    }

    public void applyCurrentThemeUi() {
        if (binding == null) return;
        int themeColor = ThemeManager.getInstance(this).getPrimaryColor();

        try {
            binding.btnRetryFirebase.setBackgroundTintList(ColorStateList.valueOf(themeColor));
            binding.tvViewAllTxn.setTextColor(themeColor);
            binding.tvFooterDeveloper.setTextColor(themeColor);
            binding.navTabHome.setBackgroundTintList(ColorStateList.valueOf(themeColor));
        } catch (Exception ignored) {}
    }

    private void showThemePickerDialog() {
        final BottomSheetDialog sheet = new BottomSheetDialog(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.parseColor("#0F172A"));
        container.setPadding(40, 40, 40, 60);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("🎨 Choose App Theme Color");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, Typeface.BOLD);
        container.addView(tvTitle);

        TextView tvSubtitle = new TextView(this);
        tvSubtitle.setText("Select a theme preset or enter custom Hex code below:");
        tvSubtitle.setTextColor(Color.parseColor("#94A3B8"));
        tvSubtitle.setTextSize(12);
        tvSubtitle.setPadding(0, 10, 0, 16);
        container.addView(tvSubtitle);

        // 10 Color Swatch Grid (2 Columns)
        String[][] presets = new String[][]{
                {ThemeManager.THEME_PURPLE, "#7C3AED"},
                {ThemeManager.THEME_BLUE, "#2563EB"},
                {ThemeManager.THEME_GREEN, "#16A34A"},
                {ThemeManager.THEME_ORANGE, "#EA580C"},
                {ThemeManager.THEME_RED, "#DC2626"},
                {ThemeManager.THEME_PINK, "#EC4899"},
                {ThemeManager.THEME_TEAL, "#0D9488"},
                {ThemeManager.THEME_INDIGO, "#4F46E5"},
                {ThemeManager.THEME_CYAN, "#06B6D4"},
                {ThemeManager.THEME_DARK, "#1E293B"}
        };

        final String currentHex = ThemeManager.getInstance(this).getPrimaryColorHex();

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < presets.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 6, 0, 6);

            for (int j = i; j < i + 2 && j < presets.length; j++) {
                final String pName = presets[j][0];
                final String pHex = presets[j][1];

                Button btn = new Button(this);
                boolean isSel = pHex.equalsIgnoreCase(currentHex);
                btn.setText((isSel ? "✔ " : "") + pName);
                btn.setTextColor(Color.WHITE);
                btn.setTextSize(13);
                btn.setBackgroundColor(Color.parseColor(pHex));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 110, 1.0f);
                lp.setMargins(6, 0, 6, 0);
                btn.setLayoutParams(lp);

                btn.setOnClickListener(v -> {
                    ThemeManager.getInstance(this).setThemePreset(pName, pHex);
                    applyCurrentThemeUi();
                    Toast.makeText(this, pName + " theme applied!", Toast.LENGTH_SHORT).show();
                    sheet.dismiss();
                });

                row.addView(btn);
            }
            grid.addView(row);
        }
        container.addView(grid);

        // Custom Hex Code Input Section
        TextView tvHexLabel = new TextView(this);
        tvHexLabel.setText("Custom Hex Color Code (e.g. #E2136E):");
        tvHexLabel.setTextColor(Color.parseColor("#94A3B8"));
        tvHexLabel.setTextSize(12);
        tvHexLabel.setPadding(0, 24, 0, 8);
        container.addView(tvHexLabel);

        final EditText etHex = new EditText(this);
        etHex.setText(ThemeManager.getInstance(this).getPrimaryColorHex());
        etHex.setTextColor(Color.WHITE);
        etHex.setHint("#7C3AED");
        etHex.setHintTextColor(Color.parseColor("#64748B"));
        etHex.setBackgroundResource(R.drawable.bg_card_inner);
        etHex.setPadding(30, 20, 30, 20);
        container.addView(etHex);

        // Apply Theme Button
        Button btnApply = new Button(this);
        btnApply.setText("✔ Apply Theme");
        btnApply.setTextColor(Color.WHITE);
        btnApply.setBackgroundResource(R.drawable.bg_button_primary);
        LinearLayout.LayoutParams lpApply = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 120);
        lpApply.setMargins(0, 24, 0, 0);
        btnApply.setLayoutParams(lpApply);

        btnApply.setOnClickListener(v -> {
            String customHex = etHex.getText().toString().trim();
            if (!customHex.isEmpty()) {
                boolean valid = ThemeManager.getInstance(this).setCustomHexColor(customHex);
                if (valid) {
                    applyCurrentThemeUi();
                    Toast.makeText(this, "Custom Theme Applied: " + customHex, Toast.LENGTH_SHORT).show();
                    sheet.dismiss();
                } else {
                    Toast.makeText(this, "Invalid Hex Color! E.g. #7C3AED or #E2136E", Toast.LENGTH_SHORT).show();
                }
            }
        });
        container.addView(btnApply);

        sheet.setContentView(container);
        sheet.show();
    }

    public void onTerminalCardClicked() {
        if (BackendManager.getInstance(this).isPhpMode()) {
            showPhpConfigDialog();
        } else {
            showFirebaseConfigDialog();
        }
    }

    public void showAllTransactionsDialog() {
        final BottomSheetDialog sheet = new BottomSheetDialog(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.parseColor("#0F172A"));
        container.setPadding(40, 40, 40, 60);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("📅 Recent Transactions History");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, Typeface.BOLD);
        container.addView(tvTitle);

        boolean hasTxn = false;

        for (Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
            if (smsStore.isParseSuccess(p)) {
                hasTxn = true;
                String amt = smsStore.getAmount(p);
                String agent = smsStore.getAgent(p);
                String txid = smsStore.getTxid(p);

                TextView tv = new TextView(this);
                tv.setText("• " + p.getDisplayName() + " | From: " + (agent.isEmpty() ? "—" : agent) +
                        "\n  Amount: ৳ " + amt + " | TrxID: " + txid);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(13);
                tv.setPadding(24, 20, 24, 20);
                tv.setBackgroundResource(R.drawable.bg_card_inner);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 14, 0, 0);
                tv.setLayoutParams(lp);

                tv.setOnClickListener(v -> {
                    if (!txid.isEmpty() && !"—".equals(txid)) {
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("TrxID", txid);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(this, "TrxID " + txid + " copied", Toast.LENGTH_SHORT).show();
                    }
                });
                container.addView(tv);
            }
        }

        if (!hasTxn) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("No Transactions Yet\nConnect a project & receive payment SMS");
            tvEmpty.setTextColor(Color.parseColor("#94A3B8"));
            tvEmpty.setTextSize(13);
            tvEmpty.setPadding(0, 40, 0, 40);
            tvEmpty.setGravity(Gravity.CENTER);
            container.addView(tvEmpty);
        }

        sheet.setContentView(container);
        sheet.show();
    }

    private TextView createSettingsItem(Context ctx, String title, String subtitle) {
        TextView tv = new TextView(ctx);
        tv.setText(title + "\n" + subtitle);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setPadding(30, 24, 30, 24);
        tv.setBackgroundResource(R.drawable.bg_card_inner);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 16, 0, 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    // =========================================================================
    // DYNAMIC APP LOGO CUSTOMIZER (UPLOAD FROM GALLERY)
    // =========================================================================

    private void promptChangeAppLogo() {
        boolean hasCustom = LogoLoader.hasCustomUploadedLogo(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("🖼️ App Logo Customizer")
                .setMessage("Select a custom logo image from your phone gallery to update the app logo across all screens.")
                .setPositiveButton("📷 CHOOSE FROM GALLERY", (dialog, which) -> launchGalleryPicker())
                .setNegativeButton("CANCEL", null);

        if (hasCustom) {
            builder.setNeutralButton("↺ RESET DEFAULT", (dialog, which) -> {
                LogoLoader.resetCustomLogo(this);
                refreshAllAppLogos();
                Toast.makeText(this, "Reset to default logo", Toast.LENGTH_SHORT).show();
            });
        }

        builder.show();
    }

    private void launchGalleryPicker() {
        try {
            if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(this)) {
                photoPickerLauncher.launch(new PickVisualMediaRequest.Builder()
                        .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                        .build());
            } else {
                logoPickerLauncher.launch("image/*");
            }
        } catch (Exception e) {
            try {
                logoPickerLauncher.launch("image/*");
            } catch (Exception ex) {
                Toast.makeText(this, "Could not open image picker: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void refreshAllAppLogos() {
        LogoLoader.loadLogoInto(binding.ivMainAppLogo, this);
        LogoLoader.loadLogoInto(binding.ivFooterLogo, this);
    }
}

