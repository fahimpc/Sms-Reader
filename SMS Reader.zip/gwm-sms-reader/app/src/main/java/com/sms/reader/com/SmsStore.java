package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Local persistent store for caching the latest received SMS per provider
 * and managing session authentication state.
 */
public final class SmsStore {

    private static final String PREF_NAME = "gwm_sms_store";

    // Keys for Session
    private static final String KEY_IS_UNLOCKED = "session_unlocked";
    private static final String KEY_LAST_UNLOCK_TIME = "last_unlock_time";

    private final SharedPreferences prefs;

    public SmsStore(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Stores full SMS and parsed details separately for each provider.
     */
    public void saveLatestSms(Provider provider, String rawBody, String sender,
                              long timestamp, boolean parseSuccess, PaymentData parsedData) {
        if (provider == null || provider == Provider.UNKNOWN) {
            return;
        }

        String prefix = provider.name() + "_";
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(prefix + "raw_body", rawBody != null ? rawBody : "");
        editor.putString(prefix + "sender", sender != null ? sender : "");
        editor.putLong(prefix + "timestamp", timestamp > 0 ? timestamp : System.currentTimeMillis());
        editor.putBoolean(prefix + "parse_success", parseSuccess);

        if (parsedData != null) {
            editor.putString(prefix + "amount", parsedData.getAmount());
            editor.putString(prefix + "agent", parsedData.getAgent());
            editor.putString(prefix + "txid", parsedData.getTxid());
        } else if (!parseSuccess) {
            editor.putString(prefix + "amount", "");
            editor.putString(prefix + "agent", "");
            editor.putString(prefix + "txid", "");
        }
        editor.apply();
    }

    public String getRawBody(Provider provider) {
        if (provider == null) return "";
        return prefs.getString(provider.name() + "_raw_body", "");
    }

    public String getSender(Provider provider) {
        if (provider == null) return "";
        return prefs.getString(provider.name() + "_sender", "");
    }

    public long getTimestamp(Provider provider) {
        if (provider == null) return 0L;
        return prefs.getLong(provider.name() + "_timestamp", 0L);
    }

    public boolean isParseSuccess(Provider provider) {
        if (provider == null) return false;
        return prefs.getBoolean(provider.name() + "_parse_success", false);
    }

    public String getAmount(Provider provider) {
        if (provider == null) return "";
        return prefs.getString(provider.name() + "_amount", "");
    }

    public String getAgent(Provider provider) {
        if (provider == null) return "";
        return prefs.getString(provider.name() + "_agent", "");
    }

    public String getTxid(Provider provider) {
        if (provider == null) return "";
        return prefs.getString(provider.name() + "_txid", "");
    }

    public boolean hasSms(Provider provider) {
        return !getRawBody(provider).isEmpty();
    }

    // -------------------------------------------------------------
    // Session Management
    // -------------------------------------------------------------
    public void setUnlocked(boolean unlocked) {
        prefs.edit()
                .putBoolean(KEY_IS_UNLOCKED, unlocked)
                .putLong(KEY_LAST_UNLOCK_TIME, unlocked ? System.currentTimeMillis() : 0L)
                .apply();
    }

    public boolean isUnlocked() {
        return prefs.getBoolean(KEY_IS_UNLOCKED, false);
    }

    public void lockSession() {
        setUnlocked(false);
    }
}
