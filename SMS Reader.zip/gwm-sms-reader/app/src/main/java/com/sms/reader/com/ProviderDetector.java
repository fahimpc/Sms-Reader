package com.sms.reader.com;

import java.util.Locale;

/**
 * Identifies whether an incoming SMS belongs to bKash, Nagad, or Rocket.
 * Uses both sender address heuristics and strict message body signatures.
 */
public final class ProviderDetector {

    private ProviderDetector() {
    }

    public static boolean isAllowedBkashSender(String sender) {
        if (sender == null) {
            return false;
        }
        return sender.trim().toLowerCase(Locale.ROOT).equals("bkash");
    }

    public static Provider detect(String sender, String body) {
        if (body == null) {
            return Provider.UNKNOWN;
        }

        String s = sender != null ? sender.toLowerCase(Locale.ROOT).trim() : "";
        String b = body.trim();
        String bLower = b.toLowerCase(Locale.ROOT);

        // 1. Strict bKash Sender Check: bKash payment SMS MUST have exact sender "bKash"
        if (isAllowedBkashSender(sender)) {
            return Provider.BKASH;
        }

        // 2. Check by sender for Nagad, Rocket, Upay
        if (s.contains("nagad")) {
            return Provider.NAGAD;
        }
        if (s.contains("rocket") || s.contains("16216") || s.contains("dbbl")) {
            return Provider.ROCKET;
        }
        if (s.contains("upay") || s.contains("16268")) {
            return Provider.UPAY;
        }

        // 3. Body-based signature checks for Nagad
        // Format 1: "Cash In Received. Amount: Tk ... Uddokta: ... TxnID: ..."
        // Format 2: "Money Received. Amount: Tk ... Sender: ... TxnID: ..."
        // Format 3: "Payment Received. Amount: Tk ... Customer: ... TxnID: ..."
        if ((b.contains("Cash In Received") || b.contains("Money Received") || b.contains("Payment Received")) &&
                (b.contains("TxnID") || b.contains("TxnId") || b.contains("Uddokta:") || b.contains("Sender:") || b.contains("Customer:"))) {
            return Provider.NAGAD;
        }

        // 4. Body-based signature checks for Upay (Two verified incoming formats)
        // Format 1: "Tk. 14.00 has been received from 01787882701. Ref-. Balance Tk. 14.00. TrxID 01M4NBDPA3 at 11/10/2026 17:26."
        // Format 2: "Cash-In of Tk. 290.00 from 01838607027 is successful. Balance Tk. 292.68. TrxID 01M4NMPMMK at 11/10/2026 20:08."
        if ((bLower.contains("has been received from") || bLower.contains("cash-in of tk"))
                && (bLower.contains("trxid") || bLower.contains("trx id"))) {
            return Provider.UPAY;
        }

        // 5. Body-based signature checks for Rocket (Only P2P and Cash-In)
        // Format 1: "Tk20.00 received from A/C:***583 ... TxnId:7011827020"
        // Format 2: "Cash-In from A/C: ***222 Tk20.00 ... TxnId:7015175802"
        if ((bLower.contains("received from a/c") || bLower.contains("cash-in from a/c"))
                && (bLower.contains("txnid") || bLower.contains("txn id"))) {
            return Provider.ROCKET;
        }
        if (bLower.contains("a/c balance:") && (bLower.contains("txnid:") || bLower.contains("txn id:"))) {
            return Provider.ROCKET;
        }

        return Provider.UNKNOWN;
    }
}
