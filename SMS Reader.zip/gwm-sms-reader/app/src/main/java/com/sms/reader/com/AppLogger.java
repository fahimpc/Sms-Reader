package com.sms.reader.com;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Locale;

/**
 * High-performance, thread-safe diagnostic logging utility for GWM SMS Reader.
 * Uses a lightweight bounded circular buffer (ArrayDeque) and incremental event
 * dispatching to ensure zero UI lag or garbage collection stutter.
 */
public final class AppLogger {

    private static final String TAG = "GWMSmsReader";
    private static final int MAX_LOG_ENTRIES = 150;
    private static final Deque<String> LOG_BUFFER = new ArrayDeque<>(MAX_LOG_ENTRIES);
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("hh:mm:ss a", Locale.US);
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static LogListener logListener;

    public interface LogListener {
        void onLogAdded(String newEntry, String fullLog);
    }

    private AppLogger() {
    }

    public static synchronized void log(String message) {
        if (message == null || message.trim().isEmpty()) {
            return;
        }

        // Security check: Never log PIN
        if (message.contains(AppConfig.DEFAULT_PIN)) {
            message = message.replace(AppConfig.DEFAULT_PIN, "****");
        }

        String time = TIME_FORMAT.format(new Date());
        String entry = time + " " + message;

        Log.i(TAG, entry);

        synchronized (LOG_BUFFER) {
            if (LOG_BUFFER.size() >= MAX_LOG_ENTRIES) {
                LOG_BUFFER.pollFirst();
            }
            LOG_BUFFER.addLast(entry);
        }

        notifyIncremental(entry);
    }

    public static synchronized void error(String message, Throwable tr) {
        String time = TIME_FORMAT.format(new Date());
        String entry = time + " ERROR: " + message + (tr != null ? " (" + tr.getMessage() + ")" : "");
        Log.e(TAG, entry, tr);

        synchronized (LOG_BUFFER) {
            if (LOG_BUFFER.size() >= MAX_LOG_ENTRIES) {
                LOG_BUFFER.pollFirst();
            }
            LOG_BUFFER.addLast(entry);
        }

        notifyIncremental(entry);
    }

    public static synchronized String getFullLog() {
        synchronized (LOG_BUFFER) {
            if (LOG_BUFFER.isEmpty()) {
                return "Ready. Listening for bKash, Nagad, and Rocket payment SMS...";
            }
            StringBuilder sb = new StringBuilder(LOG_BUFFER.size() * 64);
            for (String entry : LOG_BUFFER) {
                sb.append(entry).append("\n");
            }
            return sb.toString();
        }
    }

    public static synchronized void clear() {
        synchronized (LOG_BUFFER) {
            LOG_BUFFER.clear();
        }
        MAIN_HANDLER.post(() -> {
            LogListener listener;
            synchronized (AppLogger.class) {
                listener = logListener;
            }
            if (listener != null) {
                listener.onLogAdded(null, "");
            }
        });
    }

    public static synchronized void setListener(LogListener listener) {
        logListener = listener;
    }

    private static void notifyIncremental(final String entry) {
        MAIN_HANDLER.post(() -> {
            LogListener listener;
            synchronized (AppLogger.class) {
                listener = logListener;
            }
            if (listener != null) {
                listener.onLogAdded(entry, null);
            }
        });
    }
}
