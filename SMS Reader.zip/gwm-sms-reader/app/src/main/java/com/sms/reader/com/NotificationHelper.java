package com.sms.reader.com;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

/**
 * Manages the single persistent notification in the status bar.
 * Updates a single stable notification ID (1001) to avoid duplicate alerts.
 */
public final class NotificationHelper {

    private static NotificationHelper instance;
    private final Context context;
    private final NotificationManager notificationManager;

    public static synchronized NotificationHelper getInstance(Context context) {
        if (instance == null) {
            instance = new NotificationHelper(context.getApplicationContext());
        }
        return instance;
    }

    private NotificationHelper(Context context) {
        this.context = context;
        this.notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    AppConfig.NOTIFICATION_CHANNEL_ID,
                    context.getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription(context.getString(R.string.notification_channel_desc));
            channel.setShowBadge(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableLights(false);
            channel.enableVibration(false);
            channel.setSound(null, null);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private PendingIntent getPinPendingIntent() {
        Intent intent = new Intent(context, PinActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, 0, intent, flags);
    }

    /**
     * Builds standard notification object for Foreground Service and status updates.
     * Configured with explicit flags to remain 100% permanent and un-clearable
     * across Chinese OEM ROMs (MIUI/HyperOS, ColorOS, OriginOS, EMUI, HiOS).
     */
    @NonNull
    public Notification buildNotification(String title, String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, AppConfig.NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_bolt_white)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setLocalOnly(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(getPinPendingIntent());

        Bitmap logo = LogoLoader.getLogoBitmap(context);
        if (logo != null) {
            builder.setLargeIcon(logo);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE);
        }

        Notification notification = builder.build();

        // CRITICAL FOR CHINESE OEM ROMS (MIUI/HyperOS, ColorOS, OriginOS, EMUI, HiOS):
        // Chinese notification shade dispatchers inspect FLAG_NO_CLEAR upon "Clear All".
        // Explicitly applying FLAG_NO_CLEAR | FLAG_ONGOING_EVENT | FLAG_FOREGROUND_SERVICE
        // prevents Chinese ROM notification sweepers from clearing this notification.
        notification.flags |= Notification.FLAG_NO_CLEAR
                | Notification.FLAG_ONGOING_EVENT
                | Notification.FLAG_FOREGROUND_SERVICE;

        return notification;
    }

    /**
     * Returns the persistent ongoing notification for Foreground Service.
     */
    @NonNull
    public Notification getForegroundNotification() {
        return buildNotification(
                context.getString(R.string.notification_active_title),
                context.getString(R.string.notification_active_text)
        );
    }

    /**
     * Shows initial persistent active status.
     */
    public void showActiveNotification() {
        updateNotification(
                context.getString(R.string.notification_active_title),
                context.getString(R.string.notification_active_text)
        );
    }

    /**
     * Updates persistent notification with latest status using single ID 1001.
     */
    public void updateNotification(String title, String message) {
        if (notificationManager == null) return;
        Notification notification = buildNotification(title, message);
        notificationManager.notify(AppConfig.NOTIFICATION_ID, notification);
    }

    /**
     * Convenience method to update notification on payment events.
     */
    public void onPaymentEvent(String providerName, String amount, String txid, String status) {
        String title = "Payment SMS detected";
        String message = providerName + " • Tk " + amount + " • " + txid + " • " + status;
        updateNotification(title, message);
    }
}
