package com.sms.reader.com;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.net.URI;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Sends the API POST through a hidden, real Chromium WebView (fetch()) instead of
 * HttpURLConnection. Imunify360 / WAF bot protection treats a real browser engine
 * very differently from a plain Java HTTP client, and any challenge cookie that the
 * user passed via the verify dialog is shared automatically through CookieManager.
 */
public final class PhpWebTransport {

    /** Thrown when the response is a firewall / captcha / bot-protection page. */
    public static final class BlockedException extends Exception {
        public BlockedException(String message) { super(message); }
    }

    private static final long TOTAL_TIMEOUT_MS = 11_000L;
    private static final int FETCH_ABORT_MS = 9_000;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Object REQUEST_LOCK = new Object();

    private static WebView webView;
    private static String loadedOrigin = "";
    private static volatile CountDownLatch pageLatch;
    private static volatile CountDownLatch resultLatch;
    private static volatile int resultStatus;
    private static volatile String resultBody;
    private static volatile String resultError;

    private PhpWebTransport() {}

    /** Blocking call. Must NOT be called from the main thread. */
    @NonNull
    public static String post(@NonNull Context context, @NonNull String url, @NonNull String body) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw new IllegalStateException("PhpWebTransport.post must run off the main thread");
        }
        final Context app = context.getApplicationContext();
        final String origin = originOf(url);

        synchronized (REQUEST_LOCK) {
            resultStatus = 0;
            resultBody = null;
            resultError = null;
            resultLatch = new CountDownLatch(1);

            // 1) make sure the hidden WebView sits on the same origin as the API
            pageLatch = new CountDownLatch(1);
            final boolean[] needLoad = {false};
            final CountDownLatch prep = new CountDownLatch(1);
            MAIN.post(() -> {
                try {
                    ensureWebView(app);
                    if (!origin.equals(loadedOrigin)) {
                        needLoad[0] = true;
                        loadedOrigin = origin;
                        webView.loadDataWithBaseURL(origin + "/", "<html><body></body></html>",
                                "text/html", "UTF-8", null);
                    }
                } catch (Throwable t) {
                    resultError = "WEBVIEW_INIT: " + t.getMessage();
                    resultLatch.countDown();
                } finally {
                    prep.countDown();
                }
            });
            if (!prep.await(5, TimeUnit.SECONDS)) throw new Exception("WebView init timeout");
            if (resultError != null) throw new Exception(resultError);
            if (needLoad[0] && !pageLatch.await(6, TimeUnit.SECONDS)) {
                loadedOrigin = "";
                throw new Exception("WebView page load timeout");
            }

            // 2) run fetch() inside the page
            final String js = "(function(){var c=new AbortController();"
                    + "var t=setTimeout(function(){c.abort()}," + FETCH_ABORT_MS + ");"
                    + "fetch(" + JSONObject.quote(url) + ",{method:'POST',credentials:'include',"
                    + "headers:{'Content-Type':'application/json'},body:" + JSONObject.quote(body)
                    + ",signal:c.signal}).then(function(r){return r.text().then(function(x){"
                    + "clearTimeout(t);FexBridge.onResult(r.status,x);});})"
                    + ".catch(function(e){clearTimeout(t);FexBridge.onError(String(e));});})();";
            MAIN.post(() -> webView.evaluateJavascript(js, null));

            if (!resultLatch.await(TOTAL_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                throw new Exception("WebView request timeout");
            }
            if (resultError != null) throw new Exception(resultError);

            final String text = resultBody == null ? "" : resultBody.trim();
            final int status = resultStatus;
            if (looksBlocked(status, text)) {
                throw new BlockedException("Imunify360 Bot Protection: Server firewall blocked request (HTTP "
                        + status + "). Open PHP MySQL tab and tap VERIFY & UNBLOCK SERVER FIREWALL.");
            }
            if (status >= 400 && !text.startsWith("{")) {
                throw new Exception("HTTP Error " + status + ": " + (text.length() > 100 ? text.substring(0, 100) : text));
            }
            return text;
        }
    }

    /** True when the body is a WAF / captcha page instead of the API's JSON. */
    public static boolean looksBlocked(int status, @NonNull String body) {
        String b = body.trim();
        if (b.startsWith("{") || b.startsWith("[")) return false; // real API JSON
        String low = b.toLowerCase(Locale.ROOT);
        if (low.contains("imunify") || low.contains("bot-protection") || low.contains("access denied")
                || low.contains("captcha") || low.contains("cf-chl") || low.contains("just a moment")) {
            return true;
        }
        return status == 403 || status == 429 || status == 503;
    }

    @NonNull
    public static String originOf(@NonNull String url) {
        try {
            URI u = new URI(url);
            String scheme = u.getScheme() == null ? "https" : u.getScheme();
            int port = u.getPort();
            return scheme + "://" + u.getHost() + (port > 0 ? ":" + port : "");
        } catch (Exception e) {
            int slash = url.indexOf('/', 8);
            return slash > 0 ? url.substring(0, slash) : url;
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private static void ensureWebView(Context app) {
        if (webView != null) return;
        webView = new WebView(app);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new Bridge(), "FexBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String u) {
                CountDownLatch l = pageLatch;
                if (l != null) l.countDown();
            }
        });
    }

    private static final class Bridge {
        @JavascriptInterface public void onResult(int status, String body) {
            resultStatus = status;
            resultBody = body;
            CountDownLatch l = resultLatch;
            if (l != null) l.countDown();
        }
        @JavascriptInterface public void onError(String err) {
            resultError = "WEBVIEW_FETCH: " + err;
            CountDownLatch l = resultLatch;
            if (l != null) l.countDown();
        }
    }
}
