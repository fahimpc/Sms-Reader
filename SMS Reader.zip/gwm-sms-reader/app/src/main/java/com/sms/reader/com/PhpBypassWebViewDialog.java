package com.sms.reader.com;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import java.util.Locale;

/**
 * In-app WebView dialog for the cPanel / Imunify360 / Cloudflare firewall challenge.
 *
 * Loads a REAL API endpoint (connection_test.php, not the bare /api/ folder which has no index
 * and returns 404), lets the user solve any captcha, and treats the check as passed as soon as the
 * page returns the API's own JSON. Cookies live in the shared CookieManager, so both the hidden
 * WebView transport and the HTTP fallback in PhpWriter reuse them automatically.
 */
public final class PhpBypassWebViewDialog {

    public interface BypassCallback {
        void onVerified(String cookie);
    }

    private final Context context;
    private final String apiUrl;
    private final BypassCallback callback;

    private AlertDialog dialog;
    private WebView webView;
    private TextView tvStatus;
    private boolean finished = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public PhpBypassWebViewDialog(@NonNull Context context, @NonNull String apiUrl, @NonNull BypassCallback callback) {
        this.context = context;
        this.apiUrl = PhpConfig.sanitizeUrl(apiUrl);
        this.callback = callback;
    }

    @SuppressLint("SetJavaScriptEnabled")
    public void show() {
        final String testUrl = new PhpConfig(apiUrl, "x", "x", true).getEndpointUrl("connection_test.php");

        LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(20, 20, 20, 20);
        container.setBackgroundColor(Color.parseColor("#0F172A"));

        TextView tvTitle = new TextView(context);
        tvTitle.setText("🛡️ Verify & Unblock Server Firewall");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(16);
        tvTitle.setPadding(10, 10, 10, 10);
        container.addView(tvTitle);

        tvStatus = new TextView(context);
        tvStatus.setText("Loading " + testUrl + " ...\nIf a captcha appears, solve it. This window closes by itself when the server answers.");
        tvStatus.setTextColor(Color.parseColor("#94A3B8"));
        tvStatus.setTextSize(11);
        tvStatus.setPadding(10, 0, 10, 16);
        container.addView(tvStatus);

        webView = new WebView(context);
        webView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (420 * context.getResources().getDisplayMetrics().density)));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // Default WebView User-Agent on purpose: the firewall cookie is tied to the User-Agent that earned it.

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request.isForMainFrame() && errorResponse.getStatusCode() == 404) {
                    setStatus("❌ 404: " + testUrl + " not found on your server. Upload php_backend/connection_test.php into the /api/ folder or fix the API Base URL.");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (finished) return;
                view.evaluateJavascript("(function(){return document.body?document.body.innerText:'';})()", value -> {
                    if (finished || value == null) return;
                    String text = value.toLowerCase(Locale.ROOT);
                    // The API's own JSON (even "MISSING_FIELDS") proves the request reached PHP, not the firewall.
                    if (text.contains("error_code") || text.contains("\\\"success\\\"")) {
                        complete();
                    } else if (text.contains("imunify") || text.contains("captcha") || text.contains("access denied")
                            || text.contains("bot")) {
                        setStatus("⚠️ Firewall challenge is showing. Please solve it below.");
                    }
                });
            }
        });

        container.addView(webView);

        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setView(container)
                .setPositiveButton("DONE", (d, w) -> complete())
                .setNegativeButton("CANCEL", (d, w) -> { finished = true; d.dismiss(); });

        dialog = builder.create();
        dialog.setOnDismissListener(d -> { if (webView != null) { webView.destroy(); webView = null; } });
        dialog.show();

        webView.loadUrl(testUrl);
    }

    private void setStatus(String s) {
        mainHandler.post(() -> { if (tvStatus != null) tvStatus.setText(s); });
    }

    private void complete() {
        if (finished) return;
        finished = true;
        String cookies = CookieManager.getInstance().getCookie(PhpWebTransport.originOf(apiUrl));
        PhpConfigManager.getInstance(context).saveFirewallCookie(cookies);
        CookieManager.getInstance().flush();
        Toast.makeText(context, "✓ Server check finished. Retrying connection...", Toast.LENGTH_LONG).show();
        if (callback != null) callback.onVerified(cookies == null ? "" : cookies);
        if (dialog != null && dialog.isShowing()) dialog.dismiss();
    }
}
