package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import androidx.annotation.NonNull;

/**
 * Manages Dynamic UI Color Themes with Presets and Custom Hex Code Support.
 */
public final class ThemeManager {

    private static final String PREFS_NAME = "gwm_theme_prefs";
    private static final String KEY_THEME_HEX = "selected_theme_hex";
    private static final String KEY_THEME_NAME = "selected_theme_name";

    public static final String THEME_PURPLE = "Purple";
    public static final String THEME_BLUE = "Blue";
    public static final String THEME_GREEN = "Green";
    public static final String THEME_ORANGE = "Orange";
    public static final String THEME_RED = "Red";
    public static final String THEME_PINK = "Pink";
    public static final String THEME_TEAL = "Teal";
    public static final String THEME_INDIGO = "Indigo";
    public static final String THEME_CYAN = "Cyan";
    public static final String THEME_DARK = "Dark";

    private static ThemeManager instance;
    private final SharedPreferences prefs;

    public static synchronized ThemeManager getInstance(@NonNull Context context) {
        if (instance == null) {
            instance = new ThemeManager(context.getApplicationContext());
        }
        return instance;
    }

    private ThemeManager(@NonNull Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    @NonNull
    public String getThemeName() {
        return prefs.getString(KEY_THEME_NAME, THEME_PURPLE);
    }

    @NonNull
    public String getPrimaryColorHex() {
        return prefs.getString(KEY_THEME_HEX, "#7C3AED");
    }

    public int getPrimaryColor() {
        try {
            String hex = getPrimaryColorHex();
            if (!hex.startsWith("#")) {
                hex = "#" + hex;
            }
            return Color.parseColor(hex);
        } catch (Exception e) {
            return Color.parseColor("#7C3AED");
        }
    }

    public void setThemePreset(@NonNull String name, @NonNull String hexColor) {
        String cleanHex = hexColor.trim();
        if (!cleanHex.startsWith("#")) {
            cleanHex = "#" + cleanHex;
        }
        prefs.edit()
                .putString(KEY_THEME_NAME, name)
                .putString(KEY_THEME_HEX, cleanHex)
                .apply();
    }

    public boolean setCustomHexColor(@NonNull String hexColor) {
        String clean = hexColor.trim();
        if (!clean.startsWith("#")) {
            clean = "#" + clean;
        }
        try {
            Color.parseColor(clean);
            prefs.edit()
                    .putString(KEY_THEME_NAME, "Custom (" + clean + ")")
                    .putString(KEY_THEME_HEX, clean)
                    .apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
