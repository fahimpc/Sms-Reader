package com.sms.reader.com;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.sms.reader.com.databinding.FragmentPhpBinding;

public final class PhpFragment extends Fragment {

    private FragmentPhpBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPhpBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupListeners();
        updateUi();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void updateUi() {
        if (binding == null || !isAdded()) return;
        Context ctx = getContext();
        if (ctx == null) return;

        boolean isPhpMode = BackendManager.getInstance(ctx).isPhpMode();
        PhpConfig config = PhpConfigManager.getInstance(ctx).getActiveConfig();
        boolean isConfigured = isPhpMode && config != null && config.isValid();

        if (isConfigured) {
            binding.tvPhpStatusBadgePage.setText("✔ Connected");
            binding.tvPhpStatusBadgePage.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));

            binding.tvPhpConnValue.setText("✔ Connected");
            binding.tvPhpConnValue.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));

            binding.tvPhpApiUrlValue.setText(config.getApiBaseUrl());
            binding.tvPhpDeviceIdValue.setText(config.getDeviceId());
            binding.etPhpApiUrl.setText(config.getApiBaseUrl());
            binding.etDeviceSecret.setText(config.getDeviceSecret());
        } else {
            binding.tvPhpStatusBadgePage.setText("● Disconnected");
            binding.tvPhpStatusBadgePage.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));

            binding.tvPhpConnValue.setText("● Disconnected");
            binding.tvPhpConnValue.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));

            binding.tvPhpApiUrlValue.setText(isPhpMode ? "Not configured" : "Disabled (Firebase Mode Active)");
            binding.tvPhpDeviceIdValue.setText(PhpConfigManager.getInstance(ctx).getOrCreateDeviceId());
        }
    }

    private void setupListeners() {
        if (binding == null) return;

        // Copy Device ID
        View.OnClickListener copyDeviceIdListener = v -> {
            Context ctx = getContext();
            if (ctx != null) {
                String fullDeviceId = PhpConfigManager.getInstance(ctx).getOrCreateDeviceId();
                ClipboardManager clipboard = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Device ID", fullDeviceId);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(ctx, "Device ID Copied Successfully!", Toast.LENGTH_SHORT).show();
                    AppLogger.log("Copied Device ID: " + fullDeviceId);
                }
            }
        };

        binding.layoutPhpDeviceIdContainer.setOnClickListener(copyDeviceIdListener);
        binding.tvPhpDeviceIdValue.setOnClickListener(copyDeviceIdListener);

        // Add New PHP MySQL Project
        binding.btnTestAndActivatePhp.setOnClickListener(v -> {
            Context ctx = requireContext();
            String url = binding.etPhpApiUrl.getText().toString().trim();
            String secret = binding.etDeviceSecret.getText().toString().trim();

            if (url.isEmpty() || secret.isEmpty()) {
                Toast.makeText(ctx, "Please enter API URL and Device Secret", Toast.LENGTH_SHORT).show();
                return;
            }

            binding.layoutPhpTestStatus.setVisibility(View.VISIBLE);
            binding.progressBarPhp.setVisibility(View.VISIBLE);
            binding.tvPhpStatus.setText("Testing connection to PHP API...");
            binding.tvPhpStatus.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
            binding.btnTestAndActivatePhp.setEnabled(false);

            PhpWriter.testConnection(ctx, url, secret, new PhpWriter.ApiCallback() {
                @Override
                public void onSuccess(String deviceId, String message) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            if (binding != null) {
                                binding.progressBarPhp.setVisibility(View.GONE);
                                binding.btnTestAndActivatePhp.setEnabled(true);
                                binding.tvPhpStatus.setText("✓ " + message + "\nPHP API connection verified!");
                                binding.tvPhpStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));
                            }

                            PhpConfigManager.getInstance(ctx).saveConfig(url, secret);
                            BackendManager.getInstance(ctx).setBackendMode(BackendManager.BackendMode.PHP_MYSQL);
                            updateUi();

                            if (getActivity() instanceof MainActivity) {
                                ((MainActivity) getActivity()).updateActiveProjectUi();
                            }

                            Toast.makeText(ctx, "PHP MySQL Mode Activated!", Toast.LENGTH_SHORT).show();
                        });
                    }
                }

                @Override
                public void onAlreadyExists(String deviceId, String message) {
                    onSuccess(deviceId, message);
                }

                @Override
                public void onError(String errorCode, String errorMessage) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            if (binding != null) {
                                binding.progressBarPhp.setVisibility(View.GONE);
                                binding.btnTestAndActivatePhp.setEnabled(true);
                                binding.tvPhpStatus.setText("❌ Error: " + errorMessage);
                                binding.tvPhpStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_red));

                                if (errorMessage != null && (errorMessage.contains("Imunify360") || errorMessage.contains("blocked") || errorMessage.contains("firewall") || errorMessage.contains("403") || errorMessage.contains("503"))) {
                                    binding.btnVerifyUnblockPhp.setVisibility(View.VISIBLE);
                                }
                            }
                        });
                    }
                }
            });
        });

        // Verify & Unblock Server Firewall Button (WebView Captcha Bypass)
        binding.btnVerifyUnblockPhp.setOnClickListener(v -> {
            String url = binding.etPhpApiUrl.getText().toString().trim();
            if (url.isEmpty()) {
                PhpConfig cfg = PhpConfigManager.getInstance(requireContext()).getActiveConfig();
                if (cfg != null) url = cfg.getApiBaseUrl();
            }
            if (!url.isEmpty()) {
                new PhpBypassWebViewDialog(requireContext(), url, cookie -> {
                    Toast.makeText(requireContext(), "✓ Server Unblocked! Retrying connection...", Toast.LENGTH_SHORT).show();
                    binding.btnTestAndActivatePhp.performClick();
                }).show();
            } else {
                Toast.makeText(requireContext(), "Please enter API Base URL first", Toast.LENGTH_SHORT).show();
            }
        });

        // Test Connection
        binding.btnTestPhpConnection.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).onTestPhpClicked();
            }
        });

        // Retry PHP MySQL
        binding.btnRetryPhpPage.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).onRetryAddClicked();
            }
        });

        // Remove PHP MySQL Project
        binding.btnTestPhpPage.setOnClickListener(v -> {
            Context ctx = requireContext();
            new AlertDialog.Builder(ctx)
                    .setTitle("🗑️ Remove PHP MySQL Project?")
                    .setMessage("Are you sure you want to remove the active PHP MySQL API backend? This will disconnect PHP MySQL and clear saved credentials.")
                    .setPositiveButton("YES, REMOVE", (dialog, which) -> {
                        PhpConfigManager.getInstance(ctx).clearConfig();
                        updateUi();
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).notifyHomeDashboardUpdated();
                        }
                        Toast.makeText(ctx, "PHP MySQL Project Removed", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("CANCEL", null)
                    .show();
        });

        // Switch Back to Firebase Mode
        binding.btnSwitchToFirebase.setOnClickListener(v -> {
            Context ctx = requireContext();
            BackendManager.getInstance(ctx).setBackendMode(BackendManager.BackendMode.FIREBASE);
            updateUi();

            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).updateActiveProjectUi();
            }

            Toast.makeText(ctx, "Switched to Firebase Mode", Toast.LENGTH_SHORT).show();
        });
    }
}
