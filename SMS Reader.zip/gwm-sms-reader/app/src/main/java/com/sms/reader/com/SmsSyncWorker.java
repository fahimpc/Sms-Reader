package com.sms.reader.com;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * Android WorkManager Worker for background automatic server recovery.
 * Periodically retries pending, offline, and server_failed payment SMS records.
 */
public final class SmsSyncWorker extends Worker {

    public SmsSyncWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        SmsSyncManager.getInstance(getApplicationContext()).syncPendingQueue(null);
        return Result.success();
    }
}
