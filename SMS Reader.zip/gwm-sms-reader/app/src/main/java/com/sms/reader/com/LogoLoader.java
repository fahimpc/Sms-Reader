package com.sms.reader.com;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Dynamically loads and displays the app logo.
 *
 * Priority Order:
 * 1. User-uploaded custom logo from device storage (custom_app_logo.png)
 * 2. Assets directory (app/src/main/assets/logo.png or logo.jpg)
 * 3. Fallback drawable (R.drawable.img_app_icon)
 *
 * Supports live uploading from phone gallery with automatic image scaling and resizing.
 */
public final class LogoLoader {

    private static final String CUSTOM_LOGO_FILENAME = "custom_app_logo.png";
    private static final int MAX_LOGO_DIMENSION = 512; // Auto-resizes large images to max 512x512 px

    private static volatile Bitmap cachedLogoBitmap = null;
    private static volatile boolean attemptedLoad = false;

    private LogoLoader() {}

    /**
     * Loads the custom/default logo into the provided ImageView.
     */
    public static void loadLogoInto(ImageView imageView, Context context) {
        if (imageView == null || context == null) return;

        Bitmap logo = getLogoBitmap(context);
        if (logo != null) {
            imageView.setImageBitmap(logo);
        } else {
            imageView.setImageResource(R.drawable.img_app_icon);
        }
    }

    /**
     * Retrieves the custom or default logo bitmap.
     */
    public static synchronized Bitmap getLogoBitmap(Context context) {
        if (attemptedLoad && cachedLogoBitmap != null && !cachedLogoBitmap.isRecycled()) {
            return cachedLogoBitmap;
        }

        attemptedLoad = true;

        // 1. Check user-uploaded logo in app internal storage
        if (context != null) {
            try {
                File customFile = new File(context.getFilesDir(), CUSTOM_LOGO_FILENAME);
                if (customFile.exists() && customFile.length() > 0) {
                    Bitmap customBitmap = BitmapFactory.decodeFile(customFile.getAbsolutePath());
                    if (customBitmap != null) {
                        cachedLogoBitmap = customBitmap;
                        AppLogger.log("Loaded user-uploaded custom logo from internal storage.");
                        return cachedLogoBitmap;
                    }
                }
            } catch (Exception e) {
                AppLogger.error("Error reading custom uploaded logo: " + e.getMessage(), e);
            }
        }

        // 2. Check assets folder
        if (context != null) {
            String[] candidateNames = new String[]{
                    "logo.png",
                    "logo.jpg",
                    "logo.jpeg",
                    "logo.webp",
                    "app_logo.png",
                    "app_logo.jpg"
            };

            for (String filename : candidateNames) {
                try (InputStream is = context.getAssets().open(filename)) {
                    Bitmap decoded = BitmapFactory.decodeStream(is);
                    if (decoded != null) {
                        cachedLogoBitmap = decoded;
                        AppLogger.log("Custom logo successfully loaded from assets: " + filename);
                        return cachedLogoBitmap;
                    }
                } catch (Exception ignored) {
                    // Try next file name
                }
            }

            // Dynamic search for any file named like logo or icon in assets root
            try {
                String[] assetFiles = context.getAssets().list("");
                if (assetFiles != null) {
                    for (String file : assetFiles) {
                        String lower = file.toLowerCase();
                        if ((lower.contains("logo") || lower.contains("icon")) &&
                                (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".webp"))) {
                            try (InputStream is = context.getAssets().open(file)) {
                                Bitmap decoded = BitmapFactory.decodeStream(is);
                                if (decoded != null) {
                                    cachedLogoBitmap = decoded;
                                    AppLogger.log("Custom logo found and loaded from assets: " + file);
                                    return cachedLogoBitmap;
                                }
                            } catch (Exception ignored) {}
                        }
                    }
                }
            } catch (Exception ignored) {}
        }

        // 3. Fallback to drawable resource if assets/internal storage do not yield a bitmap
        if (context != null) {
            try {
                Bitmap fallback = BitmapFactory.decodeResource(context.getResources(), R.drawable.img_app_icon);
                if (fallback != null) {
                    cachedLogoBitmap = fallback;
                    return cachedLogoBitmap;
                }
            } catch (Exception ignored) {}
        }

        return null;
    }

    /**
     * Saves a new logo picked from phone gallery/storage, automatically resizing it for memory efficiency.
     */
    public static synchronized boolean saveCustomLogo(@NonNull Context context, @NonNull Uri imageUri) {
        try {
            InputStream is = context.getContentResolver().openInputStream(imageUri);
            if (is == null) return false;

            Bitmap original = BitmapFactory.decodeStream(is);
            is.close();

            if (original == null) return false;

            // Auto-scale bitmap if dimensions exceed MAX_LOGO_DIMENSION (512px)
            Bitmap scaled = scaleBitmap(original, MAX_LOGO_DIMENSION);

            File customFile = new File(context.getFilesDir(), CUSTOM_LOGO_FILENAME);
            try (FileOutputStream fos = new FileOutputStream(customFile)) {
                scaled.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.flush();
            }

            if (scaled != original && !original.isRecycled()) {
                original.recycle();
            }

            clearCache();
            AppLogger.log("New custom logo successfully uploaded and saved to internal storage!");
            return true;
        } catch (Exception e) {
            AppLogger.error("Failed to save custom uploaded logo: " + e.getMessage(), e);
            return false;
        }
    }

    /**
     * Resets the logo back to default.
     */
    public static synchronized boolean resetCustomLogo(@NonNull Context context) {
        try {
            File customFile = new File(context.getFilesDir(), CUSTOM_LOGO_FILENAME);
            if (customFile.exists()) {
                boolean deleted = customFile.delete();
                clearCache();
                AppLogger.log("Custom uploaded logo deleted. Reset to default logo.");
                return deleted;
            }
        } catch (Exception e) {
            AppLogger.error("Failed to reset custom logo: " + e.getMessage(), e);
        }
        clearCache();
        return false;
    }

    public static boolean hasCustomUploadedLogo(@NonNull Context context) {
        try {
            File customFile = new File(context.getFilesDir(), CUSTOM_LOGO_FILENAME);
            return customFile.exists() && customFile.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private static Bitmap scaleBitmap(Bitmap bitmap, int maxDimension) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        if (width <= maxDimension && height <= maxDimension) {
            return bitmap;
        }

        float ratio = (float) width / (float) height;
        if (ratio > 1) {
            width = maxDimension;
            height = (int) (width / ratio);
        } else {
            height = maxDimension;
            width = (int) (height * ratio);
        }

        return Bitmap.createScaledBitmap(bitmap, Math.max(1, width), Math.max(1, height), true);
    }

    /**
     * Clears cached bitmap so replacing the logo file reloads it instantly across all screens.
     */
    public static synchronized void clearCache() {
        cachedLogoBitmap = null;
        attemptedLoad = false;
    }
}
