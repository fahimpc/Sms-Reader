package com.sms.reader.com;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Executes secure HTTP/HTTPS POST requests to the PHP MySQL Backend API endpoints.
 *
 * Implements strict error handling, duplicate transaction checks,
 * timeouts, and thread safety.
 */
public final class PhpWriter {

    public interface ApiCallback {
        void onSuccess(String txid, String message);
        void onAlreadyExists(String txid, String message);
        void onError(String errorCode, String errorMessage);
    }

    private static final int TIMEOUT_MS = 15000;
    // Bounded thread pool optimized for budget / low-end devices to prevent high RAM/CPU usage
    private static final ExecutorService executor = Executors.newFixedThreadPool(2);
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    private PhpWriter() {}

    public static void uploadTransaction(@NonNull final Context context,
                                         @NonNull final PaymentData data,
                                         @Nullable final FirebaseWriter.UploadCallback callback) {
        final PhpConfig config = PhpConfigManager.getInstance(context).getActiveConfig();
        if (config == null || !config.isValid()) {
            if (callback != null) {
                callback.onError("PHP_NOT_CONFIGURED", "PHP API Backend is not configured or disabled");
            }
            return;
        }

        // Determine PHP approved receiving number for this provider from PHP Config Manager
        SettingsRepository.ProviderSetting phpSetting = PhpConfigManager.getInstance(context).getProviderSetting(data.getProvider());
        String approvedReceiverNum = phpSetting.getNumber();
        if (approvedReceiverNum == null || "Not configured".equalsIgnoreCase(approvedReceiverNum.trim())) {
            approvedReceiverNum = "";
        }

        final String receiverNum = approvedReceiverNum.trim();

        executor.execute(() -> {
            try {
                long now = System.currentTimeMillis();
                String nonce = UUID.randomUUID().toString();
                String sig = AppSecurityManager.generateRequestSignature(config.getDeviceId(), config.getDeviceSecret(), data.getTxid(), now, nonce);

                JSONObject jsonPayload = new JSONObject();
                jsonPayload.put("device_id", config.getDeviceId());
                jsonPayload.put("device_uid", config.getDeviceId());
                jsonPayload.put("device_secret", config.getDeviceSecret());
                jsonPayload.put("secret_key", config.getDeviceSecret());
                jsonPayload.put("api_key", config.getDeviceSecret());

                jsonPayload.put("provider", data.getProvider().getDisplayName());
                jsonPayload.put("provider_code", data.getProvider().getSettingsKey());
                jsonPayload.put("method", data.getProvider().getDisplayName());
                jsonPayload.put("type", data.getProvider().getDisplayName());

                jsonPayload.put("sender", data.getSender());
                jsonPayload.put("phone", data.getSender());
                jsonPayload.put("from_number", data.getSender());

                jsonPayload.put("amount", data.getAmount());
                jsonPayload.put("total_amount", data.getAmount());
                jsonPayload.put("price", data.getAmount());

                jsonPayload.put("txid", data.getTxid());
                jsonPayload.put("trxid", data.getTxid());
                jsonPayload.put("transaction_id", data.getTxid());

                jsonPayload.put("received_account", receiverNum);
                jsonPayload.put("receiver", receiverNum);
                jsonPayload.put("receiving_number", receiverNum);
                jsonPayload.put("account", receiverNum);

                jsonPayload.put("raw_sms", data.getRawSms());
                jsonPayload.put("sms_body", data.getRawSms());
                jsonPayload.put("full_sms", data.getRawSms());
                jsonPayload.put("message", data.getRawSms());

                jsonPayload.put("timestamp", now);
                jsonPayload.put("sms_time", now);
                jsonPayload.put("nonce", nonce);
                jsonPayload.put("signature", sig);
                jsonPayload.put("client_event_id", "evt_" + now + "_" + data.getTxid());

                String endpoint = config.getEndpointUrl("payment_receiver.php");
                String responseStr = executeHttpPost(context, endpoint, jsonPayload.toString());

                JSONObject responseJson = new JSONObject(responseStr);
                boolean success = responseJson.optBoolean("success", false)
                        || "success".equalsIgnoreCase(responseJson.optString("status", ""))
                        || "ok".equalsIgnoreCase(responseJson.optString("status", ""))
                        || responseJson.optInt("status", 0) == 200
                        || responseJson.optInt("code", 0) == 200;
                boolean exists = responseJson.optBoolean("already_exists", false)
                        || responseJson.optBoolean("exists", false)
                        || "exists".equalsIgnoreCase(responseJson.optString("status", ""));
                String message = responseJson.optString("message", responseJson.optString("msg", "OK"));
                String txid = responseJson.optString("txid", data.getTxid());

                if (responseJson.has("receivers") || responseJson.has("provider_numbers")) {
                    PhpConfigManager.getInstance(context).parseAndSaveProviderNumbers(responseJson);
                }

                if (success) {
                    if (exists) {
                        AppLogger.log("PHP API: Transaction " + txid + " already exists in MySQL database.");
                        if (callback != null) {
                            mainHandler.post(() -> callback.onAlreadyExists(txid));
                        }
                    } else {
                        AppLogger.log("PHP API: Transaction " + txid + " saved successfully to MySQL database.");
                        if (callback != null) {
                            mainHandler.post(() -> callback.onSuccess(txid));
                        }
                    }
                } else {
                    String errCode = responseJson.optString("error_code", "PHP_ERROR");
                    AppLogger.error("PHP API Error: " + errCode + " - " + message, null);
                    if (callback != null) {
                        mainHandler.post(() -> callback.onError(errCode, message));
                    }
                }

            } catch (Exception e) {
                AppLogger.error("PHP API Exception: " + e.getMessage(), e);
                if (callback != null) {
                    mainHandler.post(() -> callback.onError("NETWORK_ERROR", e.getMessage() != null ? e.getMessage() : "Connection failed"));
                }
            }
        });
    }

    public static void testConnection(@NonNull final Context context,
                                      @NonNull final String apiBaseUrl,
                                      @NonNull final String deviceSecret,
                                      @NonNull final ApiCallback callback) {
        executor.execute(() -> {
            try {
                String deviceId = PhpConfigManager.getInstance(context).getOrCreateDeviceId();
                PhpConfig testConfig = new PhpConfig(apiBaseUrl, deviceSecret, deviceId, true);
                if (!testConfig.isValid()) {
                    mainHandler.post(() -> callback.onError("INVALID_CONFIG", "Please provide a valid URL and device secret"));
                    return;
                }

                JSONObject jsonPayload = new JSONObject();
                jsonPayload.put("device_id", deviceId);
                jsonPayload.put("device_secret", deviceSecret);
                jsonPayload.put("action", "test_connection");

                String endpoint = testConfig.getEndpointUrl("connection_test.php");
                String responseStr = executeHttpPost(context, endpoint, jsonPayload.toString());

                JSONObject responseJson = new JSONObject(responseStr);
                boolean success = responseJson.optBoolean("success", false);
                String msg = responseJson.optString("message", "Connection successful");

                if (success) {
                    // Parse approved 'receivers' object from PHP server response
                    PhpConfigManager.getInstance(context).parseAndSaveProviderNumbers(responseJson);
                    mainHandler.post(() -> callback.onSuccess(deviceId, msg));
                } else {
                    String errCode = responseJson.optString("error_code", "AUTH_FAILED");
                    mainHandler.post(() -> callback.onError(errCode, msg));
                }
            } catch (Exception e) {
                mainHandler.post(() -> callback.onError("CONNECTION_FAILED", e.getMessage() != null ? e.getMessage() : "HTTP Connection error"));
            }
        });
    }

    /**
     * Sends the request through a real Chromium WebView first (passes Imunify360 / WAF bot
     * protection far more reliably than a plain Java HTTP client). If the WebView itself fails
     * for a non-firewall reason, falls back to HttpURLConnection that reuses the same cookies
     * and the same User-Agent as the WebView.
     */
    @NonNull
    private static String executeHttpPost(@NonNull Context context, @NonNull String urlStr, @NonNull String jsonBody) throws Exception {
        // Keep the b64 wrapper: the server side (sms_reader_common.php / getJsonInput) decodes it.
        String base64Payload = Base64.encodeToString(jsonBody.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        JSONObject wrapped = new JSONObject();
        wrapped.put("b64", base64Payload);
        final String finalPostBody = wrapped.toString();

        try {
            return PhpWebTransport.post(context, urlStr, finalPostBody);
        } catch (PhpWebTransport.BlockedException blocked) {
            // Firewall page: do NOT hammer the server again (that gets the IP graylisted).
            AppLogger.error("PHP API blocked by firewall: " + blocked.getMessage(), null);
            throw new Exception(blocked.getMessage());
        } catch (Exception webViewFailure) {
            AppLogger.log("WebView transport failed (" + webViewFailure.getMessage() + "), using HTTP fallback");
        }
        return executeUrlConnectionPost(context, urlStr, finalPostBody);
    }

    @NonNull
    private static String executeUrlConnectionPost(@NonNull Context context, @NonNull String urlStr, @NonNull String finalPostBody) throws Exception {
        final String userAgent = WebSettings.getDefaultUserAgent(context);
        int redirects = 0;
        String currentUrl = urlStr;

        while (redirects < 5) {
            URL url = new URL(currentUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setDoInput(true);
            conn.setDoOutput(true);

            conn.setRequestProperty("User-Agent", userAgent);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("Accept", "application/json, text/plain, */*");
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            conn.setRequestProperty("Cache-Control", "no-cache");

            // Reuse cookies that the verify dialog / WebView already earned (this was never sent before).
            String cookie = CookieManager.getInstance().getCookie(PhpWebTransport.originOf(currentUrl));
            if (cookie != null && !cookie.isEmpty()) {
                conn.setRequestProperty("Cookie", cookie);
            }

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = finalPostBody.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_MOVED_PERM || responseCode == HttpURLConnection.HTTP_MOVED_TEMP
                    || responseCode == 307 || responseCode == 308) {
                String location = conn.getHeaderField("Location");
                conn.disconnect();
                if (location != null && !location.isEmpty()) {
                    currentUrl = new URL(url, location).toString();
                    redirects++;
                    continue;
                }
            }

            InputStream is = (responseCode >= 200 && responseCode < 300) ? conn.getInputStream() : conn.getErrorStream();
            if (is == null) {
                conn.disconnect();
                throw new Exception("HTTP response empty, code: " + responseCode);
            }

            StringBuilder response = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line.trim());
                }
            } finally {
                conn.disconnect();
            }

            String respStr = response.toString();

            if (PhpWebTransport.looksBlocked(responseCode, respStr)) {
                throw new Exception("Imunify360 Bot Protection: Server firewall blocked request (HTTP "
                        + responseCode + "). Open PHP MySQL tab and tap VERIFY & UNBLOCK SERVER FIREWALL.");
            }
            if (responseCode >= 400 && !respStr.startsWith("{")) {
                throw new Exception("HTTP Error " + responseCode + ": " + (respStr.length() > 100 ? respStr.substring(0, 100) : respStr));
            }
            return respStr;
        }

        throw new Exception("Too many HTTP redirects");
    }
}
