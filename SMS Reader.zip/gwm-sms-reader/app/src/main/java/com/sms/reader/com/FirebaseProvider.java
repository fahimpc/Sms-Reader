package com.sms.reader.com;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Manages active Firebase Realtime Database and Authentication.
 * Supports dynamic project switching at runtime, automatic reconnection,
 * and persistent reader UID with Anonymous Authentication.
 */
public final class FirebaseProvider {

    public enum ConnectionState {
        CONNECTING,
        CONNECTED,
        DISCONNECTED,
        AUTH_ERROR
    }

    public interface StateListener {
        void onConnectionStateChanged(ConnectionState state);
        void onAuthUidChanged(String uid);
    }

    public interface TestCallback {
        void onSuccess(String uid, boolean isConnected);
        void onError(String message);
    }

    private static final String PREF_DEVICE_ID = "gwm_device_reader_uid";
    private static final String CUSTOM_APP_NAME = "gwm_active_custom_app";
    private static FirebaseProvider instance;

    private final Context appContext;
    private FirebaseApp currentApp;
    private FirebaseDatabase currentDatabase;
    private FirebaseAuth currentAuth;
    private FirebaseConfig activeConfig;

    private ConnectionState currentState = ConnectionState.CONNECTING;
    private boolean isRtdbConnected = false;
    private boolean isAnonymousAuthDisabledInConsole = false;
    private final List<StateListener> listeners = new ArrayList<>();
    private final String deviceReaderUid;
    private DatabaseReference connectedRef;
    private ValueEventListener connectedListener;

    public static synchronized FirebaseProvider getInstance(Context context) {
        if (instance == null) {
            instance = new FirebaseProvider(context.getApplicationContext());
        }
        return instance;
    }

    private FirebaseProvider(Context context) {
        this.appContext = context;
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context);
        }

        this.deviceReaderUid = getOrCreateDeviceUid(context);
        this.activeConfig = FirebaseConfigManager.getInstance(context).getActiveConfig();

        initializeActiveFirebase();
    }

    private void initializeActiveFirebase() {
        if (activeConfig == null || "DEFAULT_DELETED".equals(activeConfig.getProjectId()) || !activeConfig.isValid()) {
            this.currentApp = null;
            this.currentDatabase = null;
            this.currentAuth = null;
            updateState(ConnectionState.DISCONNECTED);
            AppLogger.log("Default Firebase project has been purged. No active Firebase project connected.");
            return;
        }

        try {
            FirebaseOptions defaultOptions = null;
            try {
                FirebaseApp defApp = FirebaseApp.getInstance();
                defaultOptions = defApp.getOptions();
            } catch (Exception ignored) {}

            boolean isPurged = FirebaseConfigManager.getInstance(appContext).isDefaultPurged();
            boolean defaultValidAndMatches = !isPurged
                    && defaultOptions != null
                    && activeConfig.getProjectId().equals(defaultOptions.getProjectId())
                    && activeConfig.getApiKey().equals(defaultOptions.getApiKey())
                    && !defaultOptions.getApiKey().contains("remixed")
                    && !defaultOptions.getApiKey().isEmpty();

            if (defaultValidAndMatches) {
                this.currentApp = FirebaseApp.getInstance();
                this.currentDatabase = FirebaseDatabase.getInstance(currentApp, activeConfig.getDatabaseUrl());
                this.currentAuth = FirebaseAuth.getInstance(currentApp);
            } else {
                FirebaseOptions.Builder optionsBuilder = new FirebaseOptions.Builder()
                        .setProjectId(activeConfig.getProjectId())
                        .setApplicationId(activeConfig.getApplicationId())
                        .setApiKey(activeConfig.getApiKey())
                        .setDatabaseUrl(activeConfig.getDatabaseUrl());
                if (!activeConfig.getStorageBucket().isEmpty()) {
                    optionsBuilder.setStorageBucket(activeConfig.getStorageBucket());
                }
                if (!activeConfig.getGcmSenderId().isEmpty()) {
                    optionsBuilder.setGcmSenderId(activeConfig.getGcmSenderId());
                }
                FirebaseOptions options = optionsBuilder.build();

                try {
                    FirebaseApp existing = FirebaseApp.getInstance(CUSTOM_APP_NAME);
                    existing.delete();
                } catch (Exception ignored) {}

                this.currentApp = FirebaseApp.initializeApp(appContext, options, CUSTOM_APP_NAME);
                this.currentDatabase = FirebaseDatabase.getInstance(currentApp, activeConfig.getDatabaseUrl());
                try {
                    this.currentDatabase.setPersistenceEnabled(true);
                } catch (Exception ignored) {}
                this.currentAuth = FirebaseAuth.getInstance(currentApp);
            }
        } catch (Exception e) {
            AppLogger.log("Notice initializing active Firebase: " + e.getMessage());
            boolean isPurged = FirebaseConfigManager.getInstance(appContext).isDefaultPurged();
            if (!isPurged) {
                try {
                    this.currentApp = FirebaseApp.getInstance();
                    this.currentDatabase = FirebaseDatabase.getInstance(AppConfig.FIREBASE_DATABASE_URL);
                    this.currentAuth = FirebaseAuth.getInstance();
                } catch (Exception ignored) {}
                this.activeConfig = FirebaseConfigManager.getInstance(appContext).getDefaultPackagedConfig();
            } else {
                this.currentApp = null;
                this.currentDatabase = null;
                this.currentAuth = null;
                this.activeConfig = FirebaseConfigManager.getInstance(appContext).getPurgedPlaceholderConfig();
                updateState(ConnectionState.DISCONNECTED);
                return;
            }
        }

        initConnectionListener();
        ensureAuthenticated();
    }

    public synchronized void reloadActiveConfig() {
        this.activeConfig = FirebaseConfigManager.getInstance(appContext).getActiveConfig();
        if (connectedRef != null && connectedListener != null) {
            try {
                connectedRef.removeEventListener(connectedListener);
            } catch (Exception ignored) {}
        }
        initializeActiveFirebase();
    }

    public synchronized FirebaseDatabase getDatabase() {
        return currentDatabase;
    }

    public synchronized FirebaseAuth getAuth() {
        return currentAuth;
    }

    public synchronized FirebaseConfig getActiveConfig() {
        return activeConfig;
    }

    public String getCurrentUid() {
        if (currentAuth != null) {
            FirebaseUser user = currentAuth.getCurrentUser();
            if (user != null && user.getUid() != null && !user.getUid().isEmpty()) {
                return user.getUid();
            }
        }
        return deviceReaderUid;
    }

    public ConnectionState getCurrentState() {
        return currentState;
    }

    public void addListener(StateListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
            listener.onConnectionStateChanged(currentState);
            listener.onAuthUidChanged(getCurrentUid());
        }
    }

    public void removeListener(StateListener listener) {
        listeners.remove(listener);
    }

    /**
     * Dynamically switches active Firebase instances when configuration changes.
     */
    public synchronized void applyNewConfig(@NonNull FirebaseConfig newConfig, @NonNull FirebaseOptions options) {
        AppLogger.log("FirebaseProvider: Switching active project to: " + newConfig.getProjectId());

        // Cleanly detach old connection listener
        detachConnectionListener();

        this.activeConfig = newConfig;

        try {
            if (newConfig.isDefault()) {
                this.currentApp = FirebaseApp.getInstance();
                this.currentDatabase = FirebaseDatabase.getInstance(newConfig.getDatabaseUrl());
                this.currentAuth = FirebaseAuth.getInstance();
            } else {
                try {
                    FirebaseApp existing = FirebaseApp.getInstance(CUSTOM_APP_NAME);
                    existing.delete();
                } catch (Exception ignored) {}

                this.currentApp = FirebaseApp.initializeApp(appContext, options, CUSTOM_APP_NAME);
                this.currentDatabase = FirebaseDatabase.getInstance(currentApp, newConfig.getDatabaseUrl());
                this.currentAuth = FirebaseAuth.getInstance(currentApp);
            }
        } catch (Exception e) {
            AppLogger.error("Failed to apply new Firebase config: " + e.getMessage(), e);
        }

        // Reconnect connection listener and settings repository
        initConnectionListener();
        ensureAuthenticated();
        SettingsRepository.getInstance(appContext).reconnect(currentDatabase);

        // Broadcast to application components
        Intent broadcast = new Intent(AppConfig.ACTION_FIREBASE_STATE_CHANGED);
        broadcast.setPackage(appContext.getPackageName());
        appContext.sendBroadcast(broadcast);
    }

    public synchronized void disconnectAndClear() {
        detachConnectionListener();
        try {
            if (currentApp != null && !currentApp.getName().equals(FirebaseApp.DEFAULT_APP_NAME)) {
                currentApp.delete();
            }
        } catch (Exception ignored) {}
        this.currentApp = null;
        this.currentDatabase = null;
        this.currentAuth = null;
        this.activeConfig = FirebaseConfigManager.getInstance(appContext).getPurgedPlaceholderConfig();
        updateState(ConnectionState.DISCONNECTED);
        AppLogger.log("FirebaseProvider cleanly disconnected and cleared.");

        Intent broadcast = new Intent(AppConfig.ACTION_FIREBASE_STATE_CHANGED);
        broadcast.setPackage(appContext.getPackageName());
        appContext.sendBroadcast(broadcast);
    }

    public void ensureAuthenticated() {
        if (currentAuth == null) return;

        FirebaseUser currentUser = null;
        try {
            currentUser = currentAuth.getCurrentUser();
        } catch (Exception ignored) {}

        if (currentUser != null) {
            AppLogger.log("Firebase Auth ready: UID " + currentUser.getUid());
            updateState(isRtdbConnected ? ConnectionState.CONNECTED : ConnectionState.CONNECTING);
            notifyUid(currentUser.getUid());
            return;
        }

        notifyUid(deviceReaderUid);

        AppLogger.log("Authenticating reader device with active Firebase (" + activeConfig.getProjectId() + ")...");
        try {
            currentAuth.signInAnonymously()
                    .addOnSuccessListener(authResult -> {
                        FirebaseUser user = authResult.getUser();
                        String uid = user != null ? user.getUid() : deviceReaderUid;
                        isAnonymousAuthDisabledInConsole = false;
                        AppLogger.log("Firebase Auth active: UID " + uid);
                        updateState(isRtdbConnected ? ConnectionState.CONNECTED : ConnectionState.CONNECTING);
                        notifyUid(uid);
                    })
                    .addOnFailureListener(e -> {
                        String msg = e.getMessage() != null ? e.getMessage() : "";
                        isAnonymousAuthDisabledInConsole = true;
                        AppLogger.log("Firebase Auth notice: " + msg);
                        AppLogger.log("Continuing with persistent Reader UID: " + deviceReaderUid);
                        updateState(isRtdbConnected ? ConnectionState.CONNECTED : ConnectionState.CONNECTING);
                        notifyUid(deviceReaderUid);
                    });
        } catch (Exception ex) {
            AppLogger.log("Firebase Auth request note: " + ex.getMessage());
            updateState(isRtdbConnected ? ConnectionState.CONNECTED : ConnectionState.CONNECTING);
            notifyUid(deviceReaderUid);
        }
    }

    private synchronized void detachConnectionListener() {
        if (connectedRef != null && connectedListener != null) {
            try {
                connectedRef.removeEventListener(connectedListener);
            } catch (Exception ignored) {}
        }
        connectedRef = null;
        connectedListener = null;
    }

    private synchronized void initConnectionListener() {
        detachConnectionListener();
        if (currentDatabase == null) return;

        try {
            currentDatabase.goOnline();
        } catch (Exception ignored) {}

        connectedRef = currentDatabase.getReference(".info/connected");
        connectedListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Boolean connected = snapshot.getValue(Boolean.class);
                isRtdbConnected = Boolean.TRUE.equals(connected);
                if (isRtdbConnected) {
                    updateState(ConnectionState.CONNECTED);
                    AppLogger.log("Firebase RTDB status: CONNECTED (" + activeConfig.getProjectId() + ")");
                } else if (activeConfig != null && activeConfig.isValid() && !"DEFAULT_DELETED".equals(activeConfig.getProjectId())) {
                    // Valid active Firebase project is configured; stay CONNECTED so background idle socket drops don't reset app status!
                    updateState(ConnectionState.CONNECTED);
                    AppLogger.log("Firebase RTDB status: RECONNECTING/IDLE (" + activeConfig.getProjectId() + ")");
                } else {
                    updateState(ConnectionState.DISCONNECTED);
                    AppLogger.log("Firebase RTDB status: DISCONNECTED");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                AppLogger.error("Firebase connection listener error: " + error.getMessage(), error.toException());
            }
        };
        connectedRef.addValueEventListener(connectedListener);
    }

    public void testConnection(final TestCallback callback) {
        if (currentAuth == null) {
            if (callback != null) callback.onError("Auth service not initialized");
            return;
        }

        FirebaseUser user = currentAuth.getCurrentUser();
        if (user != null) {
            if (callback != null) {
                callback.onSuccess(user.getUid(), isRtdbConnected);
            }
            return;
        }

        try {
            currentAuth.signInAnonymously()
                    .addOnSuccessListener(authResult -> {
                        FirebaseUser u = authResult.getUser();
                        String uid = u != null ? u.getUid() : deviceReaderUid;
                        notifyUid(uid);
                        if (callback != null) {
                            callback.onSuccess(uid, isRtdbConnected);
                        }
                    })
                    .addOnFailureListener(e -> {
                        String msg = e.getMessage() != null ? e.getMessage() : "";
                        AppLogger.log("Firebase Auth notice during test: " + msg);
                        AppLogger.log("Reader UID: " + deviceReaderUid);
                        if (callback != null) {
                            callback.onSuccess(deviceReaderUid + " (Device UID)", isRtdbConnected);
                        }
                    });
        } catch (Exception ex) {
            AppLogger.log("Firebase Auth test exception: " + ex.getMessage());
            if (callback != null) {
                callback.onSuccess(deviceReaderUid + " (Device UID)", isRtdbConnected);
            }
        }
    }

    private void updateState(ConnectionState state) {
        this.currentState = state;
        for (StateListener l : listeners) {
            l.onConnectionStateChanged(state);
        }
    }

    private void notifyUid(String uid) {
        for (StateListener l : listeners) {
            l.onAuthUidChanged(uid);
        }
    }

    private static String getOrCreateDeviceUid(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("gwm_reader_id", Context.MODE_PRIVATE);
        String id = prefs.getString(PREF_DEVICE_ID, null);
        if (id == null || id.isEmpty() || id.startsWith("gwm-reader-")) {
            id = "sms-reader-" + UUID.randomUUID().toString().substring(0, 16);
            prefs.edit().putString(PREF_DEVICE_ID, id).apply();
        }
        return id;
    }
}
