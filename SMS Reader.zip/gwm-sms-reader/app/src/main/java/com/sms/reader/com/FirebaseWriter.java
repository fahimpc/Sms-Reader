package com.sms.reader.com;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import java.util.Map;

/**
 * Handles atomic, safe uploads to Firebase Realtime Database:
 * XNXANIKPAY/<TRX_ID>
 *
 * Implements strict duplicate protection:
 * If the transaction record already exists, it is NEVER overwritten
 * and fields such as used, usedBy, usedAt are left completely untouched.
 */
public final class FirebaseWriter {

    public interface UploadCallback {
        void onSuccess(String txid);
        void onAlreadyExists(String txid);
        void onError(String errorCode, String message);
    }

    private FirebaseWriter() {
    }

    public static void uploadTransaction(Context context, final PaymentData data, final UploadCallback callback) {
        if (data == null) {
            if (callback != null) callback.onError("PARSER_FAILED", "Transaction data is null");
            return;
        }

        // Verify provider enabled status
        boolean isEnabled = SettingsRepository.getInstance(context).isProviderEnabled(data.getProvider());
        if (!isEnabled) {
            AppLogger.log("PROVIDER_DISABLED: " + data.getProviderName() + " is currently disabled by Admin.");
            if (callback != null) callback.onError("PROVIDER_DISABLED", data.getProviderName() + " is disabled");
            return;
        }

        FirebaseProvider fbProvider = FirebaseProvider.getInstance(context);
        fbProvider.ensureAuthenticated();

        FirebaseDatabaseHelper.getInstance(context).pushParsedSms(data, new FirebaseDatabaseHelper.PushCallback() {
            @Override
            public void onSuccess(String txid) {
                if (callback != null) callback.onSuccess(txid);
            }

            @Override
            public void onAlreadyExists(String txid) {
                if (callback != null) callback.onAlreadyExists(txid);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (callback != null) callback.onError(errorCode, errorMessage);
            }
        });
    }

    public static void uploadTransaction(Context context, String provider, String sender, String amount, String txid, final UploadCallback callback) {
        Provider p = Provider.fromString(provider);
        PaymentData data = new PaymentData(p, amount, sender, txid, "", sender, System.currentTimeMillis());
        uploadTransaction(context, data, callback);
    }
}
