package com.sms.reader.com;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Durable SQLite Database OpenHelper for persistent Payment SMS Queue.
 * Persists offline, pending, failed, synced, and needs-attention records across
 * process terminations, phone restarts, and network disconnections.
 */
public final class SmsSyncSQLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "sms_sync_queue_v1.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "sms_sync_queue";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_IDEMPOTENCY_KEY = "idempotency_key";
    public static final String COLUMN_DEVICE_ID = "device_id";
    public static final String COLUMN_PROVIDER = "provider";
    public static final String COLUMN_RECEIVING_NUMBER = "receiving_number";
    public static final String COLUMN_SENDER = "sender";
    public static final String COLUMN_AMOUNT = "amount";
    public static final String COLUMN_TXID = "txid";
    public static final String COLUMN_TIMESTAMP = "timestamp";
    public static final String COLUMN_RAW_SMS = "raw_sms";
    public static final String COLUMN_BACKEND_MODE = "backend_mode";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_FAILURE_REASON = "failure_reason";
    public static final String COLUMN_RETRY_COUNT = "retry_count";
    public static final String COLUMN_NEXT_RETRY_TIME = "next_retry_time";
    public static final String COLUMN_SYNCED_TIMESTAMP = "synced_timestamp";
    public static final String COLUMN_SERVER_ACK = "server_ack_metadata";

    private static SmsSyncSQLiteHelper instance;

    public static synchronized SmsSyncSQLiteHelper getInstance(Context context) {
        if (instance == null) {
            instance = new SmsSyncSQLiteHelper(context.getApplicationContext());
        }
        return instance;
    }

    private SmsSyncSQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_IDEMPOTENCY_KEY + " TEXT UNIQUE, " +
                COLUMN_DEVICE_ID + " TEXT, " +
                COLUMN_PROVIDER + " TEXT, " +
                COLUMN_RECEIVING_NUMBER + " TEXT, " +
                COLUMN_SENDER + " TEXT, " +
                COLUMN_AMOUNT + " TEXT, " +
                COLUMN_TXID + " TEXT, " +
                COLUMN_TIMESTAMP + " INTEGER, " +
                COLUMN_RAW_SMS + " TEXT, " +
                COLUMN_BACKEND_MODE + " TEXT, " +
                COLUMN_STATUS + " TEXT, " +
                COLUMN_FAILURE_REASON + " TEXT, " +
                COLUMN_RETRY_COUNT + " INTEGER DEFAULT 0, " +
                COLUMN_NEXT_RETRY_TIME + " INTEGER DEFAULT 0, " +
                COLUMN_SYNCED_TIMESTAMP + " INTEGER DEFAULT 0, " +
                COLUMN_SERVER_ACK + " TEXT);";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Safe database migrations
    }

    public synchronized long insertRecord(@NonNull SmsSyncEntity record) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IDEMPOTENCY_KEY, record.getIdempotencyKey());
        cv.put(COLUMN_DEVICE_ID, record.getDeviceId());
        cv.put(COLUMN_PROVIDER, record.getProvider());
        cv.put(COLUMN_RECEIVING_NUMBER, record.getReceivingNumber());
        cv.put(COLUMN_SENDER, record.getSender());
        cv.put(COLUMN_AMOUNT, record.getAmount());
        cv.put(COLUMN_TXID, record.getTxid());
        cv.put(COLUMN_TIMESTAMP, record.getTimestamp());
        cv.put(COLUMN_RAW_SMS, record.getRawSms());
        cv.put(COLUMN_BACKEND_MODE, record.getBackendMode());
        cv.put(COLUMN_STATUS, record.getStatus());
        cv.put(COLUMN_FAILURE_REASON, record.getFailureReason());
        cv.put(COLUMN_RETRY_COUNT, record.getRetryCount());
        cv.put(COLUMN_NEXT_RETRY_TIME, record.getNextRetryTime());
        cv.put(COLUMN_SYNCED_TIMESTAMP, record.getSyncedTimestamp());
        cv.put(COLUMN_SERVER_ACK, record.getServerAckMetadata());

        try {
            return db.insertWithOnConflict(TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        } catch (Exception e) {
            return -1L;
        }
    }

    public synchronized void updateStatus(long id, @NonNull String status, @Nullable String failureReason, int retryCount, long nextRetryTime) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_STATUS, status);
        if (failureReason != null) {
            cv.put(COLUMN_FAILURE_REASON, failureReason);
        }
        cv.put(COLUMN_RETRY_COUNT, retryCount);
        cv.put(COLUMN_NEXT_RETRY_TIME, nextRetryTime);
        if ("SYNCED".equals(status)) {
            cv.put(COLUMN_SYNCED_TIMESTAMP, System.currentTimeMillis());
        }
        db.update(TABLE_NAME, cv, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public synchronized void markSynced(long id, @Nullable String serverAck) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_STATUS, "SYNCED");
        cv.put(COLUMN_FAILURE_REASON, "Synced Successfully");
        cv.put(COLUMN_SYNCED_TIMESTAMP, System.currentTimeMillis());
        if (serverAck != null) {
            cv.put(COLUMN_SERVER_ACK, serverAck);
        }
        db.update(TABLE_NAME, cv, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    @NonNull
    public synchronized List<SmsSyncEntity> getPendingRetryableRecords() {
        return getRecordsByQuery(COLUMN_STATUS + " IN ('OFFLINE', 'SERVER_FAILED', 'PENDING') AND " + COLUMN_STATUS + " != 'NEEDS_ATTENTION'");
    }

    @NonNull
    public synchronized List<SmsSyncEntity> getAllRecords() {
        return getRecordsByQuery(null);
    }

    @NonNull
    public synchronized List<SmsSyncEntity> getRecordsByStatusFilter(@Nullable String filterStatus) {
        if (filterStatus == null || "ALL".equalsIgnoreCase(filterStatus)) {
            return getAllRecords();
        }
        return getRecordsByQuery(COLUMN_STATUS + " = ?", new String[]{filterStatus.toUpperCase()});
    }

    public synchronized int getCountByStatus(@NonNull String status) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE " + COLUMN_STATUS + " = ?", new String[]{status.toUpperCase()});
            if (c.moveToFirst()) {
                return c.getInt(0);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return 0;
    }

    public synchronized long getLastSyncedTimestamp() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT MAX(" + COLUMN_SYNCED_TIMESTAMP + ") FROM " + TABLE_NAME + " WHERE " + COLUMN_STATUS + " = 'SYNCED'", null);
            if (c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return 0L;
    }

    @NonNull
    private List<SmsSyncEntity> getRecordsByQuery(@Nullable String selection) {
        return getRecordsByQuery(selection, null);
    }

    @NonNull
    private List<SmsSyncEntity> getRecordsByQuery(@Nullable String selection, @Nullable String[] selectionArgs) {
        List<SmsSyncEntity> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, COLUMN_ID + " DESC");
            if (c != null && c.moveToFirst()) {
                do {
                    SmsSyncEntity record = new SmsSyncEntity();
                    record.setId(c.getLong(c.getColumnIndexOrThrow(COLUMN_ID)));
                    record.setIdempotencyKey(c.getString(c.getColumnIndexOrThrow(COLUMN_IDEMPOTENCY_KEY)));
                    record.setDeviceId(c.getString(c.getColumnIndexOrThrow(COLUMN_DEVICE_ID)));
                    record.setProvider(c.getString(c.getColumnIndexOrThrow(COLUMN_PROVIDER)));
                    record.setReceivingNumber(c.getString(c.getColumnIndexOrThrow(COLUMN_RECEIVING_NUMBER)));
                    record.setSender(c.getString(c.getColumnIndexOrThrow(COLUMN_SENDER)));
                    record.setAmount(c.getString(c.getColumnIndexOrThrow(COLUMN_AMOUNT)));
                    record.setTxid(c.getString(c.getColumnIndexOrThrow(COLUMN_TXID)));
                    record.setTimestamp(c.getLong(c.getColumnIndexOrThrow(COLUMN_TIMESTAMP)));
                    record.setRawSms(c.getString(c.getColumnIndexOrThrow(COLUMN_RAW_SMS)));
                    record.setBackendMode(c.getString(c.getColumnIndexOrThrow(COLUMN_BACKEND_MODE)));
                    record.setStatus(c.getString(c.getColumnIndexOrThrow(COLUMN_STATUS)));
                    record.setFailureReason(c.getString(c.getColumnIndexOrThrow(COLUMN_FAILURE_REASON)));
                    record.setRetryCount(c.getInt(c.getColumnIndexOrThrow(COLUMN_RETRY_COUNT)));
                    record.setNextRetryTime(c.getLong(c.getColumnIndexOrThrow(COLUMN_NEXT_RETRY_TIME)));
                    record.setSyncedTimestamp(c.getLong(c.getColumnIndexOrThrow(COLUMN_SYNCED_TIMESTAMP)));
                    record.setServerAckMetadata(c.getString(c.getColumnIndexOrThrow(COLUMN_SERVER_ACK)));
                    list.add(record);
                } while (c.moveToNext());
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return list;
    }
}
