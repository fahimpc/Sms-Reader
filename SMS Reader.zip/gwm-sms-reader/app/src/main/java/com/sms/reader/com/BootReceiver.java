package com.sms.reader.com;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Restores GWM SMS Reader persistent foreground service, notification, and Firebase sync
 * after device reboot or package update.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        AppLogger.log("Boot / update event detected: " + intent.getAction() + ". Restoring persistent reader...");

        // Restore foreground service and notification
        SmsReaderForegroundService.startService(context);
        NotificationHelper.getInstance(context).showActiveNotification();

        // Ensure Firebase and Admin Settings are active
        FirebaseProvider.getInstance(context).ensureAuthenticated();
        SettingsRepository.getInstance(context);
    }
}
