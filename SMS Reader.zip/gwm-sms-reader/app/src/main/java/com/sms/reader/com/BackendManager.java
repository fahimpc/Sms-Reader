package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;

/**
 * Manages dual backend selection and payment upload dispatching between:
 * 1. FIREBASE (Existing Firebase Realtime Database)
 * 2. PHP_MYSQL (Secure PHP API + MySQL Database)
 *
 * Guarantees completely isolated execution so PHP errors never impact Firebase,
 * and Firebase settings never overwrite PHP API settings.
 */
public final class BackendManager {

    public enum BackendMode {
        FIREBASE("Firebase Realtime DB"),
        PHP_MYSQL("PHP API + MySQL");

        private final String displayName;

        BackendMode(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    private static final String PREFS_NAME = "gwm_backend_selection_prefs";
    private static final String KEY_ACTIVE_MODE = "active_backend_mode";

    private static BackendManager instance;

    private final Context appContext;
    private final SharedPreferences prefs;

    public static synchronized BackendManager getInstance(Context context) {
        if (instance == null) {
            instance = new BackendManager(context.getApplicationContext());
        }
        return instance;
    }

    private BackendManager(Context context) {
        this.appContext = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    @NonNull
    public BackendMode getActiveMode() {
        String modeName = prefs.getString(KEY_ACTIVE_MODE, BackendMode.FIREBASE.name());
        try {
            return BackendMode.valueOf(modeName);
        } catch (Exception e) {
            return BackendMode.FIREBASE;
        }
    }

    public void setBackendMode(@NonNull BackendMode mode) {
        prefs.edit().putString(KEY_ACTIVE_MODE, mode.name()).apply();
        AppLogger.log("Active Backend switched to: " + mode.getDisplayName());

        if (mode == BackendMode.FIREBASE) {
            PhpConfigManager.getInstance(appContext).clearConfig();
        } else if (mode == BackendMode.PHP_MYSQL) {
            FirebaseConfigManager.getInstance(appContext).clearActiveConfig();
            FirebaseProvider.getInstance(appContext).disconnectAndClear();
        }
    }

    public boolean isFirebaseMode() {
        return getActiveMode() == BackendMode.FIREBASE;
    }

    public boolean isPhpMode() {
        return getActiveMode() == BackendMode.PHP_MYSQL;
    }

    /**
     * Atomically dispatches payment transaction upload to the active backend.
     */
    public void uploadTransaction(Context context, PaymentData data, FirebaseWriter.UploadCallback callback) {
        BackendMode mode = getActiveMode();
        if (mode == BackendMode.PHP_MYSQL) {
            AppLogger.log("Dispatching payment to PHP API Backend for TrxID: " + data.getTxid());
            PhpWriter.uploadTransaction(context, data, callback);
        } else {
            AppLogger.log("Dispatching payment to Firebase Realtime Database for TrxID: " + data.getTxid());
            FirebaseWriter.uploadTransaction(context, data, callback);
        }
    }
}
