package com.sms.reader.com;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Details Dialog for Payment SMS Sync Center V1.0.
 * Displays offline, failed, pending, synced, and needs_attention queued SMS records,
 * allowing manual retries, filtering, and Auto Sync toggling.
 */
public final class SyncCenterDetailsDialog {

    private final Context context;
    private final BottomSheetDialog sheet;
    private final View dialogView;

    private final SwitchCompat switchAutoSync;
    private final LinearLayout containerItems;
    private final Button btnFilterAll, btnFilterOffline, btnFilterFailed, btnFilterPending, btnFilterSynced;
    private final AppCompatButton btnRetryAll, btnRefresh;

    private String currentFilter = "ALL";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public SyncCenterDetailsDialog(@NonNull Context context) {
        this.context = context;
        this.dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_sync_center, null);
        this.sheet = new BottomSheetDialog(context);
        this.sheet.setContentView(dialogView);

        if (sheet.getBehavior() != null) {
            sheet.getBehavior().setSkipCollapsed(true);
            sheet.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
            sheet.getBehavior().setPeekHeight((int) (context.getResources().getDisplayMetrics().heightPixels * 0.85));
        }

        this.switchAutoSync = dialogView.findViewById(R.id.switchAutoSyncDetails);
        this.containerItems = dialogView.findViewById(R.id.layoutQueuedSmsItemsContainer);
        this.btnFilterAll = dialogView.findViewById(R.id.btnFilterAll);
        this.btnFilterOffline = dialogView.findViewById(R.id.btnFilterOffline);
        this.btnFilterFailed = dialogView.findViewById(R.id.btnFilterFailed);
        this.btnFilterPending = dialogView.findViewById(R.id.btnFilterPending);
        this.btnFilterSynced = dialogView.findViewById(R.id.btnFilterSynced);
        this.btnRetryAll = dialogView.findViewById(R.id.btnRetryAllInDetails);
        this.btnRefresh = dialogView.findViewById(R.id.btnRefreshSyncDetails);

        AppCompatImageButton btnClose = dialogView.findViewById(R.id.btnCloseSyncDetailsDialog);
        if (btnClose != null) btnClose.setOnClickListener(v -> sheet.dismiss());

        setupListeners();
        populateList();
    }

    public void show() {
        sheet.show();
    }

    private void setupListeners() {
        SmsSyncManager syncMgr = SmsSyncManager.getInstance(context);
        switchAutoSync.setChecked(syncMgr.isAutoSyncEnabled());

        switchAutoSync.setOnCheckedChangeListener((buttonView, isChecked) -> {
            syncMgr.setAutoSyncEnabled(isChecked);
            Toast.makeText(context, "Auto Sync set to " + (isChecked ? "ON" : "OFF"), Toast.LENGTH_SHORT).show();
        });

        btnFilterAll.setOnClickListener(v -> setFilter("ALL", btnFilterAll));
        btnFilterOffline.setOnClickListener(v -> setFilter("OFFLINE", btnFilterOffline));
        btnFilterFailed.setOnClickListener(v -> setFilter("SERVER_FAILED", btnFilterFailed));
        btnFilterPending.setOnClickListener(v -> setFilter("PENDING", btnFilterPending));
        btnFilterSynced.setOnClickListener(v -> setFilter("SYNCED", btnFilterSynced));

        btnRetryAll.setOnClickListener(v -> {
            if (!syncMgr.isNetworkConnected()) {
                Toast.makeText(context, "Waiting for Internet Connection...", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(context, "Retrying all pending SMS...", Toast.LENGTH_SHORT).show();
            syncMgr.syncPendingQueue((success, failed) -> mainHandler.post(() -> {
                populateList();
                Toast.makeText(context, "Sync complete: " + success + " Synced, " + failed + " Failed", Toast.LENGTH_SHORT).show();
            }));
        });

        btnRefresh.setOnClickListener(v -> populateList());
    }

    private void setFilter(String filter, Button activeBtn) {
        this.currentFilter = filter;

        int darkBg = Color.parseColor("#1E293B");
        int activeBg = ThemeManager.getInstance(context).getPrimaryColor();

        btnFilterAll.setBackgroundColor(darkBg);
        btnFilterOffline.setBackgroundColor(darkBg);
        btnFilterFailed.setBackgroundColor(darkBg);
        btnFilterPending.setBackgroundColor(darkBg);
        btnFilterSynced.setBackgroundColor(darkBg);

        activeBtn.setBackgroundColor(activeBg);
        populateList();
    }

    private void populateList() {
        containerItems.removeAllViews();
        SmsSyncManager syncMgr = SmsSyncManager.getInstance(context);
        List<SmsSyncEntity> list = syncMgr.getRecordsForFilter(currentFilter);

        if (list.isEmpty()) {
            TextView tvEmpty = new TextView(context);
            tvEmpty.setText("No records found for filter: " + currentFilter);
            tvEmpty.setTextColor(Color.parseColor("#94A3B8"));
            tvEmpty.setTextSize(13);
            tvEmpty.setPadding(0, 40, 0, 40);
            tvEmpty.setGravity(Gravity.CENTER);
            containerItems.addView(tvEmpty);
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy hh:mm a", Locale.US);

        for (SmsSyncEntity record : list) {
            LinearLayout itemBox = new LinearLayout(context);
            itemBox.setOrientation(LinearLayout.VERTICAL);
            itemBox.setPadding(30, 24, 30, 24);
            itemBox.setBackgroundResource(R.drawable.bg_card_inner);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 12, 0, 0);
            itemBox.setLayoutParams(lp);

            // Row 1: Provider + Amount + Status Badge
            LinearLayout row1 = new LinearLayout(context);
            row1.setOrientation(LinearLayout.HORIZONTAL);

            TextView tvProvAmt = new TextView(context);
            tvProvAmt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
            tvProvAmt.setText(record.getProvider() + " • ৳ " + record.getAmount());
            tvProvAmt.setTextColor(Color.WHITE);
            tvProvAmt.setTextSize(14);
            tvProvAmt.setTypeface(null, Typeface.BOLD);

            TextView tvBadge = new TextView(context);
            tvBadge.setPadding(20, 6, 20, 6);
            tvBadge.setBackgroundResource(R.drawable.bg_pin_card);
            tvBadge.setTextSize(10);
            tvBadge.setTypeface(null, Typeface.BOLD);

            String status = record.getStatus();
            if ("SYNCED".equalsIgnoreCase(status)) {
                tvBadge.setText("SYNCED");
                tvBadge.setTextColor(ContextCompat.getColor(context, R.color.status_green));
            } else if ("OFFLINE".equalsIgnoreCase(status)) {
                tvBadge.setText("OFFLINE");
                tvBadge.setTextColor(ContextCompat.getColor(context, R.color.status_amber));
            } else if ("SERVER_FAILED".equalsIgnoreCase(status)) {
                tvBadge.setText("FAILED");
                tvBadge.setTextColor(ContextCompat.getColor(context, R.color.status_red));
            } else if ("SYNCING".equalsIgnoreCase(status)) {
                tvBadge.setText("SYNCING...");
                tvBadge.setTextColor(Color.parseColor("#38BDF8"));
            } else {
                tvBadge.setText("PENDING");
                tvBadge.setTextColor(Color.parseColor("#38BDF8"));
            }

            row1.addView(tvProvAmt);
            row1.addView(tvBadge);
            itemBox.addView(row1);

            // Row 2: Sender & TrxID
            TextView tvDetails = new TextView(context);
            tvDetails.setText("From: " + record.getSender() + " | TrxID: " + record.getTxid() + "\nTime: " + sdf.format(new Date(record.getTimestamp())) + " | Backend: " + record.getBackendMode());
            tvDetails.setTextColor(Color.parseColor("#94A3B8"));
            tvDetails.setTextSize(11);
            tvDetails.setPadding(0, 8, 0, 0);
            itemBox.addView(tvDetails);

            // Row 3: Failure Reason (if present)
            if (!record.getFailureReason().isEmpty() && !"Synced Successfully".equalsIgnoreCase(record.getFailureReason())) {
                TextView tvReason = new TextView(context);
                tvReason.setText("Reason: " + record.getFailureReason() + " (Retry #" + record.getRetryCount() + ")");
                tvReason.setTextColor(Color.parseColor("#EF4444"));
                tvReason.setTextSize(11);
                tvReason.setPadding(0, 4, 0, 0);
                itemBox.addView(tvReason);
            }

            // Retry Button for unsynced records
            if (!"SYNCED".equalsIgnoreCase(status)) {
                Button btnItemRetry = new Button(context);
                btnItemRetry.setText("🔄 Retry Now");
                btnItemRetry.setTextColor(Color.WHITE);
                btnItemRetry.setBackgroundResource(R.drawable.bg_button_secondary);
                LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 100);
                lpBtn.setMargins(0, 16, 0, 0);
                btnItemRetry.setLayoutParams(lpBtn);

                btnItemRetry.setOnClickListener(v -> {
                    Toast.makeText(context, "Retrying SMS " + record.getTxid() + "...", Toast.LENGTH_SHORT).show();
                    syncMgr.retrySingleRecord(record.getId(), (success, failed) -> mainHandler.post(() -> {
                        populateList();
                        Toast.makeText(context, success > 0 ? "SMS Synced Successfully!" : "Retry Failed. Kept in Queue.", Toast.LENGTH_SHORT).show();
                    }));
                });
                itemBox.addView(btnItemRetry);
            }

            containerItems.addView(itemBox);
        }
    }
}
