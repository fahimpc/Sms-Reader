package com.sms.reader.com;

import com.google.firebase.database.ServerValue;
import java.util.HashMap;
import java.util.Map;

/**
 * Encapsulates extracted payment transaction details.
 */
public class PaymentData {

    private final Provider provider;
    private final String amount;
    private final String agent;
    private final String txid;
    private final String rawSms;
    private final String sender;
    private final long timestamp;
    private final AiFraudResult aiResult;

    public PaymentData(Provider provider, String amount, String agent, String txid,
                       String rawSms, String sender, long timestamp) {
        this.provider = provider != null ? provider : Provider.UNKNOWN;
        this.amount = amount != null ? amount : "";
        this.agent = agent != null ? agent : "";
        this.txid = txid != null ? txid : "";
        this.rawSms = rawSms != null ? rawSms : "";
        this.sender = sender != null ? sender : "";
        this.timestamp = timestamp > 0 ? timestamp : System.currentTimeMillis();
        this.aiResult = AiFraudDetector.evaluate(this);
    }

    public AiFraudResult getAiResult() {
        return aiResult;
    }

    public Provider getProvider() {
        return provider;
    }

    public String getTypeCode() {
        return provider.getTypeCode();
    }

    public String getProviderName() {
        return provider.getDisplayName();
    }

    public String getAmount() {
        return amount;
    }

    public String getAgent() {
        return agent;
    }

    public String getTxid() {
        return txid;
    }

    public String getRawSms() {
        return rawSms;
    }

    public String getSender() {
        return sender;
    }

    public long getTimestamp() {
        return timestamp;
    }

    /**
     * Converts to the exact Firebase Map structure required by website:
     * XNXANIKPAY/<TRX_ID>
     *   type: "B"
     *   provider: "bKash"
     *   amount: "510.00"
     *   agent: "01737078264"
     *   txid: "DJ118THL8D"
     *   used: false
     *   receivedAt: SERVER_TIMESTAMP
     */
    public Map<String, Object> toFirebaseMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("type", getTypeCode());
        map.put("provider", getProviderName());
        map.put("amount", getAmount());
        map.put("agent", getAgent());
        map.put("txid", getTxid());
        map.put("used", false);
        map.put("receivedAt", ServerValue.TIMESTAMP);
        return map;
    }

    @Override
    public String toString() {
        return "PaymentData{" +
                "provider=" + provider +
                ", amount='" + amount + '\'' +
                ", agent='" + agent + '\'' +
                ", txid='" + txid + '\'' +
                '}';
    }
}
