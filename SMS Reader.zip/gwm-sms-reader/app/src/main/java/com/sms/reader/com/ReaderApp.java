package com.sms.reader.com;

import android.app.Application;

/**
 * Custom Application class for GWM SMS Reader.
 * Initializes Firebase, persistent Foreground Service, notification, and Admin settings.
 */
public class ReaderApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        AppLogger.log("GWM SMS Reader Application initializing...");

        // Ensure persistent foreground service is running
        SmsReaderForegroundService.startService(this);

        // Initialize Firebase Authentication and Realtime Database
        FirebaseProvider.getInstance(this);

        // Initialize persistent notification
        NotificationHelper.getInstance(this).showActiveNotification();

        // Initialize real-time Admin settings repository
        SettingsRepository.getInstance(this);

        AppLogger.log("Application started successfully. Ready.");
    }
}
