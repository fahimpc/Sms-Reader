package com.sms.reader.com;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;

/**
 * Foreground Service that maintains the persistent "GWM SMS Reader Active" notification
 * and guarantees reader priority in background across all Android versions.
 *
 * Implements START_STICKY and handles Android 14+ DATA_SYNC foreground service requirements.
 */
public class SmsReaderForegroundService extends Service {

    public static void startService(Context context) {
        if (context == null) return;
        try {
            Intent intent = new Intent(context, SmsReaderForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception e) {
            AppLogger.error("Could not start SmsReaderForegroundService: " + e.getMessage(), e);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        AppLogger.log("SmsReaderForegroundService started.");
        startForegroundInternal();

        // Ensure background Firebase and admin settings are active
        FirebaseProvider.getInstance(this);
        SettingsRepository.getInstance(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundInternal();
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        AppLogger.log("Task removed (Recent apps swiped). Immediately refreshing persistent foreground notification...");
        startForegroundInternal();
        scheduleAutoRestart(this);
    }

    private void startForegroundInternal() {
        try {
            Notification notification = NotificationHelper.getInstance(this).getForegroundNotification();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(AppConfig.NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(AppConfig.NOTIFICATION_ID, notification);
            }
        } catch (Exception e) {
            AppLogger.error("Failed to enter foreground service mode: " + e.getMessage(), e);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        AppLogger.log("SmsReaderForegroundService stopping. Rescheduling resurrection...");
        scheduleAutoRestart(this);
    }

    /**
     * Schedules a near-instant self-healing restart alarm to survive aggressive Chinese ROM task killers.
     */
    public static void scheduleAutoRestart(Context context) {
        if (context == null) return;
        try {
            Intent intent = new Intent(context, SmsReaderForegroundService.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            android.app.PendingIntent pendingIntent = android.app.PendingIntent.getService(context, 1002, intent, flags);
            android.app.AlarmManager am = (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                long triggerTime = android.os.SystemClock.elapsedRealtime() + 1500L; // 1.5 seconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerTime, pendingIntent);
                } else {
                    am.set(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerTime, pendingIntent);
                }
            }
        } catch (Exception e) {
            AppLogger.error("Failed to schedule auto restart: " + e.getMessage(), e);
        }
    }
}
