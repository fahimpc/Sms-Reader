package com.sms.reader.com;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * Helper to assist users in optimizing background reliability across various Android OEMs
 * (Samsung, Xiaomi/Redmi/POCO, Oppo/Realme, Vivo, Huawei).
 */
public final class BackgroundReliabilityHelper {

    private BackgroundReliabilityHelper() {}

    /**
     * Checks if the application is whitelisted from Android Doze battery optimizations.
     */
    public static boolean isBatteryOptimizationIgnored(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                return pm.isIgnoringBatteryOptimizations(context.getPackageName());
            }
        }
        return true;
    }

    /**
     * Requests user to exclude the app from battery optimizations.
     */
    public static void requestIgnoreBatteryOptimization(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(intent);
            } catch (Exception e) {
                try {
                    Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                    activity.startActivity(intent);
                } catch (Exception ex) {
                    openAppInfoSettings(activity);
                }
            }
        }
    }

    /**
     * Attempts to launch OEM-specific background autostart / battery settings.
     */
    public static boolean openOemAutoStartSettings(Context context) {
        String manufacturer = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase() : "";
        Intent[] intents = null;

        if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                    new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerSettings"))
            };
        } else if (manufacturer.contains("oppo") || manufacturer.contains("realme") || manufacturer.contains("oneplus")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                    new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")),
                    new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
                    new Intent().setComponent(new ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"))
            };
        } else if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
                    new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                    new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.MainGuideActivity"))
            };
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                    new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.bootstart.BootStartActivity"))
            };
        } else if (manufacturer.contains("infinix") || manufacturer.contains("tecno") || manufacturer.contains("itel") || manufacturer.contains("transsion")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.transsion.phonemanager", "com.transsion.phonemanager.settings.AutoStartManagementActivity")),
                    new Intent().setComponent(new ComponentName("com.transsion.phonemaster", "com.transsion.phonemaster.autostart.AutoStartActivity"))
            };
        } else if (manufacturer.contains("meizu")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.permission.startup.StartupAppListActivity"))
            };
        } else if (manufacturer.contains("samsung")) {
            intents = new Intent[]{
                    new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
                    new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity"))
            };
        }

        if (intents != null) {
            for (Intent intent : intents) {
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    return true;
                } catch (Exception ignored) {}
            }
        }

        // Fallback: Open application details settings
        return openAppInfoSettings(context);
    }

    public static boolean openAppInfoSettings(Context context) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getOemGuidance() {
        String manufacturer = Build.MANUFACTURER != null ? Build.MANUFACTURER.toUpperCase() : "Android";
        StringBuilder sb = new StringBuilder();
        sb.append("Recommended steps for ").append(manufacturer).append(" devices:\n\n");
        sb.append("1. Disable Battery Optimization: Set battery usage to 'Unrestricted' or 'No Restrictions'.\n");
        sb.append("2. AutoStart: Enable 'AutoStart' for SMS Reader in Security / App settings.\n");
        sb.append("3. Lock in Recents: Open Recent Apps, long-press or tap padlock icon on SMS Reader to prevent clearing.\n");
        sb.append("4. Ongoing Notification: Keep 'SMS Reader Active' notification enabled.\n\n");
        sb.append("Note: If the app is manually 'Force Stopped' via Android App Info, Android rules prevent background execution until reopened.");
        return sb.toString();
    }
}
