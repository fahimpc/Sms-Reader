package com.sms.reader.com;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * High-performance, concurrent SMS buffering and execution queue.
 *
 * Designed to handle extreme burst traffic (5 to 1000+ incoming SMS per second)
 * without freezing the UI or triggering Android ANR (Application Not Responding).
 *
 * Features:
 * 1. BroadcastReceiver.goAsync() decouples SMS reception from the Android Main Thread in <0.1ms.
 * 2. Multi-threaded worker pool (4-8 threads) concurrently processes and uploads payments.
 * 3. In-memory deduplication cache prevents duplicate tower rebroadcasts in O(1) time.
 * 4. Automatic WakeLock keeps the CPU awake until all queued SMS are fully uploaded.
 * 5. Throttled UI notifications prevent Choreographer dropped frames during massive bursts.
 * 6. Thread-safe metrics track processed, dropped, and queued counts.
 */
public final class SmsQueueProcessor {

    private static final String WAKE_LOCK_TAG = "gwm:SmsQueueWakeLock";
    private static final long WAKE_LOCK_TIMEOUT_MS = 180_000L; // 3 minutes safety timeout
    private static final long DEDUPE_CACHE_TTL_MS = 900_000L; // 15 minutes
    private static final long UI_THROTTLE_WINDOW_MS = 250L; // Max 4 UI broadcasts per second

    private static volatile SmsQueueProcessor instance;

    private final Context appContext;
    private final ThreadPoolExecutor executor;
    private final PowerManager.WakeLock wakeLock;
    private final AtomicInteger inFlightTasks = new AtomicInteger(0);
    private final ConcurrentHashMap<String, Long> dedupeCache = new ConcurrentHashMap<>();

    private final AtomicLong totalReceivedCount = new AtomicLong(0);
    private final AtomicLong totalProcessedCount = new AtomicLong(0);
    private final AtomicLong totalDroppedOutgoingCount = new AtomicLong(0);

    private final Object wakeLockSync = new Object();
    private volatile long lastUiBroadcastTime = 0L;
    private volatile long lastForegroundServicePingTime = 0L;

    public static SmsQueueProcessor getInstance(Context context) {
        if (instance == null) {
            synchronized (SmsQueueProcessor.class) {
                if (instance == null) {
                    instance = new SmsQueueProcessor(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private SmsQueueProcessor(Context context) {
        this.appContext = context;

        // Custom thread factory for clear thread naming in profilers/logs
        ThreadFactory threadFactory = new ThreadFactory() {
            private final AtomicInteger count = new AtomicInteger(1);
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "sms-queue-worker-" + count.getAndIncrement());
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY);
                return t;
            }
        };

        // Highly concurrent worker pool with bounded core and flexible max capacity
        int cores = Math.max(2, Runtime.getRuntime().availableProcessors());
        int corePool = Math.min(4, cores);
        int maxPool = Math.max(4, cores * 2);

        this.executor = new ThreadPoolExecutor(
                corePool,
                maxPool,
                60L,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(),
                threadFactory
        );
        this.executor.allowCoreThreadTimeOut(true);

        PowerManager pm = (PowerManager) appContext.getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            this.wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKE_LOCK_TAG);
            this.wakeLock.setReferenceCounted(false);
        } else {
            this.wakeLock = null;
        }
    }

    /**
     * Enqueues an incoming SMS Intent for asynchronous background processing.
     * Takes <0.1ms to return, freeing the BroadcastReceiver main thread immediately.
     */
    public void enqueue(Context context, Intent intent, BroadcastReceiver.PendingResult pendingResult) {
        totalReceivedCount.incrementAndGet();
        inFlightTasks.incrementAndGet();
        acquireWakeLock();

        // Keep foreground service alive without spamming service starts during bursts
        pingForegroundService();

        executor.execute(() -> {
            try {
                processSmsIntent(intent);
            } catch (Throwable t) {
                AppLogger.error("Error processing SMS task in queue: " + t.getMessage(), t);
            } finally {
                // Signal Android OS that the asynchronous broadcast handling is finished
                if (pendingResult != null) {
                    try {
                        pendingResult.finish();
                    } catch (Exception ignored) {}
                }
                onTaskFinished();
            }
        });
    }

    private void processSmsIntent(Intent intent) {
        if (intent == null) return;

        SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (messages == null || messages.length == 0) {
            return;
        }

        // Reconstruct multipart SMS into full body
        StringBuilder fullBodyBuilder = new StringBuilder();
        String originatingAddress = null;
        long timestamp = 0L;

        for (SmsMessage sms : messages) {
            if (sms != null) {
                if (originatingAddress == null) {
                    originatingAddress = sms.getDisplayOriginatingAddress();
                    if (originatingAddress == null) {
                        originatingAddress = sms.getOriginatingAddress();
                    }
                    timestamp = sms.getTimestampMillis();
                }
                String bodyPart = sms.getDisplayMessageBody();
                if (bodyPart == null) {
                    bodyPart = sms.getMessageBody();
                }
                if (bodyPart != null) {
                    fullBodyBuilder.append(bodyPart);
                }
            }
        }

        final String fullBody = fullBodyBuilder.toString();
        final String sender = originatingAddress != null ? originatingAddress : "Unknown";
        if (timestamp <= 0L) {
            timestamp = System.currentTimeMillis();
        }

        // STEP 1: Immediately drop any outgoing or debit SMS (Send Money, Cash Out, Recharge, Payment to shop)
        if (PaymentParser.isOutgoingOrDebit(fullBody)) {
            totalDroppedOutgoingCount.incrementAndGet();
            AppLogger.log("OUTGOING_SMS_DROPPED: Outgoing transaction (Send Money/Cash Out) from " + sender + " ignored. App only processes incoming money received.");
            return;
        }

        // STEP 2: Detect provider (bKash, Nagad, Rocket)
        final Provider provider = ProviderDetector.detect(sender, fullBody);
        if (provider == Provider.UNKNOWN) {
            // Unrelated non-payment or telecom SMS
            return;
        }

        // STEP 3: Strict parsing - only accepts verified incoming money received
        final PaymentData paymentData = PaymentParser.parse(sender, fullBody, timestamp);
        if (paymentData == null) {
            AppLogger.log("NON_PAYMENT_IGNORED: Non-payment/unrecognized format from " + provider.getDisplayName() + " ignored. Preserving existing app state.");
            return;
        }

        // STEP 3.5: AI Fraud & Fake SMS Evaluation
        AiFraudResult aiResult = paymentData.getAiResult();
        if (aiResult != null && !aiResult.isGenuine()) {
            AppLogger.error("⚠️ AI_FAKE_SMS_BLOCKED: " + aiResult.getStatusBadge() + " - " + aiResult.getReason() + " (TrxID: " + paymentData.getTxid() + ")", null);
            TtsHelper.getInstance(appContext).speakText("সতর্কতা! এটি একটি ভুয়া বা সন্দেহজনক পেমেন্ট মেসেজ!");
            NotificationHelper.getInstance(appContext).updateNotification(
                    "⚠️ Fake Payment SMS Blocked",
                    provider.getDisplayName() + " • " + aiResult.getReason()
            );
            return;
        }

        // STEP 4: In-memory O(1) deduplication check
        String dedupeKey = provider.name() + "_" + paymentData.getTxid();
        long now = SystemClock.elapsedRealtime();
        Long prev = dedupeCache.put(dedupeKey, now);
        if (prev != null && (now - prev) < DEDUPE_CACHE_TTL_MS) {
            AppLogger.log("DUPLICATE_IN_MEMORY: TrxID " + paymentData.getTxid() + " already processed in current burst. Skipping redundant upload.");
            return;
        }
        cleanDedupeCacheIfNeeded(now);

        // STEP 5: Save latest valid incoming payment to local store and durable Sync Center queue
        SmsStore smsStore = new SmsStore(appContext);
        smsStore.saveLatestSms(provider, fullBody, sender, timestamp, true, paymentData);
        totalProcessedCount.incrementAndGet();

        // Enqueue to Payment SMS Sync Center V1.0 (durable SQLite database & recovery queue)
        SmsSyncManager.getInstance(appContext).enqueuePaymentSms(paymentData);

        AppLogger.log("INCOMING PAYMENT RECEIVED from " + sender);
        AppLogger.log("Provider: " + provider.getDisplayName() + " Tk " + paymentData.getAmount() + " TrxID: " + paymentData.getTxid());

        // Broadcast to UI IMMEDIATELY for instant real-time display without needing app minimize/reopen
        try {
            Intent updateIntent = new Intent(AppConfig.ACTION_SMS_PROCESSED);
            updateIntent.putExtra(AppConfig.EXTRA_PROVIDER, provider.name());
            updateIntent.putExtra(AppConfig.EXTRA_TXID, paymentData.getTxid());
            updateIntent.setPackage(appContext.getPackageName());
            appContext.sendBroadcast(updateIntent);
        } catch (Exception ignored) {}

        // Speak Voice Alert announcement
        TtsHelper.getInstance(appContext).speakPayment(paymentData);

        // STEP 6: Check Admin settings for active backend (Firebase or PHP MySQL)
        boolean isPhpMode = BackendManager.getInstance(appContext).isPhpMode();
        boolean isEnabled = isPhpMode ?
                PhpConfigManager.getInstance(appContext).getProviderSetting(provider).isEnabled() :
                SettingsRepository.getInstance(appContext).isProviderEnabled(provider);

        if (!isEnabled) {
            AppLogger.log("PROVIDER_DISABLED: Auto-upload skipped for " + provider.getDisplayName());
            NotificationHelper.getInstance(appContext).updateNotification(
                    "Payment SMS detected",
                    provider.getDisplayName() + " • Provider disabled by Admin"
            );
            notifyUiThrottled(provider, paymentData.getTxid(), "PROVIDER_DISABLED");
            return;
        }

        // STEP 7: Upload atomically to active backend (Firebase or PHP MySQL)
        final String backendName = BackendManager.getInstance(appContext).getActiveMode().getDisplayName();
        BackendManager.getInstance(appContext).uploadTransaction(appContext, paymentData, new FirebaseWriter.UploadCallback() {
            @Override
            public void onSuccess(String txid) {
                NotificationHelper.getInstance(appContext).onPaymentEvent(
                        provider.getDisplayName(),
                        paymentData.getAmount(),
                        txid,
                        backendName + " saved"
                );
                notifyUiThrottled(provider, txid, "SAVED");
            }

            @Override
            public void onAlreadyExists(String txid) {
                NotificationHelper.getInstance(appContext).onPaymentEvent(
                        provider.getDisplayName(),
                        paymentData.getAmount(),
                        txid,
                        "Already saved"
                );
                notifyUiThrottled(provider, txid, "ALREADY_SAVED");
            }

            @Override
            public void onError(String errorCode, String message) {
                NotificationHelper.getInstance(appContext).updateNotification(
                        "Payment SMS error",
                        provider.getDisplayName() + " • " + errorCode
                );
                notifyUiThrottled(provider, paymentData.getTxid(), errorCode);
            }
        });
    }

    /**
     * Instantly processes payment transactions intercepted from the Notification Bar in <1ms.
     */
    public void enqueueNotificationPayment(final PaymentData paymentData) {
        if (paymentData == null) return;

        // STEP 1: In-memory O(1) deduplication check
        String dedupeKey = paymentData.getProvider().name() + "_" + paymentData.getTxid();
        long now = SystemClock.elapsedRealtime();
        Long prev = dedupeCache.put(dedupeKey, now);
        if (prev != null && (now - prev) < DEDUPE_CACHE_TTL_MS) {
            return;
        }
        cleanDedupeCacheIfNeeded(now);

        // STEP 2: Save to local store & enqueue to Sync Center
        SmsStore smsStore = new SmsStore(appContext);
        smsStore.saveLatestSms(paymentData.getProvider(), paymentData.getRawSms(), paymentData.getSender(), paymentData.getTimestamp(), true, paymentData);
        totalProcessedCount.incrementAndGet();

        SmsSyncManager.getInstance(appContext).enqueuePaymentSms(paymentData);

        // Speak Voice Alert
        TtsHelper.getInstance(appContext).speakPayment(paymentData);

        // Broadcast to UI
        try {
            Intent updateIntent = new Intent(AppConfig.ACTION_SMS_PROCESSED);
            updateIntent.putExtra(AppConfig.EXTRA_PROVIDER, paymentData.getProvider().name());
            updateIntent.putExtra(AppConfig.EXTRA_TXID, paymentData.getTxid());
            updateIntent.setPackage(appContext.getPackageName());
            appContext.sendBroadcast(updateIntent);
        } catch (Exception ignored) {}

        // Upload to active backend (Firebase or PHP MySQL)
        BackendManager.getInstance(appContext).uploadTransaction(appContext, paymentData, new FirebaseWriter.UploadCallback() {
            @Override
            public void onSuccess(String txid) {
                notifyUiThrottled(paymentData.getProvider(), txid, "SAVED");
            }
            @Override
            public void onAlreadyExists(String txid) {
                notifyUiThrottled(paymentData.getProvider(), txid, "ALREADY_SAVED");
            }
            @Override
            public void onError(String errorCode, String message) {
                notifyUiThrottled(paymentData.getProvider(), paymentData.getTxid(), errorCode);
            }
        });
    }

    /**
     * Throttles UI broadcast events during high burst traffic to keep the UI running at 60 fps.
     */
    private void notifyUiThrottled(Provider provider, String txid, String status) {
        long now = SystemClock.elapsedRealtime();
        boolean shouldBroadcast = false;

        synchronized (this) {
            if (now - lastUiBroadcastTime >= UI_THROTTLE_WINDOW_MS || inFlightTasks.get() <= 1) {
                lastUiBroadcastTime = now;
                shouldBroadcast = true;
            }
        }

        if (shouldBroadcast) {
            try {
                Intent updateIntent = new Intent(AppConfig.ACTION_SMS_PROCESSED);
                updateIntent.putExtra(AppConfig.EXTRA_PROVIDER, provider.name());
                if (txid != null) {
                    updateIntent.putExtra(AppConfig.EXTRA_TXID, txid);
                }
                if (status != null) {
                    updateIntent.putExtra(AppConfig.EXTRA_STATUS, status);
                }
                updateIntent.setPackage(appContext.getPackageName());
                appContext.sendBroadcast(updateIntent);
            } catch (Exception ignored) {}
        }
    }

    private void pingForegroundService() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastForegroundServicePingTime > 30_000L) { // At most once every 30 seconds
            lastForegroundServicePingTime = now;
            SmsReaderForegroundService.startService(appContext);
        }
    }

    private void acquireWakeLock() {
        if (wakeLock == null) return;
        synchronized (wakeLockSync) {
            try {
                if (!wakeLock.isHeld()) {
                    wakeLock.acquire(WAKE_LOCK_TIMEOUT_MS);
                }
            } catch (Exception ignored) {}
        }
    }

    private void onTaskFinished() {
        int remaining = inFlightTasks.decrementAndGet();
        if (remaining <= 0) {
            releaseWakeLock();
        }
    }

    private void releaseWakeLock() {
        if (wakeLock == null) return;
        synchronized (wakeLockSync) {
            try {
                if (wakeLock.isHeld()) {
                    wakeLock.release();
                }
            } catch (Exception ignored) {}
        }
    }

    private void cleanDedupeCacheIfNeeded(long now) {
        if (dedupeCache.size() > 500) {
            Iterator<Map.Entry<String, Long>> it = dedupeCache.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Long> entry = it.next();
                if (now - entry.getValue() > DEDUPE_CACHE_TTL_MS) {
                    it.remove();
                }
            }
        }
    }

    public int getInFlightCount() {
        return Math.max(0, inFlightTasks.get());
    }

    public long getTotalReceivedCount() {
        return totalReceivedCount.get();
    }

    public long getTotalProcessedCount() {
        return totalProcessedCount.get();
    }

    public long getTotalDroppedOutgoingCount() {
        return totalDroppedOutgoingCount.get();
    }
}
