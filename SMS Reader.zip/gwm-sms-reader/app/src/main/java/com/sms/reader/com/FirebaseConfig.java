package com.sms.reader.com;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Model representing a Firebase project configuration.
 * Can be parsed from google-services.json or entered manually.
 */
public class FirebaseConfig {

    private String projectId;
    private String applicationId;
    private String apiKey;
    private String databaseUrl;
    private String storageBucket;
    private String gcmSenderId;
    private String configName;
    private long createdAt;
    private boolean isDefault;

    public FirebaseConfig() {
        this.createdAt = System.currentTimeMillis();
    }

    public FirebaseConfig(String projectId, String applicationId, String apiKey, String databaseUrl,
                          String storageBucket, String gcmSenderId, String configName, boolean isDefault) {
        this.projectId = projectId != null ? projectId.trim() : "";
        this.applicationId = applicationId != null ? applicationId.trim() : "";
        this.apiKey = apiKey != null ? apiKey.trim() : "";
        this.databaseUrl = databaseUrl != null ? databaseUrl.trim() : "";
        this.storageBucket = storageBucket != null ? storageBucket.trim() : "";
        this.gcmSenderId = gcmSenderId != null ? gcmSenderId.trim() : "";
        this.configName = configName != null ? configName.trim() : "Custom Config";
        this.isDefault = isDefault;
        this.createdAt = System.currentTimeMillis();
    }

    public String getProjectId() {
        return projectId != null ? projectId : "";
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId != null ? projectId.trim() : "";
    }

    public String getApplicationId() {
        return applicationId != null ? applicationId : "";
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId != null ? applicationId.trim() : "";
    }

    public String getApiKey() {
        return apiKey != null ? apiKey : "";
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey != null ? apiKey.trim() : "";
    }

    public String getDatabaseUrl() {
        return databaseUrl != null ? databaseUrl : "";
    }

    public void setDatabaseUrl(String databaseUrl) {
        this.databaseUrl = databaseUrl != null ? databaseUrl.trim() : "";
    }

    public String getStorageBucket() {
        return storageBucket != null ? storageBucket : "";
    }

    public void setStorageBucket(String storageBucket) {
        this.storageBucket = storageBucket != null ? storageBucket.trim() : "";
    }

    public String getGcmSenderId() {
        return gcmSenderId != null ? gcmSenderId : "";
    }

    public void setGcmSenderId(String gcmSenderId) {
        this.gcmSenderId = gcmSenderId != null ? gcmSenderId.trim() : "";
    }

    public String getConfigName() {
        return configName != null ? configName : "Custom Config";
    }

    public void setConfigName(String configName) {
        this.configName = configName != null ? configName.trim() : "Custom Config";
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean aDefault) {
        isDefault = aDefault;
    }

    /**
     * Validates that all required fields are present and structurally valid.
     */
    public boolean isValid() {
        if (projectId == null || projectId.trim().isEmpty()) return false;
        if (apiKey == null || apiKey.trim().isEmpty()) return false;
        if (applicationId == null || applicationId.trim().isEmpty()) return false;
        if (databaseUrl == null || databaseUrl.trim().isEmpty()) return false;
        return databaseUrl.startsWith("https://") || databaseUrl.startsWith("http://");
    }

    public String getValidationError() {
        if (projectId == null || projectId.trim().isEmpty()) {
            return "Project ID is required";
        }
        if (apiKey == null || apiKey.trim().isEmpty()) {
            return "API Key is required";
        }
        if (applicationId == null || applicationId.trim().isEmpty()) {
            return "Application ID (Mobile SDK App ID) is required";
        }
        if (databaseUrl == null || databaseUrl.trim().isEmpty()) {
            return "Firebase Realtime Database URL is required";
        }
        if (!databaseUrl.startsWith("https://") && !databaseUrl.startsWith("http://")) {
            return "Database URL must start with https://";
        }
        return null;
    }

    @NonNull
    public String toJson() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("projectId", projectId);
            obj.put("applicationId", applicationId);
            obj.put("apiKey", apiKey);
            obj.put("databaseUrl", databaseUrl);
            obj.put("storageBucket", storageBucket);
            obj.put("gcmSenderId", gcmSenderId);
            obj.put("configName", configName);
            obj.put("createdAt", createdAt);
            obj.put("isDefault", isDefault);
            return obj.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    @Nullable
    public static FirebaseConfig fromJson(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) return null;
        try {
            JSONObject obj = new JSONObject(jsonString);
            FirebaseConfig config = new FirebaseConfig();
            config.projectId = obj.optString("projectId", "");
            config.applicationId = obj.optString("applicationId", "");
            config.apiKey = obj.optString("apiKey", "");
            config.databaseUrl = obj.optString("databaseUrl", "");
            config.storageBucket = obj.optString("storageBucket", "");
            config.gcmSenderId = obj.optString("gcmSenderId", "");
            config.configName = obj.optString("configName", "Custom Config");
            config.createdAt = obj.optLong("createdAt", System.currentTimeMillis());
            config.isDefault = obj.optBoolean("isDefault", false);
            return config;
        } catch (JSONException e) {
            return null;
        }
    }
}
