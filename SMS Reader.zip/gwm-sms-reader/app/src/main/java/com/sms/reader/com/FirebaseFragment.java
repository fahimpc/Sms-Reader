package com.sms.reader.com;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.sms.reader.com.databinding.FragmentFirebaseBinding;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class FirebaseFragment extends Fragment {

    private FragmentFirebaseBinding binding;
    private ActivityResultLauncher<String> jsonFilePickerLauncher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        jsonFilePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        importJsonFromUri(uri);
                    }
                }
        );
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentFirebaseBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupListeners();
        updateUi();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void updateUi() {
        if (binding == null || !isAdded()) return;
        Context ctx = getContext();
        if (ctx == null) return;

        boolean isPhpMode = BackendManager.getInstance(ctx).isPhpMode();
        FirebaseConfig active = FirebaseConfigManager.getInstance(ctx).getActiveConfig();
        boolean isConfigured = !isPhpMode && active != null && active.isValid() && !"DEFAULT_DELETED".equals(active.getProjectId());

        if (isConfigured) {
            binding.tvFirebaseStatusBadgePage.setText("✔ Connected");
            binding.tvFirebaseStatusBadgePage.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));

            binding.tvFbConnValue.setText("✔ Connected");
            binding.tvFbConnValue.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));

            binding.tvFbProjectIdValue.setText(active.getProjectId());
            binding.tvFbDbUrlValue.setText(active.getDatabaseUrl());
            binding.tvFbLastSyncValue.setText(new SimpleDateFormat("'Today,' hh:mm:ss a", Locale.US).format(new Date()));
        } else {
            binding.tvFirebaseStatusBadgePage.setText("● Disconnected");
            binding.tvFirebaseStatusBadgePage.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));

            binding.tvFbConnValue.setText("● Disconnected");
            binding.tvFbConnValue.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));

            binding.tvFbProjectIdValue.setText(isPhpMode ? "Disabled (PHP Mode Active)" : "No Project Connected");
            binding.tvFbDbUrlValue.setText(isPhpMode ? "Switch mode in Settings" : "Import google-services.json below");
            binding.tvFbLastSyncValue.setText("Not Configured");
        }
    }

    private void setupListeners() {
        if (binding == null) return;

        binding.btnImportJsonFile.setOnClickListener(v -> {
            try {
                jsonFilePickerLauncher.launch("*/*");
            } catch (Exception e) {
                Toast.makeText(getContext(), "Could not open file picker: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        binding.etRawJson.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                String content = s.toString().trim();
                if (content.startsWith("{") && content.endsWith("}")) {
                    try {
                        FirebaseConfig parsed = FirebaseConfigManager.getInstance(requireContext()).parseGoogleServicesJson(content);
                        binding.etProjectId.setText(parsed.getProjectId());
                        binding.etDatabaseUrl.setText(parsed.getDatabaseUrl());
                        binding.etApiKey.setText(parsed.getApiKey());
                        binding.etAppId.setText(parsed.getApplicationId());

                        binding.layoutTestStatus.setVisibility(View.VISIBLE);
                        binding.tvConfigStatus.setText("✓ JSON parsed successfully! Click Add New Firebase Project below.");
                        binding.tvConfigStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.status_green));
                    } catch (Exception ignored) {}
                }
            }
        });

        binding.btnTestAndSwitch.setOnClickListener(v -> {
            String pId = binding.etProjectId.getText().toString().trim();
            String dbUrl = binding.etDatabaseUrl.getText().toString().trim();
            String apiKey = binding.etApiKey.getText().toString().trim();
            String appId = binding.etAppId.getText().toString().trim();

            if (pId.isEmpty() || dbUrl.isEmpty() || apiKey.isEmpty() || appId.isEmpty()) {
                binding.layoutTestStatus.setVisibility(View.VISIBLE);
                binding.tvConfigStatus.setText("Please fill all required fields or import google-services.json");
                binding.tvConfigStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.status_red));
                return;
            }

            FirebaseConfig candidate = new FirebaseConfig(
                    pId, appId, apiKey, dbUrl,
                    pId + ".firebasestorage.app", "",
                    "Custom (" + pId + ")", false
            );

            triggerSwitchCandidate(candidate);
        });

        binding.btnRetryFirebasePage.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).onRetryAddClicked();
            }
        });

        // Remove Firebase Project Action Button
        binding.btnTestFirebasePage.setOnClickListener(v -> {
            Context ctx = requireContext();
            new AlertDialog.Builder(ctx)
                    .setTitle("🗑️ Remove Firebase Project?")
                    .setMessage("Are you sure you want to remove the current Firebase project? This will disconnect Firebase and clear saved credentials.")
                    .setPositiveButton("YES, REMOVE", (dialog, which) -> {
                        FirebaseConfigManager.getInstance(ctx).clearActiveConfig();
                        updateUi();
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).notifyHomeDashboardUpdated();
                        }
                        Toast.makeText(ctx, "Firebase Project Removed", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("CANCEL", null)
                    .show();
        });
    }

    private void triggerSwitchCandidate(final FirebaseConfig candidate) {
        if (binding == null) return;
        Context ctx = requireContext();

        binding.layoutTestStatus.setVisibility(View.VISIBLE);
        binding.progressBarConfig.setVisibility(View.VISIBLE);
        binding.tvConfigStatus.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        binding.tvConfigStatus.setText("Testing connection to " + candidate.getProjectId() + "...");
        binding.btnTestAndSwitch.setEnabled(false);

        FirebaseConfigManager.getInstance(ctx).testAndSwitchConfig(candidate, false, new FirebaseConfigManager.SwitchCallback() {
            @Override
            public void onProgress(String status) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (binding != null) binding.tvConfigStatus.setText(status);
                    });
                }
            }

            @Override
            public void onSuccess(FirebaseConfig newConfig) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (binding != null) {
                            binding.progressBarConfig.setVisibility(View.GONE);
                            binding.btnTestAndSwitch.setEnabled(true);
                            binding.tvConfigStatus.setText("✓ Successfully connected to " + newConfig.getProjectId() + "!\nAll future SMS will sync to this database.");
                            binding.tvConfigStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));
                        }

                        BackendManager.getInstance(ctx).setBackendMode(BackendManager.BackendMode.FIREBASE);
                        updateUi();

                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).updateActiveProjectUi();
                        }

                        Toast.makeText(ctx, "Firebase Connected: " + newConfig.getProjectId(), Toast.LENGTH_SHORT).show();
                    });
                }
            }

            @Override
            public void onError(String errorMessage) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (binding != null) {
                            binding.progressBarConfig.setVisibility(View.GONE);
                            binding.btnTestAndSwitch.setEnabled(true);
                            binding.tvConfigStatus.setText("❌ " + errorMessage + "\nConnection failed.");
                            binding.tvConfigStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_red));
                        }
                    });
                }
            }
        });
    }

    private void importJsonFromUri(Uri uri) {
        if (binding == null || getContext() == null) return;
        try (InputStream inputStream = requireContext().getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            String content = sb.toString();
            FirebaseConfig parsed = FirebaseConfigManager.getInstance(requireContext()).parseGoogleServicesJson(content);

            binding.etRawJson.setText(content);
            binding.etProjectId.setText(parsed.getProjectId());
            binding.etDatabaseUrl.setText(parsed.getDatabaseUrl());
            binding.etApiKey.setText(parsed.getApiKey());
            binding.etAppId.setText(parsed.getApplicationId());

            binding.layoutTestStatus.setVisibility(View.VISIBLE);
            binding.tvConfigStatus.setText("✓ File loaded: " + parsed.getProjectId() + "\nAuto-filled! Click Add New Firebase Project below.");
            binding.tvConfigStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.status_green));

            Toast.makeText(requireContext(), "Loaded " + parsed.getProjectId(), Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            AppLogger.error("Failed to parse imported json file: " + e.getMessage(), e);
            binding.layoutTestStatus.setVisibility(View.VISIBLE);
            binding.tvConfigStatus.setText("Failed to parse json file: " + e.getMessage());
            binding.tvConfigStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.status_red));
            Toast.makeText(requireContext(), "Failed to parse json file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
