package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Manages runtime Firebase configuration switching with transactional safety.
 * Validates new configurations using an isolated probe FirebaseApp before
 * switching the active app instance. Maintains a rollback configuration.
 */
public final class FirebaseConfigManager {

    public interface SwitchCallback {
        void onProgress(String status);
        void onSuccess(FirebaseConfig newConfig);
        void onError(String errorMessage);
    }

    private static final String PREF_NAME = "gwm_firebase_config_mgr";
    private static final String KEY_ACTIVE_CONFIG = "active_firebase_config";
    private static final String KEY_ROLLBACK_CONFIG = "rollback_firebase_config";
    public static final String KEY_DEFAULT_PURGED = "is_default_firebase_purged";

    private static FirebaseConfigManager instance;

    private final Context appContext;
    private final SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static synchronized FirebaseConfigManager getInstance(Context context) {
        if (instance == null) {
            instance = new FirebaseConfigManager(context.getApplicationContext());
        }
        return instance;
    }

    private FirebaseConfigManager(Context context) {
        this.appContext = context;
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Checks if the default packaged Firebase project (topupbd-9f02e) has been purged/deleted.
     */
    public boolean isDefaultPurged() {
        return prefs.getBoolean(KEY_DEFAULT_PURGED, false);
    }

    /**
     * Permanently deletes and purges the default packaged Firebase project (topupbd-9f02e).
     * Once purged, this app will never connect to or send data to the old user's project/website.
     */
    public void purgeDefaultConfigPermanently() {
        prefs.edit().putBoolean(KEY_DEFAULT_PURGED, true).apply();
        String rollbackJson = prefs.getString(KEY_ROLLBACK_CONFIG, null);
        if (rollbackJson != null && rollbackJson.contains("topupbd-9f02e")) {
            prefs.edit().remove(KEY_ROLLBACK_CONFIG).apply();
        }
        String activeJson = prefs.getString(KEY_ACTIVE_CONFIG, null);
        if (activeJson == null || activeJson.contains("topupbd-9f02e")) {
            prefs.edit().remove(KEY_ACTIVE_CONFIG).apply();
        }
        AppLogger.log("Default Firebase project (topupbd-9f02e) has been PERMANENTLY PURGED. The app will never connect to it.");
    }

    public void clearActiveConfig() {
        prefs.edit().remove(KEY_ACTIVE_CONFIG).remove(KEY_ROLLBACK_CONFIG).apply();
        AppLogger.log("Firebase Active Config cleared.");
    }

    /**
     * Placeholder configuration returned when the default config has been deleted
     * and no custom project has been imported yet.
     */
    @NonNull
    public FirebaseConfig getPurgedPlaceholderConfig() {
        return new FirebaseConfig(
                "DEFAULT_DELETED",
                "",
                "",
                "",
                "",
                "",
                "Default Project Deleted (No Active Project)",
                false
        );
    }

    /**
     * Default packaged configuration.
     * Returns null by default so fresh public installations start cleanly disconnected
     * until the user imports their own google-services.json or connects to PHP API.
     */
    @Nullable
    public FirebaseConfig getDefaultPackagedConfig() {
        return null;
    }

    /**
     * Retrieves the currently active configuration.
     */
    @NonNull
    public FirebaseConfig getActiveConfig() {
        String json = prefs.getString(KEY_ACTIVE_CONFIG, null);
        if (json != null) {
            FirebaseConfig config = FirebaseConfig.fromJson(json);
            if (config != null && config.isValid()) {
                if ("remixed-api-key".equals(config.getApiKey()) || "remixed-project-id".equals(config.getProjectId())) {
                    prefs.edit().remove(KEY_ACTIVE_CONFIG).apply();
                    FirebaseConfig def = getDefaultPackagedConfig();
                    return def != null ? def : getPurgedPlaceholderConfig();
                }
                return config;
            }
        }
        FirebaseConfig def = getDefaultPackagedConfig();
        return def != null ? def : getPurgedPlaceholderConfig();
    }

    /**
     * Retrieves the previous working rollback configuration if available.
     */
    @Nullable
    public FirebaseConfig getRollbackConfig() {
        String json = prefs.getString(KEY_ROLLBACK_CONFIG, null);
        if (json != null) {
            FirebaseConfig config = FirebaseConfig.fromJson(json);
            if (config != null && config.isValid()) {
                if ("remixed-api-key".equals(config.getApiKey()) || "remixed-project-id".equals(config.getProjectId())) {
                    prefs.edit().remove(KEY_ROLLBACK_CONFIG).apply();
                    return null;
                }
                return config;
            }
        }
        return null;
    }

    public boolean hasRollbackConfig() {
        return getRollbackConfig() != null;
    }

    /**
     * Parses a raw google-services.json file into a FirebaseConfig object.
     */
    @NonNull
    public FirebaseConfig parseGoogleServicesJson(@NonNull String jsonContent) throws Exception {
        if (jsonContent.contains("private_key") || jsonContent.contains("private_key_id")) {
            throw new IllegalArgumentException("SECURITY ERROR: Service-Account JSON containing private_key cannot be imported. Please import a standard client google-services.json file.");
        }

        JSONObject root = new JSONObject(jsonContent);
        if ("service_account".equalsIgnoreCase(root.optString("type"))) {
            throw new IllegalArgumentException("SECURITY ERROR: Service-Account JSON cannot be imported into Android app. Please import a client google-services.json file.");
        }

        JSONObject projectInfo = root.optJSONObject("project_info");
        if (projectInfo == null) {
            throw new IllegalArgumentException("Invalid google-services.json: 'project_info' object missing.");
        }

        String projectId = projectInfo.optString("project_id", "").trim();
        String databaseUrl = projectInfo.optString("firebase_url", "").trim();
        String projectNumber = projectInfo.optString("project_number", "").trim();
        String storageBucket = projectInfo.optString("storage_bucket", "").trim();

        if (databaseUrl.isEmpty() && !projectId.isEmpty()) {
            databaseUrl = "https://" + projectId + "-default-rtdb.firebaseio.com";
        }

        JSONArray clientArray = root.optJSONArray("client");
        if (clientArray == null || clientArray.length() == 0) {
            throw new IllegalArgumentException("Invalid google-services.json: 'client' array missing or empty.");
        }

        JSONObject client = clientArray.getJSONObject(0);
        JSONObject clientInfo = client.optJSONObject("client_info");
        String appId = clientInfo != null ? clientInfo.optString("mobilesdk_app_id", "").trim() : "";

        String apiKey = "";
        JSONArray apiKeyArray = client.optJSONArray("api_key");
        if (apiKeyArray != null && apiKeyArray.length() > 0) {
            JSONObject keyObj = apiKeyArray.getJSONObject(0);
            apiKey = keyObj.optString("current_key", "").trim();
        }

        FirebaseConfig config = new FirebaseConfig(
                projectId,
                appId,
                apiKey,
                databaseUrl,
                storageBucket,
                projectNumber,
                "Imported (" + projectId + ")",
                false
        );

        String error = config.getValidationError();
        if (error != null) {
            throw new IllegalArgumentException(error);
        }

        return config;
    }

    /**
     * Transactionally tests and switches the Firebase project.
     * If validation or testing fails, the current working configuration is completely untouched.
     */
    public void testAndSwitchConfig(@NonNull final FirebaseConfig newConfig, @NonNull final SwitchCallback callback) {
        testAndSwitchConfig(newConfig, false, callback);
    }

    /**
     * Transactionally tests and switches the Firebase project with option to permanently delete
     * and purge the old default project (topupbd-9f02e).
     */
    public void testAndSwitchConfig(@NonNull final FirebaseConfig newConfig, final boolean purgeOldDefault, @NonNull final SwitchCallback callback) {
        String validationError = newConfig.getValidationError();
        if (validationError != null) {
            callback.onError("Validation Error: " + validationError);
            return;
        }

        callback.onProgress("Initializing isolated test probe for " + newConfig.getProjectId() + "...");

        executor.execute(() -> {
            String probeAppName = "probe_" + System.currentTimeMillis();
            FirebaseApp probeApp = null;
            try {
                FirebaseOptions.Builder optionsBuilder = new FirebaseOptions.Builder()
                        .setProjectId(newConfig.getProjectId())
                        .setApplicationId(newConfig.getApplicationId())
                        .setApiKey(newConfig.getApiKey())
                        .setDatabaseUrl(newConfig.getDatabaseUrl());

                if (!newConfig.getStorageBucket().isEmpty()) {
                    optionsBuilder.setStorageBucket(newConfig.getStorageBucket());
                }
                if (!newConfig.getGcmSenderId().isEmpty()) {
                    optionsBuilder.setGcmSenderId(newConfig.getGcmSenderId());
                }

                final FirebaseOptions options = optionsBuilder.build();
                probeApp = FirebaseApp.initializeApp(appContext, options, probeAppName);

                postProgress(callback, "Testing Database connection to " + newConfig.getDatabaseUrl() + "...");

                // Probe Database
                FirebaseDatabase probeDb = FirebaseDatabase.getInstance(probeApp, newConfig.getDatabaseUrl());
                probeDb.purgeOutstandingWrites();

                // Test probe listener with timeout
                final AtomicBoolean connectedResult = new AtomicBoolean(false);
                final Object lock = new Object();

                DatabaseReference connectedRef = probeDb.getReference(".info/connected");
                ValueEventListener testListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Boolean val = snapshot.getValue(Boolean.class);
                        if (Boolean.TRUE.equals(val)) {
                            connectedResult.set(true);
                            synchronized (lock) {
                                lock.notifyAll();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        synchronized (lock) {
                            lock.notifyAll();
                        }
                    }
                };

                connectedRef.addValueEventListener(testListener);

                synchronized (lock) {
                    try {
                        lock.wait(3500); // Wait up to 3.5s for probe connection
                    } catch (InterruptedException ignored) {}
                }

                connectedRef.removeEventListener(testListener);

                postProgress(callback, "Probing Firebase Authentication...");
                FirebaseAuth probeAuth = FirebaseAuth.getInstance(probeApp);
                final AtomicBoolean authCompleted = new AtomicBoolean(false);
                final StringBuilder authErrorHolder = new StringBuilder();

                probeAuth.signInAnonymously()
                        .addOnSuccessListener(authResult -> {
                            authCompleted.set(true);
                            synchronized (lock) {
                                lock.notifyAll();
                            }
                        })
                        .addOnFailureListener(e -> {
                            String msg = e.getMessage() != null ? e.getMessage() : "";
                            // If anonymous auth is disabled in console, we don't treat it as fatal failure
                            if (msg.contains("restricted to administrators")
                                    || (e instanceof FirebaseAuthException && "ERROR_ADMIN_RESTRICTED_OPERATION".equals(((FirebaseAuthException) e).getErrorCode()))) {
                                authCompleted.set(true);
                            } else {
                                authErrorHolder.append(msg);
                            }
                            synchronized (lock) {
                                lock.notifyAll();
                            }
                        });

                synchronized (lock) {
                    try {
                        lock.wait(2500);
                    } catch (InterruptedException ignored) {}
                }

                // Clean up probe app
                try {
                    probeApp.delete();
                } catch (Exception ignored) {}

                // Check results: If auth fatal failure happened and not restricted
                if (authErrorHolder.length() > 0 && !connectedResult.get()) {
                    final String err = authErrorHolder.toString();
                    postError(callback, "Firebase test failed: " + err);
                    return;
                }

                // If test reached here, configuration is valid and reachable!
                postProgress(callback, "Probe succeeded! Applying configuration...");

                // Save or purge
                if (purgeOldDefault) {
                    prefs.edit()
                            .putBoolean(KEY_DEFAULT_PURGED, true)
                            .remove(KEY_ROLLBACK_CONFIG)
                            .putString(KEY_ACTIVE_CONFIG, newConfig.toJson())
                            .apply();
                    AppLogger.log("Default Firebase project (topupbd-9f02e) permanently purged upon switching. Prevents any data from going to old website.");
                } else {
                    // Save current active config as rollback before switching
                    FirebaseConfig currentActive = getActiveConfig();
                    if (!currentActive.getProjectId().equals(newConfig.getProjectId())
                            || !currentActive.getDatabaseUrl().equals(newConfig.getDatabaseUrl())) {
                        prefs.edit().putString(KEY_ROLLBACK_CONFIG, currentActive.toJson()).apply();
                    }
                    // Persist new active config
                    prefs.edit().putString(KEY_ACTIVE_CONFIG, newConfig.toJson()).apply();
                }

                // Apply to live application
                mainHandler.post(() -> {
                    try {
                        BackendManager.getInstance(appContext).setBackendMode(BackendManager.BackendMode.FIREBASE);
                        FirebaseProvider.getInstance(appContext).applyNewConfig(newConfig, options);
                        AppLogger.log("Successfully switched Firebase project to: " + newConfig.getProjectId() + " (" + newConfig.getDatabaseUrl() + ")");
                        callback.onSuccess(newConfig);
                    } catch (Exception ex) {
                        AppLogger.error("Error applying new Firebase config: " + ex.getMessage(), ex);
                        callback.onError("Failed to apply new config: " + ex.getMessage());
                    }
                });

            } catch (Exception e) {
                if (probeApp != null) {
                    try {
                        probeApp.delete();
                    } catch (Exception ignored) {}
                }
                AppLogger.error("Failed to validate new Firebase configuration: " + e.getMessage(), e);
                postError(callback, "Validation probe failed: " + e.getMessage());
            }
        });
    }

    /**
     * Restores the previous working rollback configuration.
     */
    public void rollbackToPreviousConfig(@NonNull final SwitchCallback callback) {
        FirebaseConfig rollback = getRollbackConfig();
        if (rollback == null) {
            callback.onError("No rollback configuration available.");
            return;
        }
        testAndSwitchConfig(rollback, false, callback);
    }

    /**
     * Resets to the packaged default configuration.
     */
    public void resetToDefaultConfig(@NonNull final SwitchCallback callback) {
        if (isDefaultPurged()) {
            callback.onError("The default Firebase project (topupbd-9f02e) was permanently deleted and cannot be restored.");
            return;
        }
        FirebaseConfig def = getDefaultPackagedConfig();
        if (def == null) {
            callback.onError("Default configuration is not available.");
            return;
        }
        testAndSwitchConfig(def, false, callback);
    }

    private void postProgress(final SwitchCallback callback, final String status) {
        mainHandler.post(() -> callback.onProgress(status));
    }

    private void postError(final SwitchCallback callback, final String error) {
        mainHandler.post(() -> callback.onError(error));
    }
}
