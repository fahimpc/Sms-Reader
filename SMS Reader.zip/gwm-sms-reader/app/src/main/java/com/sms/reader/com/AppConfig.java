package com.sms.reader.com;

/**
 * Isolated configuration constants for GWM SMS Reader.
 * Change PIN, paths, or Firebase defaults here in one place.
 */
public final class AppConfig {

    private AppConfig() {
        // Private constructor to prevent instantiation
    }

    /**
     * Default PIN for unlocking the application.
     * Keep this in one place and do not scatter across multiple files.
     */
    public static final String DEFAULT_PIN = "1212";

    /**
     * Firebase Realtime Database URL.
     */
    public static final String FIREBASE_DATABASE_URL = "https://topupbd-9f02e-default-rtdb.firebaseio.com";

    /**
     * Root node for storing payment transactions.
     * Website expects: XNXANIKPAY/<TRX_ID>
     */
    public static final String PATH_TRANSACTIONS = "XNXANIKPAY";

    /**
     * Root node for Admin-controlled payment settings:
     * paymentSettings/bkash, paymentSettings/nagad, paymentSettings/rocket
     */
    public static final String PATH_SETTINGS = "paymentSettings";

    /**
     * Notification channel and ID for persistent reader service.
     */
    public static final String NOTIFICATION_CHANNEL_ID = "gwm_sms_reader_channel";
    public static final int NOTIFICATION_ID = 1001;

    /**
     * Broadcast Intent Actions for communicating between background receiver and UI.
     */
    public static final String ACTION_SMS_PROCESSED = "gwm.topup.ACTION_SMS_PROCESSED";
    public static final String ACTION_LOG_UPDATED = "gwm.topup.ACTION_LOG_UPDATED";
    public static final String ACTION_SETTINGS_CHANGED = "gwm.topup.ACTION_SETTINGS_CHANGED";
    public static final String ACTION_FIREBASE_STATE_CHANGED = "gwm.topup.ACTION_FIREBASE_STATE_CHANGED";

    public static final String EXTRA_PROVIDER = "extra_provider";
    public static final String EXTRA_TXID = "extra_txid";
    public static final String EXTRA_STATUS = "extra_status";
}
