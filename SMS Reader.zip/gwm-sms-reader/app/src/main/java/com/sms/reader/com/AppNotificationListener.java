package com.sms.reader.com;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * Ultra-fast Notification Bar Interceptor for GWM SMS Reader.
 * Intercepts incoming payment notifications (bKash, Nagad, Rocket, Upay, System Messaging)
 * at the Notification Bar layer in <1ms, extracting TrxID and posting to PHP/Firebase
 * even before the phone's SMS app finishes indexing the inbox!
 */
public final class AppNotificationListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;

        try {
            Notification notification = sbn.getNotification();
            if (notification == null || notification.extras == null) return;

            Bundle extras = notification.extras;
            CharSequence titleSeq = extras.getCharSequence(Notification.EXTRA_TITLE, "");
            CharSequence textSeq = extras.getCharSequence(Notification.EXTRA_TEXT, "");
            CharSequence bigTextSeq = extras.getCharSequence(Notification.EXTRA_BIG_TEXT, "");

            String title = titleSeq != null ? titleSeq.toString() : "";
            String text = textSeq != null ? textSeq.toString() : "";
            String bigText = bigTextSeq != null ? bigTextSeq.toString() : "";

            String fullText = (title + " " + text + " " + bigText).trim();
            if (fullText.isEmpty()) return;

            // Detect payment provider from notification title/text
            Provider provider = ProviderDetector.detect(title, fullText);
            if (provider == Provider.UNKNOWN) {
                return; // Unrelated notification
            }

            // Parse payment transaction details
            long timestamp = sbn.getPostTime() > 0 ? sbn.getPostTime() : System.currentTimeMillis();
            PaymentData data = PaymentParser.parse(title, fullText, timestamp);

            if (data != null) {
                AppLogger.log("⚡ [NOTIFICATION INTERCEPTED] " + provider.getDisplayName() + " | Tk " + data.getAmount() + " | TrxID: " + data.getTxid());
                // Enqueue and upload immediately via SmsQueueProcessor
                SmsQueueProcessor.getInstance(getApplicationContext()).enqueueNotificationPayment(data);
            }

        } catch (Exception e) {
            AppLogger.error("Notification Interceptor Exception: " + e.getMessage(), e);
        }
    }
}
