package com.sms.reader.com;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.sms.reader.com.databinding.FragmentSettingsBinding;

public final class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupListeners();
        updateUi();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void updateUi() {
        if (binding == null || !isAdded()) return;
        Context ctx = getContext();
        if (ctx == null) return;

        boolean isPhp = BackendManager.getInstance(ctx).isPhpMode();
        boolean isConnected = isPhp ?
                PhpConfigManager.getInstance(ctx).isConfigured() :
                (FirebaseConfigManager.getInstance(ctx).getActiveConfig() != null && FirebaseConfigManager.getInstance(ctx).getActiveConfig().isValid() && !"DEFAULT_DELETED".equals(FirebaseConfigManager.getInstance(ctx).getActiveConfig().getProjectId()));

        if (isConnected) {
            binding.tvSettingsActiveBackendBadge.setText(isPhp ? "🐬 PHP MySQL Connected" : "🔥 Firebase Connected");
            binding.tvSettingsActiveBackendBadge.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));
        } else {
            binding.tvSettingsActiveBackendBadge.setText("● DISCONNECTED");
            binding.tvSettingsActiveBackendBadge.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));
        }

        binding.tvSettingsReaderUidValue.setText(FirebaseProvider.getInstance(ctx).getCurrentUid());
        binding.btnSettingsSwitchBackend.setText(isPhp ? "⇄  Switch to Firebase Project" : "⇄  Switch to PHP MySQL Project");
    }

    private void setupListeners() {
        if (binding == null) return;

        // Copy Reader UID
        binding.btnSettingsCopyUid.setOnClickListener(v -> {
            Context ctx = getContext();
            if (ctx != null) {
                String uid = FirebaseProvider.getInstance(ctx).getCurrentUid();
                ClipboardManager clipboard = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Reader UID", uid);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(ctx, "Reader UID copied", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Reliability Guide
        binding.btnSettingsReliability.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).showBackgroundReliabilityDialog();
            }
        });

        // Project Connection & Switch navigates directly to the embedded Page
        binding.btnSettingsManageProject.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                boolean isPhp = BackendManager.getInstance(requireContext()).isPhpMode();
                if (isPhp) {
                    ((MainActivity) getActivity()).selectNavTab(2);
                } else {
                    ((MainActivity) getActivity()).selectNavTab(1);
                }
            }
        });

        // Switch Active Backend Mode
        binding.btnSettingsSwitchBackend.setOnClickListener(v -> {
            Context ctx = requireContext();
            boolean isPhp = BackendManager.getInstance(ctx).isPhpMode();
            if (isPhp) {
                BackendManager.getInstance(ctx).setBackendMode(BackendManager.BackendMode.FIREBASE);
                Toast.makeText(ctx, "Switched to Firebase Mode", Toast.LENGTH_SHORT).show();
            } else {
                BackendManager.getInstance(ctx).setBackendMode(BackendManager.BackendMode.PHP_MYSQL);
                Toast.makeText(ctx, "Switched to PHP MySQL Mode", Toast.LENGTH_SHORT).show();
            }
            updateUi();
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).updateActiveProjectUi();
            }
        });

        // Theme Swatches
        binding.btnThemePurple.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_PURPLE, "#7C3AED"));
        binding.btnThemeBlue.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_BLUE, "#2563EB"));
        binding.btnThemeGreen.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_GREEN, "#16A34A"));
        binding.btnThemeOrange.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_ORANGE, "#EA580C"));
        binding.btnThemeRed.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_RED, "#DC2626"));
        binding.btnThemePink.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_PINK, "#EC4899"));
        binding.btnThemeTeal.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_TEAL, "#0D9488"));
        binding.btnThemeIndigo.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_INDIGO, "#4F46E5"));
        binding.btnThemeCyan.setOnClickListener(v -> applyPresetTheme(ThemeManager.THEME_CYAN, "#06B6D4"));

        // Custom Hex Apply
        binding.btnApplyCustomTheme.setOnClickListener(v -> {
            String customHex = binding.etCustomThemeHex.getText().toString().trim();
            if (!customHex.isEmpty()) {
                Context ctx = requireContext();
                boolean valid = ThemeManager.getInstance(ctx).setCustomHexColor(customHex);
                if (valid) {
                    Toast.makeText(ctx, "Custom Theme Applied: " + customHex, Toast.LENGTH_SHORT).show();
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).applyCurrentThemeUi();
                    }
                } else {
                    Toast.makeText(ctx, "Invalid Hex Color! E.g. #7C3AED or #E2136E", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Developer Facebook Profile Link
        View.OnClickListener openFacebookListener = v -> {
            try {
                String fbUrl = "https://www.facebook.com/share/1BM4waZmSS/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(fbUrl));
                startActivity(intent);
                AppLogger.log("Opening developer Facebook profile: " + fbUrl);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Could not open Facebook link", Toast.LENGTH_SHORT).show();
            }
        };

        if (binding.layoutSettingsFooter != null) binding.layoutSettingsFooter.setOnClickListener(openFacebookListener);
        if (binding.tvSettingsFooterDeveloper != null) binding.tvSettingsFooterDeveloper.setOnClickListener(openFacebookListener);
    }

    private void applyPresetTheme(String name, String hex) {
        Context ctx = requireContext();
        ThemeManager.getInstance(ctx).setThemePreset(name, hex);
        Toast.makeText(ctx, name + " theme applied!", Toast.LENGTH_SHORT).show();
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).applyCurrentThemeUi();
        }
    }
}
