package com.sms.reader.com;

/**
 * Result object returned by the On-Device AI Fraud Detector.
 * Evaluates whether an incoming payment SMS is genuine or fake/spoofed.
 */
public final class AiFraudResult {

    private final boolean isGenuine;
    private final float confidenceScore; // 0.0 to 1.0
    private final String statusBadge;
    private final String reason;

    public AiFraudResult(boolean isGenuine, float confidenceScore, String statusBadge, String reason) {
        this.isGenuine = isGenuine;
        this.confidenceScore = confidenceScore;
        this.statusBadge = statusBadge != null ? statusBadge : (isGenuine ? "✔ Verified Payment" : "⚠️ Fake/Fraud SMS");
        this.reason = reason != null ? reason : (isGenuine ? "Verified Authentic Payment" : "Suspicious SMS Pattern");
    }

    public boolean isGenuine() {
        return isGenuine;
    }

    public float getConfidenceScore() {
        return confidenceScore;
    }

    public String getStatusBadge() {
        return statusBadge;
    }

    public String getReason() {
        return reason;
    }
}
