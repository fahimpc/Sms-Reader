package com.sms.reader.com;

import androidx.annotation.NonNull;

/**
 * Supported payment providers:
 * bKash (Type 'B')
 * Nagad (Type 'N')
 * Rocket (Type 'R')
 */
public enum Provider {
    BKASH("bKash", "B", "bkash"),
    NAGAD("Nagad", "N", "nagad"),
    ROCKET("Rocket", "R", "rocket"),
    UPAY("Upay", "U", "upay"),
    UNKNOWN("Unknown", "UNKNOWN", "unknown");

    private final String displayName;
    private final String typeCode;
    private final String settingsKey;

    Provider(String displayName, String typeCode, String settingsKey) {
        this.displayName = displayName;
        this.typeCode = typeCode;
        this.settingsKey = settingsKey;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public String getSettingsKey() {
        return settingsKey;
    }

    @NonNull
    public static Provider fromString(String name) {
        if (name == null) return UNKNOWN;
        String trimmed = name.trim();
        for (Provider p : values()) {
            if (p.name().equalsIgnoreCase(trimmed) ||
                p.displayName.equalsIgnoreCase(trimmed) ||
                p.typeCode.equalsIgnoreCase(trimmed) ||
                p.settingsKey.equalsIgnoreCase(trimmed)) {
                return p;
            }
        }
        return UNKNOWN;
    }
}
