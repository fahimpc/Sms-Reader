package com.sms.reader.com;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

/**
 * Dedicated helper class to push parsed SMS payment data (sender, amount, transaction ID,
 * provider) directly to the active Firebase Realtime Database at path: XNXANIKPAY/<TRX_ID>.
 *
 * Features:
 * 1. Safe atomic transaction write preventing overwriting of existing payment records.
 * 2. Automatic type detection: B (bKash), N (Nagad), R (Rocket).
 * 3. Preserves backend 'used' status (never resets used=false on existing nodes).
 * 4. Normalizes amount formats (strips thousands commas).
 * 5. Dynamic database resolution: always targets the currently selected active Firebase project.
 * 6. Full error reporting and diagnostic logging.
 */
public final class FirebaseDatabaseHelper {

    public interface PushCallback {
        void onSuccess(String txid);
        void onAlreadyExists(String txid);
        void onError(String errorCode, String errorMessage);
    }

    public interface ExistenceCallback {
        void onResult(boolean exists, @Nullable DataSnapshot snapshot);
        void onError(String errorMessage);
    }

    private static FirebaseDatabaseHelper instance;
    private final Context appContext;

    public static synchronized FirebaseDatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new FirebaseDatabaseHelper(context != null ? context.getApplicationContext() : null);
        }
        return instance;
    }

    private FirebaseDatabaseHelper(Context context) {
        this.appContext = context;
    }

    private FirebaseDatabase getActiveDatabase() {
        if (appContext != null) {
            boolean isPurged = FirebaseConfigManager.getInstance(appContext).isDefaultPurged();
            FirebaseDatabase db = FirebaseProvider.getInstance(appContext).getDatabase();
            if (db != null) {
                return db;
            }
            if (isPurged) {
                return null;
            }
        }
        return FirebaseDatabase.getInstance(AppConfig.FIREBASE_DATABASE_URL);
    }

    /**
     * Pushes parsed SMS details using individual fields:
     *
     * @param provider e.g. "bKash", "Nagad", "Rocket", or "B", "N", "R"
     * @param sender   the customer / agent phone number or account (e.g. "01737078264", "***583")
     * @param amount   the payment amount string (e.g. "510.00")
     * @param txid     the unique transaction ID (e.g. "DJ118THL8D", "7011827020")
     * @param callback callback to receive upload result
     */
    public void pushParsedSms(String provider, String sender, String amount, String txid, final PushCallback callback) {
        if (txid == null || txid.trim().isEmpty()) {
            if (callback != null) callback.onError("INVALID_TXID", "Transaction ID is missing");
            return;
        }

        final String cleanTxid = txid.trim();
        final String cleanAmount = amount != null ? amount.replace(",", "").trim() : "0.00";
        final String cleanSender = sender != null ? sender.trim() : "Unknown";

        // Determine provider enum and standard type code
        final Provider providerEnum = Provider.fromString(provider);
        final String typeCode = providerEnum != Provider.UNKNOWN ? providerEnum.getTypeCode() : resolveTypeCode(provider);
        if (typeCode == null || "UNKNOWN".equals(typeCode)) {
            AppLogger.error("FirebaseDatabaseHelper: Rejected unknown provider: " + provider, null);
            if (callback != null) callback.onError("INVALID_PROVIDER", "Cannot upload unknown or invalid provider record");
            return;
        }
        final String providerName = providerEnum != Provider.UNKNOWN ? providerEnum.getDisplayName() :
                ("U".equals(typeCode) ? Provider.UPAY.getDisplayName() :
                 ("B".equals(typeCode) ? Provider.BKASH.getDisplayName() :
                  ("N".equals(typeCode) ? Provider.NAGAD.getDisplayName() : Provider.ROCKET.getDisplayName())));

        FirebaseDatabase db = getActiveDatabase();
        if (db == null) {
            if (callback != null) callback.onError("FIREBASE_NOT_INITIALIZED", "Active Firebase Database is not ready");
            return;
        }

        DatabaseReference txRef = db.getReference(AppConfig.PATH_TRANSACTIONS).child(cleanTxid);
        AppLogger.log("FirebaseDatabaseHelper: Pushing " + providerName + " (" + typeCode + ") TxID: " + cleanTxid + ", Tk " + cleanAmount + " from " + cleanSender);

        txRef.runTransaction(new Transaction.Handler() {
            private boolean alreadyExists = false;

            @NonNull
            @Override
            public Transaction.Result doTransaction(@NonNull MutableData currentData) {
                // Duplicate protection: Never overwrite existing records!
                if (currentData.getValue() != null) {
                    alreadyExists = true;
                    return Transaction.abort();
                }

                // New record: populate all expected fields
                Map<String, Object> record = new HashMap<>();
                record.put("type", typeCode);
                record.put("provider", providerName);
                record.put("amount", cleanAmount);
                record.put("agent", cleanSender);
                record.put("txid", cleanTxid);
                record.put("used", false);
                record.put("receivedAt", ServerValue.TIMESTAMP);

                currentData.setValue(record);
                return Transaction.success(currentData);
            }

            @Override
            public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot snapshot) {
                if (error != null) {
                    String code = "FIREBASE_ERROR";
                    if (error.getCode() == DatabaseError.PERMISSION_DENIED) {
                        code = "FIREBASE_PERMISSION_DENIED";
                    } else if (error.getCode() == DatabaseError.NETWORK_ERROR) {
                        code = "NETWORK_ERROR";
                    }
                    AppLogger.error("FirebaseDatabaseHelper error: " + code + " - " + error.getMessage(), error.toException());
                    if (callback != null) {
                        callback.onError(code, error.getMessage());
                    }
                    return;
                }

                if (committed) {
                    AppLogger.log("FirebaseDatabaseHelper: Successfully saved " + AppConfig.PATH_TRANSACTIONS + "/" + cleanTxid);
                    if (callback != null) {
                        callback.onSuccess(cleanTxid);
                    }
                } else if (alreadyExists) {
                    AppLogger.log("FirebaseDatabaseHelper: Record already exists: " + AppConfig.PATH_TRANSACTIONS + "/" + cleanTxid);
                    if (callback != null) {
                        callback.onAlreadyExists(cleanTxid);
                    }
                } else {
                    AppLogger.log("FirebaseDatabaseHelper: Transaction aborted for " + cleanTxid);
                    if (callback != null) {
                        callback.onError("ABORTED", "Transaction was aborted by Firebase");
                    }
                }
            }
        });
    }

    /**
     * Pushes a parsed PaymentData instance directly to Firebase Realtime Database.
     */
    public void pushParsedSms(PaymentData data, final PushCallback callback) {
        if (data == null) {
            if (callback != null) callback.onError("NULL_DATA", "PaymentData is null");
            return;
        }
        pushParsedSms(data.getProviderName(), data.getAgent(), data.getAmount(), data.getTxid(), callback);
    }

    /**
     * Checks if a transaction ID already exists in the database.
     */
    public void checkTransactionExists(String txid, final ExistenceCallback callback) {
        if (txid == null || txid.trim().isEmpty()) {
            if (callback != null) callback.onError("Invalid transaction ID");
            return;
        }

        FirebaseDatabase db = getActiveDatabase();
        if (db == null) {
            if (callback != null) callback.onError("Database not ready");
            return;
        }

        db.getReference(AppConfig.PATH_TRANSACTIONS)
                .child(txid.trim())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (callback != null) {
                            callback.onResult(snapshot.exists(), snapshot);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (callback != null) {
                            callback.onError(error.getMessage());
                        }
                    }
                });
    }

    private static String resolveTypeCode(String providerName) {
        if (providerName == null) return null;
        String lower = providerName.toLowerCase();
        if (lower.contains("bkash") || lower.equals("b")) return "B";
        if (lower.contains("nagad") || lower.equals("n")) return "N";
        if (lower.contains("rocket") || lower.equals("r")) return "R";
        if (lower.contains("upay") || lower.equals("u")) return "U";
        return null;
    }
}
