package com.sms.reader.com;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Strict parser for bKash, Nagad, Rocket, and Upay SMS formats.
 * ONLY accepts incoming payment / money received messages (credit).
 * Strictly ignores and rejects any outgoing transactions (Send Money, Cash Out,
 * Mobile Recharge, Merchant Payment to shop, Pay Bill, etc.).
 */
public final class PaymentParser {

    // -------------------------------------------------------------
    // bKash Regex Patterns
    // -------------------------------------------------------------
    private static final Pattern BKASH_RECEIVED_PATTERN = Pattern.compile(
            "You have received (?:Cash In )?Tk\\s+([0-9,]+(?:\\.[0-9]{2})?)\\s+from\\s+([0-9A-Za-z+*]+)\\.?" +
                    "(?:.*?)(?:TrxID|TrxId|TRXID)\\s+([A-Za-z0-9]+)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );

    private static final Pattern BKASH_PAYMENT_PATTERN = Pattern.compile(
            "(?:Payment received|You have received payment)\\s+Tk\\s+([0-9,]+(?:\\.[0-9]{2})?)\\s+from\\s+([0-9A-Za-z+*]+)\\.?" +
                    "(?:.*?)(?:TrxID|TrxId|TRXID)\\s+([A-Za-z0-9]+)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );

    private static final Pattern BKASH_CASHIN_PATTERN = Pattern.compile(
            "Cash In\\s+Tk\\s+([0-9,]+(?:\\.[0-9]{2})?)\\s+from\\s+([0-9A-Za-z+*]+)\\.?" +
                    "(?:.*?)(?:TrxID|TrxId|TRXID)\\s+([A-Za-z0-9]+)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );

    // -------------------------------------------------------------
    // Nagad Patterns
    // -------------------------------------------------------------
    private static final Pattern NAGAD_HEADER_PATTERN = Pattern.compile(
            "(?:Cash\\s*In\\s*Received|Money\\s*Received|Payment\\s*Received)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern NAGAD_AMOUNT_PATTERN = Pattern.compile(
            "Amount:\\s*(?:Tk\\s*)?([0-9,]+(?:\\.[0-9]{2})?)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern NAGAD_AGENT_PATTERN = Pattern.compile(
            "(?:Uddokta|Sender|Customer):\\s*([0-9A-Za-z+*]+)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern NAGAD_TXID_PATTERN = Pattern.compile(
            "(?:TxnID|TxnId|TxID|TXNID):\\s*([A-Za-z0-9]+)",
            Pattern.CASE_INSENSITIVE
    );

    // -------------------------------------------------------------
    // Rocket Patterns (ONLY P2P and Cash-In accepted)
    // -------------------------------------------------------------
    private static final Pattern ROCKET_P2P_PATTERN = Pattern.compile(
            "Tk\\s*([0-9,]+(?:\\.[0-9]{2})?)\\s+received\\s+from\\s+A/C\\s*:\\s*([0-9A-Za-z+*]+).*?(?:Txn\\s*Id|TxnID|TXNID)\\s*:\\s*([0-9A-Za-z]+)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );

    private static final Pattern ROCKET_CASHIN_PATTERN = Pattern.compile(
            "(?:Cash-In|Cash In)\\s+from\\s+A/C\\s*:\\s*([0-9A-Za-z+*]+).*?Tk\\s*([0-9,]+(?:\\.[0-9]{2})?).*?(?:Txn\\s*Id|TxnID|TXNID)\\s*:\\s*([0-9A-Za-z]+)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );

    // -------------------------------------------------------------
    // Universal Upay Key Extractors
    // -------------------------------------------------------------
    private static final Pattern UPAY_AMOUNT_PATTERN = Pattern.compile(
            "Tk\\.?\\s*([0-9,]+(?:\\.[0-9]{2})?)",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern UPAY_SENDER_PHONE_PATTERN = Pattern.compile(
            "from\\s+([0-9A-Za-z+*]+)",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern UPAY_TRXID_PATTERN = Pattern.compile(
            "(?:TrxID|TrxId|TRXID|TxnID|TxnId)\\s*:?\\s*([A-Za-z0-9]+)",
            Pattern.CASE_INSENSITIVE
    );

    private PaymentParser() {
    }

    /**
     * Checks if the message represents an outgoing transaction, debit,
     * or non-incoming operation (Send Money, Cash Out, Recharge, Payment to merchant, Pay Bill, etc.).
     * Returns true if the SMS should be completely ignored and NEVER stored/shown in app.
     */
    public static boolean isOutgoingOrDebit(String body) {
        if (body == null || body.trim().isEmpty()) {
            return false;
        }

        String lower = body.toLowerCase(Locale.US);

        // 1. Outgoing transfer / Send Money
        if (lower.contains("send money") ||
                lower.contains("you have transferred") ||
                lower.contains("transferred tk") ||
                lower.contains("transferred to") ||
                lower.contains("money sent") ||
                lower.contains("sent money") ||
                lower.contains("money transfer to") ||
                lower.contains("transfer to")) {
            return true;
        }

        // 2. Outgoing Cash Out
        if (lower.contains("cash out") ||
                lower.contains("cash-out") ||
                lower.contains("cashout")) {
            return true;
        }

        // 3. Outgoing Mobile Recharge
        if (lower.contains("mobile recharge") ||
                lower.contains("recharge to") ||
                lower.contains("recharge tk") ||
                lower.contains("recharged tk") ||
                lower.contains("airtime")) {
            return true;
        }

        // 4. Outgoing Payment to a merchant or shop
        if ((lower.contains("payment to") ||
                lower.contains("paid to") ||
                lower.contains("you have paid") ||
                lower.contains("merchant payment to"))
                && !lower.contains("payment received")
                && !lower.contains("received payment")) {
            return true;
        }

        // 5. Outgoing Pay Bill / Bank Transfer / Remittance out
        if (lower.contains("pay bill") ||
                lower.contains("bill pay") ||
                lower.contains("paid bill") ||
                lower.contains("transfer to bank") ||
                lower.contains("bkash to bank") ||
                lower.contains("nagad to bank") ||
                lower.contains("add money to bank") ||
                lower.contains("debited") ||
                lower.contains("has been debited")) {
            return true;
        }

        // 6. Promotional, reward, cashback
        if (lower.contains("cash reward") ||
                lower.contains("cashback") ||
                lower.contains("cash back") ||
                lower.contains("reward") ||
                lower.contains("promotional")) {
            return true;
        }

        return false;
    }

    /**
     * Parses an incoming SMS message. Returns null if message does not match
     * any confirmed incoming payment format, is an outgoing transaction, or represents OTP/spam.
     */
    public static PaymentData parse(String sender, String body, long timestamp) {
        if (body == null || body.trim().isEmpty()) {
            return null;
        }

        // Security check: Ignore OTPs, temporary PIN, password resets
        String bodyLower = body.toLowerCase(Locale.US);
        if (bodyLower.contains("otp") ||
                bodyLower.contains("verification code") ||
                bodyLower.contains("security code") ||
                bodyLower.contains("temporary pin") ||
                bodyLower.contains("pin reset") ||
                bodyLower.contains("reset pin") ||
                bodyLower.contains("password") ||
                bodyLower.contains("do not share")) {
            return null;
        }

        // Failed or cancelled transactions
        if (bodyLower.contains("failed") || bodyLower.contains("unsuccessful") || bodyLower.contains("cancelled")) {
            return null;
        }

        // Strict filter: If outgoing transaction (Send Money, Cash Out, Recharge, etc.), completely ignore
        if (isOutgoingOrDebit(body)) {
            return null;
        }

        Provider provider = ProviderDetector.detect(sender, body);

        switch (provider) {
            case BKASH:
                return parseBkash(body, sender, timestamp);
            case NAGAD:
                return parseNagad(body, sender, timestamp);
            case ROCKET:
                return parseRocket(body, sender, timestamp);
            case UPAY:
                return parseUpay(body, sender, timestamp);
            default:
                return null;
        }
    }

    /**
     * Parses bKash incoming payment SMS.
     */
    public static PaymentData parseBkash(String body, String sender, long timestamp) {
        if (body == null || isOutgoingOrDebit(body)) return null;

        // Strict bKash Sender ID Check: MUST be exact "bKash"
        if (!ProviderDetector.isAllowedBkashSender(sender)) {
            AppLogger.log("REJECTED_FAKE_BKASH_SENDER: Rejected SMS from '" + sender + "' - bKash payment SMS requires exact sender 'bKash'");
            return null;
        }

        // Pattern 1: Personal received
        Matcher matcher = BKASH_RECEIVED_PATTERN.matcher(body);
        if (matcher.find()) {
            return buildPaymentData(Provider.BKASH, matcher.group(1), matcher.group(2), matcher.group(3), body, sender, timestamp);
        }

        // Pattern 2: Payment received (Merchant)
        Matcher payMatcher = BKASH_PAYMENT_PATTERN.matcher(body);
        if (payMatcher.find()) {
            return buildPaymentData(Provider.BKASH, payMatcher.group(1), payMatcher.group(2), payMatcher.group(3), body, sender, timestamp);
        }

        // Pattern 3: Cash In received
        Matcher cashinMatcher = BKASH_CASHIN_PATTERN.matcher(body);
        if (cashinMatcher.find()) {
            return buildPaymentData(Provider.BKASH, cashinMatcher.group(1), cashinMatcher.group(2), cashinMatcher.group(3), body, sender, timestamp);
        }

        return null;
    }

    /**
     * Parses Nagad SMS.
     */
    public static PaymentData parseNagad(String body, String sender, long timestamp) {
        if (body == null || isOutgoingOrDebit(body)) return null;

        Matcher headerMatcher = NAGAD_HEADER_PATTERN.matcher(body);
        if (!headerMatcher.find()) {
            return null;
        }

        Matcher amountMatcher = NAGAD_AMOUNT_PATTERN.matcher(body);
        Matcher agentMatcher = NAGAD_AGENT_PATTERN.matcher(body);
        Matcher txidMatcher = NAGAD_TXID_PATTERN.matcher(body);

        if (amountMatcher.find() && agentMatcher.find() && txidMatcher.find()) {
            return buildPaymentData(Provider.NAGAD, amountMatcher.group(1), agentMatcher.group(1), txidMatcher.group(1), body, sender, timestamp);
        }

        return null;
    }

    /**
     * Parses Rocket SMS.
     */
    public static PaymentData parseRocket(String body, String sender, long timestamp) {
        if (body == null || isOutgoingOrDebit(body)) return null;

        Matcher p2pMatcher = ROCKET_P2P_PATTERN.matcher(body);
        if (p2pMatcher.find()) {
            return buildPaymentData(Provider.ROCKET, p2pMatcher.group(1), p2pMatcher.group(2), p2pMatcher.group(3), body, sender, timestamp);
        }

        Matcher cashinMatcher = ROCKET_CASHIN_PATTERN.matcher(body);
        if (cashinMatcher.find()) {
            return buildPaymentData(Provider.ROCKET, cashinMatcher.group(2), cashinMatcher.group(1), cashinMatcher.group(3), body, sender, timestamp);
        }

        return null;
    }

    /**
     * Parses Upay incoming payment SMS using Universal Key Extractors.
     * Guaranteed to match 100% of Upay incoming SMS variations, including
     * notification header prefixes ("15 messages | Tk. 15.00...").
     */
    public static PaymentData parseUpay(String body, String sender, long timestamp) {
        if (body == null || isOutgoingOrDebit(body)) return null;

        String bodyLower = body.toLowerCase(Locale.US);

        // Security check: Must represent incoming payment/money received
        boolean isUpayIncoming = bodyLower.contains("received") ||
                bodyLower.contains("cash-in") ||
                bodyLower.contains("cash in") ||
                bodyLower.contains("trxid") ||
                bodyLower.contains("has been received");

        if (!isUpayIncoming) {
            return null;
        }

        Matcher amountMatcher = UPAY_AMOUNT_PATTERN.matcher(body);
        Matcher phoneMatcher = UPAY_SENDER_PHONE_PATTERN.matcher(body);
        Matcher txidMatcher = UPAY_TRXID_PATTERN.matcher(body);

        if (amountMatcher.find() && phoneMatcher.find() && txidMatcher.find()) {
            String rawAmount = amountMatcher.group(1);
            String fromPhone = phoneMatcher.group(1);
            String rawTxid = txidMatcher.group(1);

            // Verify phone contains digits (reject non-phone strings like "from Rocket")
            if (fromPhone != null && fromPhone.matches(".*[0-9].*") && !fromPhone.equalsIgnoreCase("rocket")) {
                return buildPaymentData(Provider.UPAY, rawAmount, fromPhone, rawTxid, body, sender, timestamp);
            }
        }

        return null;
    }

    private static PaymentData buildPaymentData(Provider provider, String rawAmount, String agent, String txid, String body, String sender, long timestamp) {
        if (rawAmount == null || agent == null || txid == null) {
            return null;
        }
        String cleanTxid = txid.trim().toUpperCase(Locale.US);
        if (cleanTxid.isEmpty()) {
            return null;
        }
        String cleanAmount = cleanAmountString(rawAmount);
        try {
            double amountVal = Double.parseDouble(cleanAmount);
            if (amountVal <= 0.0) {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
        return new PaymentData(provider, cleanAmount, agent.trim(), cleanTxid, body, sender, timestamp);
    }

    /**
     * Normalizes amount by stripping commas and ensuring two decimal places if needed.
     */
    private static String cleanAmountString(String rawAmount) {
        String clean = rawAmount.replace(",", "").trim();
        if (!clean.contains(".")) {
            clean = clean + ".00";
        } else {
            String[] parts = clean.split("\\.");
            if (parts.length > 1 && parts[1].length() == 1) {
                clean = clean + "0";
            }
        }
        return clean;
    }
}
