package com.sms.reader.com;

import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.sms.reader.com.databinding.FragmentHomeBinding;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private SmsStore smsStore;
    private SettingsRepository settingsRepo;
    private FirebaseConfigManager configManager;
    private FirebaseProvider fbProvider;
    private Provider selectedProvider = Provider.BKASH;

    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockRunnable = new Runnable() {
        @Override
        public void run() {
            if (binding != null && binding.tvHeaderClock != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a", Locale.US);
                binding.tvHeaderClock.setText(sdf.format(new Date()));
            }
            clockHandler.postDelayed(this, 1000);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Context ctx = requireContext();
        smsStore = new SmsStore(ctx);
        settingsRepo = SettingsRepository.getInstance(ctx);
        configManager = FirebaseConfigManager.getInstance(ctx);
        fbProvider = FirebaseProvider.getInstance(ctx);

        setupListeners();
        updateDashboardUi();
    }

    private final BroadcastReceiver syncQueueReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (getActivity() != null) {
                getActivity().runOnUiThread(HomeFragment.this::updateDashboardUi);
            }
        }
    };

    private final SettingsRepository.SettingsListener settingsListener = (provider, setting) -> {
        if (getActivity() != null) {
            getActivity().runOnUiThread(this::updateDashboardUi);
        }
    };

    private final AppLogger.LogListener logListener = (newEntry, fullLog) -> {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                if (binding != null && binding.tvLogConsole != null) {
                    if (newEntry != null) {
                        if (binding.tvLogConsole.getLineCount() > 150) {
                            binding.tvLogConsole.setText(AppLogger.getFullLog());
                        } else {
                            binding.tvLogConsole.append(newEntry + "\n");
                        }
                    } else {
                        binding.tvLogConsole.setText(fullLog != null ? fullLog : "");
                    }
                    if (binding.scrollLog != null) {
                        binding.scrollLog.post(() -> binding.scrollLog.fullScroll(View.FOCUS_DOWN));
                    }
                }
            });
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        clockHandler.post(clockRunnable);
        if (settingsRepo != null) settingsRepo.addListener(settingsListener);
        AppLogger.setListener(logListener);
        if (binding != null && binding.tvLogConsole != null) {
            binding.tvLogConsole.setText(AppLogger.getFullLog());
            if (binding.scrollLog != null) {
                binding.scrollLog.post(() -> binding.scrollLog.fullScroll(View.FOCUS_DOWN));
            }
        }
        try {
            IntentFilter filter = new IntentFilter(SmsSyncManager.ACTION_SYNC_QUEUE_UPDATED);
            ContextCompat.registerReceiver(requireContext(), syncQueueReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
        } catch (Exception ignored) {}
        updateDashboardUi();
    }

    @Override
    public void onPause() {
        super.onPause();
        clockHandler.removeCallbacks(clockRunnable);
        if (settingsRepo != null) settingsRepo.removeListener(settingsListener);
        AppLogger.setListener(null);
        try {
            requireContext().unregisterReceiver(syncQueueReceiver);
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void updateDashboardUi() {
        if (binding == null || !isAdded()) return;

        Context ctx = getContext();
        if (ctx == null) return;

        boolean isPhp = BackendManager.getInstance(ctx).isPhpMode();
        boolean isConnected = false;

        if (isPhp) {
            isConnected = PhpConfigManager.getInstance(ctx).isConfigured();
        } else {
            FirebaseConfig activeFb = configManager.getActiveConfig();
            isConnected = activeFb != null && activeFb.isValid() && !"DEFAULT_DELETED".equals(activeFb.getProjectId());
        }

        // 1. Terminal Status Card
        if (isPhp) {
            PhpConfig phpConfig = PhpConfigManager.getInstance(ctx).getActiveConfig();
            if (phpConfig != null && phpConfig.isValid()) {
                binding.tvActiveProjectName.setText("Backend: " + phpConfig.getDisplayDomain());
                binding.tvActiveConfigType.setText("");
                binding.tvFirebaseStatus.setText("● Connected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));
            } else {
                binding.tvActiveProjectName.setText("Backend: Not Configured");
                binding.tvActiveConfigType.setText("");
                binding.tvFirebaseStatus.setText("● Disconnected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));
            }
        } else {
            FirebaseConfig active = configManager.getActiveConfig();
            if (active == null || "DEFAULT_DELETED".equals(active.getProjectId()) || active.getProjectId().isEmpty() || !active.isValid()) {
                binding.tvActiveProjectName.setText("Backend: Not Configured");
                binding.tvActiveConfigType.setText("");
                binding.tvFirebaseStatus.setText("● Disconnected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_amber));
            } else {
                binding.tvActiveProjectName.setText("Project: " + active.getProjectId());
                binding.tvActiveConfigType.setText("");
                binding.tvFirebaseStatus.setText("● Connected");
                binding.tvFirebaseStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_green));
            }
        }

        // 2. Selected Provider Configured Number Card Update
        if (binding.tvSelectedProviderName != null) {
            String emoji = "🌸 ";
            if (selectedProvider == Provider.NAGAD) emoji = "🔥 ";
            else if (selectedProvider == Provider.ROCKET) emoji = "🚀 ";
            else if (selectedProvider == Provider.UPAY) emoji = "⚡ ";

            binding.tvSelectedProviderName.setText(emoji + selectedProvider.getDisplayName());

            String num = "Not configured";
            String badgeText = "NOT CONFIGURED";
            int badgeColor = ContextCompat.getColor(ctx, R.color.status_amber);

            if (isConnected) {
                SettingsRepository.ProviderSetting setting = isPhp ?
                        PhpConfigManager.getInstance(ctx).getProviderSetting(selectedProvider) :
                        settingsRepo.getSetting(selectedProvider);
                if (setting.isConfigured()) {
                    num = setting.getNumber();
                    badgeText = setting.isEnabled() ? "ENABLED" : "DISABLED";
                    badgeColor = setting.isEnabled() ? ContextCompat.getColor(ctx, R.color.status_green) : ContextCompat.getColor(ctx, R.color.status_red);
                }
            }

            binding.tvAdminNumber.setText(num);
            binding.tvAdminStatus.setText(badgeText);
            binding.tvAdminStatus.setTextColor(badgeColor);
        }

        // 2. Metrics & Recent Transactions
        if (!isConnected) {
            binding.tvMetricDayAmount.setText("৳ 0");
            binding.tvMetricDayTxn.setText("0 Txn");
            binding.tvMetricMonthAmount.setText("৳ 0");
            binding.tvMetricMonthTxn.setText("0 Txn");
            binding.tvMetricYearAmount.setText("৳ 0");
            binding.tvMetricYearTxn.setText("0 Txn");

            binding.tvNoTxnNotice.setVisibility(View.VISIBLE);
            binding.layoutRecentTxnRows.removeAllViews();
            binding.layoutRecentTxnRows.setVisibility(View.GONE);
        } else {
            // Calendar Midnight & Period Boundaries
            Calendar calDay = Calendar.getInstance();
            calDay.set(Calendar.HOUR_OF_DAY, 0);
            calDay.set(Calendar.MINUTE, 0);
            calDay.set(Calendar.SECOND, 0);
            calDay.set(Calendar.MILLISECOND, 0);
            long startOfDay = calDay.getTimeInMillis(); // Resets at 12:00 AM Midnight!

            Calendar calMonth = Calendar.getInstance();
            calMonth.set(Calendar.DAY_OF_MONTH, 1);
            calMonth.set(Calendar.HOUR_OF_DAY, 0);
            calMonth.set(Calendar.MINUTE, 0);
            calMonth.set(Calendar.SECOND, 0);
            calMonth.set(Calendar.MILLISECOND, 0);
            long startOfMonth = calMonth.getTimeInMillis(); // Resets on 1st day of Month!

            Calendar calYear = Calendar.getInstance();
            calYear.set(Calendar.DAY_OF_YEAR, 1);
            calYear.set(Calendar.HOUR_OF_DAY, 0);
            calYear.set(Calendar.MINUTE, 0);
            calYear.set(Calendar.SECOND, 0);
            calYear.set(Calendar.MILLISECOND, 0);
            long startOfYear = calYear.getTimeInMillis(); // Resets on Jan 1st of Year!

            long dayTxnCount = 0;
            double dayTotalAmount = 0.0;

            long monthTxnCount = 0;
            double monthTotalAmount = 0.0;

            long yearTxnCount = 0;
            double yearTotalAmount = 0.0;

            int totalRowsCount = 0;
            binding.layoutRecentTxnRows.removeAllViews();

            // Calculate Day, Month, Year totals from durable queue & store records
            SmsSyncManager syncMgr = SmsSyncManager.getInstance(ctx);
            List<SmsSyncEntity> allSyncRecords = syncMgr.getRecordsForFilter("ALL");

            for (SmsSyncEntity record : allSyncRecords) {
                long ts = record.getTimestamp();
                double amt = 0.0;
                try {
                    String amtStr = record.getAmount().replace(",", "").trim();
                    if (!amtStr.isEmpty() && !"—".equals(amtStr)) {
                        amt = Double.parseDouble(amtStr);
                    }
                } catch (Exception ignored) {}

                if (ts >= startOfDay) {
                    dayTxnCount++;
                    dayTotalAmount += amt;
                }
                if (ts >= startOfMonth) {
                    monthTxnCount++;
                    monthTotalAmount += amt;
                }
                if (ts >= startOfYear) {
                    yearTxnCount++;
                    yearTotalAmount += amt;
                }
            }

            // Populate Recent Transactions Table (Latest SMS for each provider)
            for (Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
                if (smsStore.isParseSuccess(p)) {
                    totalRowsCount++;
                    String amtStr = smsStore.getAmount(p);
                    String agent = smsStore.getAgent(p);
                    String txid = smsStore.getTxid(p);
                    long timestamp = smsStore.getTimestamp(p);
                    String timeStr = timestamp > 0 ? new SimpleDateFormat("hh:mm a", Locale.US).format(new Date(timestamp)) : "";

                    LinearLayout row = new LinearLayout(ctx);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setPadding(0, 16, 0, 16);
                    row.setGravity(Gravity.CENTER_VERTICAL);

                    // Provider Column with Time Subtext
                    LinearLayout colProv = new LinearLayout(ctx);
                    colProv.setOrientation(LinearLayout.VERTICAL);
                    colProv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f));

                    TextView tvProv = new TextView(ctx);
                    tvProv.setText(p.getDisplayName());
                    tvProv.setTextColor(Color.WHITE);
                    tvProv.setTextSize(12);
                    tvProv.setTypeface(null, Typeface.BOLD);

                    TextView tvTime = new TextView(ctx);
                    tvTime.setText(timeStr);
                    tvTime.setTextColor(Color.parseColor("#94A3B8"));
                    tvTime.setTextSize(10);

                    colProv.addView(tvProv);
                    if (!timeStr.isEmpty()) colProv.addView(tvTime);

                    // Account Column
                    TextView tvAcc = new TextView(ctx);
                    tvAcc.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f));
                    tvAcc.setText(agent.isEmpty() ? "—" : agent);
                    tvAcc.setTextColor(Color.parseColor("#94A3B8"));
                    tvAcc.setTextSize(12);
                    tvAcc.setSingleLine(true);
                    tvAcc.setEllipsize(TextUtils.TruncateAt.MIDDLE);

                    // Amount Column
                    TextView tvAmt = new TextView(ctx);
                    tvAmt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
                    tvAmt.setText("৳ " + (amtStr.isEmpty() ? "0" : amtStr));
                    tvAmt.setTextColor(Color.parseColor("#00F5A0"));
                    tvAmt.setTextSize(12);
                    tvAmt.setTypeface(null, Typeface.BOLD);

                    // TrxID Column (Tap text directly to copy - No extra buttons or icons)
                    TextView tvTx = new TextView(ctx);
                    tvTx.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
                    tvTx.setText(txid.isEmpty() ? "—" : txid);
                    tvTx.setTextColor(Color.parseColor("#38BDF8"));
                    tvTx.setTextSize(11);
                    tvTx.setSingleLine(true);
                    tvTx.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                    tvTx.setGravity(Gravity.END);
                    tvTx.setTypeface(null, Typeface.BOLD);
                    tvTx.setClickable(true);
                    tvTx.setFocusable(true);

                    final String finalTxid = txid;
                    tvTx.setOnClickListener(v -> {
                        if (!finalTxid.isEmpty() && !"—".equals(finalTxid)) {
                            ClipboardManager clipboard = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                            if (clipboard != null) {
                                ClipData clip = ClipData.newPlainText("TrxID", finalTxid);
                                clipboard.setPrimaryClip(clip);
                                Toast.makeText(ctx, "TrxID " + finalTxid + " copied", Toast.LENGTH_SHORT).show();
                                AppLogger.log("Copied TrxID: " + finalTxid);
                            }
                        }
                    });

                    row.addView(colProv);
                    row.addView(tvAcc);
                    row.addView(tvAmt);
                    row.addView(tvTx);

                    binding.layoutRecentTxnRows.addView(row);
                }
            }

            // Update Day, Month, Year cards with exact period totals
            binding.tvMetricDayAmount.setText("৳ " + (dayTotalAmount > 0 ? String.format(Locale.US, "%.2f", dayTotalAmount) : "0"));
            binding.tvMetricDayTxn.setText(dayTxnCount + " Txn");

            binding.tvMetricMonthAmount.setText("৳ " + (monthTotalAmount > 0 ? String.format(Locale.US, "%.2f", monthTotalAmount) : "0"));
            binding.tvMetricMonthTxn.setText(monthTxnCount + " Txn");

            binding.tvMetricYearAmount.setText("৳ " + (yearTotalAmount > 0 ? String.format(Locale.US, "%.2f", yearTotalAmount) : "0"));
            binding.tvMetricYearTxn.setText(yearTxnCount + " Txn");

            if (totalRowsCount > 0) {
                binding.tvNoTxnNotice.setVisibility(View.GONE);
                binding.layoutRecentTxnRows.setVisibility(View.VISIBLE);
            } else {
                binding.tvNoTxnNotice.setVisibility(View.VISIBLE);
                binding.layoutRecentTxnRows.setVisibility(View.GONE);
            }
        }

        // 3. Payment SMS Sync Center Card Update
        SmsSyncManager syncMgr = SmsSyncManager.getInstance(ctx);
        if (binding.tvCountOffline != null) {
            binding.tvCountOffline.setText(String.format(Locale.US, "%02d", syncMgr.getOfflineCount()));
            binding.tvCountFailed.setText(String.format(Locale.US, "%02d", syncMgr.getFailedCount()));
            binding.tvCountPending.setText(String.format(Locale.US, "%02d", syncMgr.getPendingCount()));
            binding.tvCountSynced.setText(String.format(Locale.US, "%02d", syncMgr.getSyncedCount()));

            boolean autoSyncOn = syncMgr.isAutoSyncEnabled();
            binding.tvSyncCenterAutoSyncBadge.setText("Auto Sync: " + (autoSyncOn ? "ON" : "OFF"));
            binding.tvSyncCenterAutoSyncBadge.setTextColor(ContextCompat.getColor(ctx, autoSyncOn ? R.color.status_green : R.color.status_amber));

            binding.tvSyncBackendMeta.setText("Backend: " + (isPhp ? "PHP MySQL" : "Firebase"));

            long lastTime = syncMgr.getLastSyncedTimestamp();
            if (lastTime > 0) {
                binding.tvSyncLastTimeMeta.setText("Last Sync: " + new SimpleDateFormat("hh:mm a", Locale.US).format(new Date(lastTime)));
            } else {
                binding.tvSyncLastTimeMeta.setText("Last Sync: Never");
            }
        }
    }

    public void setSelectedProvider(Provider provider) {
        if (provider != null && provider != Provider.UNKNOWN) {
            this.selectedProvider = provider;
            if (binding != null) {
                updateDashboardUi();
            }
        }
    }

    private void setupListeners() {
        if (binding == null) return;

        // Sync Center Card Actions
        View.OnClickListener openSyncCenterListener = v -> {
            new SyncCenterDetailsDialog(requireContext()).show();
        };

        if (binding.cardSyncCenter != null) binding.cardSyncCenter.setOnClickListener(openSyncCenterListener);
        if (binding.btnSyncCenterViewSms != null) binding.btnSyncCenterViewSms.setOnClickListener(openSyncCenterListener);

        if (binding.btnSyncCenterRetryAll != null) {
            binding.btnSyncCenterRetryAll.setOnClickListener(v -> {
                SmsSyncManager sync = SmsSyncManager.getInstance(requireContext());
                if (!sync.isNetworkConnected()) {
                    Toast.makeText(requireContext(), "Waiting for Internet Connection...", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(requireContext(), "Retrying all pending SMS...", Toast.LENGTH_SHORT).show();
                sync.syncPendingQueue((success, failed) -> {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            updateDashboardUi();
                            Toast.makeText(requireContext(), "Sync complete: " + success + " Synced, " + failed + " Failed", Toast.LENGTH_SHORT).show();
                        });
                    }
                });
            });
        }

        binding.tabBkash.setOnClickListener(v -> { selectedProvider = Provider.BKASH; updateDashboardUi(); });
        binding.tabNagad.setOnClickListener(v -> { selectedProvider = Provider.NAGAD; updateDashboardUi(); });
        binding.tabRocket.setOnClickListener(v -> { selectedProvider = Provider.ROCKET; updateDashboardUi(); });
        binding.tabUpay.setOnClickListener(v -> { selectedProvider = Provider.UPAY; updateDashboardUi(); });

        binding.cardTerminalStatus.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).onTerminalCardClicked();
            }
        });

        binding.tvViewAllTxn.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).showAllTransactionsDialog();
            }
        });

        binding.btnClearLog.setOnClickListener(v -> {
            AppLogger.clear();
            if (binding.tvLogConsole != null) binding.tvLogConsole.setText("");
        });

        // Enable smooth, independent inner vertical scrolling for System Log Console
        if (binding.scrollLog != null) {
            binding.scrollLog.setOnTouchListener((v, event) -> {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            });
        }

        // Developer Facebook Profile Link
        View.OnClickListener openFacebookListener = v -> {
            try {
                String fbUrl = "https://www.facebook.com/share/1BM4waZmSS/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(fbUrl));
                startActivity(intent);
                AppLogger.log("Opening developer Facebook profile: " + fbUrl);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Could not open Facebook link", Toast.LENGTH_SHORT).show();
            }
        };

        if (binding.layoutFooter != null) binding.layoutFooter.setOnClickListener(openFacebookListener);
        if (binding.tvFooterDeveloper != null) binding.tvFooterDeveloper.setOnClickListener(openFacebookListener);
    }
}
