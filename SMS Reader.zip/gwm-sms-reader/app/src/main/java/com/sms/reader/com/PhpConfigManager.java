package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONObject;

import java.util.UUID;

/**
 * Manages storage, import, and retrieval of PHP API Backend configuration.
 */
public final class PhpConfigManager {

    private static final String PREFS_NAME = "gwm_php_config_prefs";
    private static final String KEY_API_BASE_URL = "php_api_base_url";
    private static final String KEY_DEVICE_SECRET = "php_device_secret";
    private static final String KEY_DEVICE_ID = "php_device_id";
    private static final String KEY_ACTIVE = "php_backend_active";

    private static PhpConfigManager instance;

    private final SharedPreferences prefs;
    private final Context appContext;

    public static synchronized PhpConfigManager getInstance(Context context) {
        if (instance == null) {
            instance = new PhpConfigManager(context.getApplicationContext());
        }
        return instance;
    }

    private PhpConfigManager(Context context) {
        this.appContext = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    @NonNull
    public String getOrCreateDeviceId() {
        String id = prefs.getString(KEY_DEVICE_ID, null);
        if (id == null || id.trim().isEmpty()) {
            id = "device-" + UUID.randomUUID().toString().substring(0, 12);
            prefs.edit().putString(KEY_DEVICE_ID, id).apply();
        }
        return id;
    }

    @Nullable
    public PhpConfig getActiveConfig() {
        String url = prefs.getString(KEY_API_BASE_URL, "");
        String secret = prefs.getString(KEY_DEVICE_SECRET, "");
        String id = getOrCreateDeviceId();
        boolean active = prefs.getBoolean(KEY_ACTIVE, false);

        PhpConfig config = new PhpConfig(url, secret, id, active);
        return config.isValid() ? config : null;
    }

    public void saveConfig(@NonNull String apiBaseUrl, @NonNull String deviceSecret) {
        String id = getOrCreateDeviceId();
        PhpConfig config = new PhpConfig(apiBaseUrl, deviceSecret, id, true);
        if (config.isValid()) {
            prefs.edit()
                    .putString(KEY_API_BASE_URL, config.getApiBaseUrl())
                    .putString(KEY_DEVICE_SECRET, config.getDeviceSecret())
                    .putString(KEY_DEVICE_ID, id)
                    .putBoolean(KEY_ACTIVE, true)
                    .apply();
            AppLogger.log("PHP Config saved: " + config.getApiBaseUrl());
        }
    }

    public void saveFirewallCookie(@Nullable String cookie) {
        if (cookie != null && !cookie.trim().isEmpty()) {
            prefs.edit().putString("php_firewall_cookie", cookie.trim()).apply();
            AppLogger.log("Saved WAF/Imunify360 Cookie: " + cookie.trim());
        }
    }

    @Nullable
    public String getSavedFirewallCookie() {
        return prefs.getString("php_firewall_cookie", null);
    }

    public void clearConfig() {
        prefs.edit()
                .remove(KEY_API_BASE_URL)
                .remove(KEY_DEVICE_SECRET)
                .remove("php_firewall_cookie")
                .putBoolean(KEY_ACTIVE, false)
                .apply();
        AppLogger.log("PHP Config cleared.");
    }

    public boolean isConfigured() {
        PhpConfig cfg = getActiveConfig();
        return cfg != null && cfg.isValid();
    }

    public void saveProviderNumber(@NonNull Provider provider, @Nullable String number, boolean enabled) {
        if (provider == Provider.UNKNOWN) return;
        String cleanNum = number != null ? number.trim() : "";
        prefs.edit()
                .putString("php_num_" + provider.getSettingsKey(), cleanNum)
                .putBoolean("php_en_" + provider.getSettingsKey(), enabled)
                .apply();
    }

    @NonNull
    public SettingsRepository.ProviderSetting getProviderSetting(@NonNull Provider provider) {
        if (provider == Provider.UNKNOWN) {
            return new SettingsRepository.ProviderSetting("Not configured", false);
        }
        String num = prefs.getString("php_num_" + provider.getSettingsKey(), "Not configured");
        boolean en = prefs.getBoolean("php_en_" + provider.getSettingsKey(), true);
        return new SettingsRepository.ProviderSetting(num, en);
    }

    public void parseAndSaveProviderNumbers(@Nullable JSONObject responseJson) {
        if (responseJson == null) return;

        // Extract 'receivers' object (returned by connection_test.php) or 'provider_numbers' object or root
        JSONObject numbersObj = responseJson.optJSONObject("receivers");
        if (numbersObj == null) {
            numbersObj = responseJson.optJSONObject("provider_numbers");
        }
        if (numbersObj == null) {
            numbersObj = responseJson;
        }

        for (Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
            String num = numbersObj.optString(p.getSettingsKey(), numbersObj.optString(p.getDisplayName(), ""));
            if (num.isEmpty() && numbersObj.has(p.name())) {
                num = numbersObj.optString(p.name(), "");
            }
            if (!num.trim().isEmpty() && !"null".equalsIgnoreCase(num.trim()) && !"Not configured".equalsIgnoreCase(num.trim())) {
                saveProviderNumber(p, num.trim(), true);
                AppLogger.log("PHP Approved Receiver Number for " + p.getDisplayName() + ": " + num.trim());
            }
        }
    }

    @NonNull
    public PhpConfig parsePhpConnectorJson(@NonNull String jsonContent) throws Exception {
        JSONObject root = new JSONObject(jsonContent);
        String url = root.optString("api_base_url", root.optString("api_url", root.optString("url", ""))).trim();
        String secret = root.optString("device_secret", root.optString("master_secret", root.optString("secret", root.optString("pairing_key", "")))).trim();
        String deviceId = root.optString("device_id", getOrCreateDeviceId()).trim();

        if (url.isEmpty()) {
            throw new IllegalArgumentException("Invalid PHP Connector JSON: 'api_base_url' or 'api_url' is missing.");
        }

        PhpConfig config = new PhpConfig(url, secret, deviceId, true);
        if (!config.isValid()) {
            throw new IllegalArgumentException("Invalid PHP Connector JSON: URL or Secret invalid.");
        }
        return config;
    }
}
