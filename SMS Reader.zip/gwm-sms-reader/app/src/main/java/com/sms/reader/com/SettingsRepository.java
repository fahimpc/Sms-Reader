package com.sms.reader.com;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Listens in real time to Admin settings in Firebase Realtime Database for all supported payment providers:
 * bKash, Nagad, Rocket, Upay.
 *
 * Supports case-insensitive key detection (e.g., "bKash" vs "bkash", "Nagad" vs "nagad", "Rocket" vs "rocket", "upay" vs "Upay"),
 * diverse field formats (number, phone, account, mobile, admin_number, personal, agent, merchant, etc.),
 * dynamic project switching, and instant live sync when numbers are added, updated, or removed from the Admin panel.
 */
public final class SettingsRepository {

    public static class ProviderSetting {
        private String number = "Not configured";
        private boolean enabled = true;

        public ProviderSetting(String number, boolean enabled) {
            this.number = (number != null && !number.trim().isEmpty()) ? number.trim() : "Not configured";
            this.enabled = isConfigured() && enabled;
        }

        public String getNumber() {
            return number;
        }

        public boolean isEnabled() {
            return isConfigured() && enabled;
        }

        public boolean isConfigured() {
            return number != null && !number.trim().isEmpty() && !"Not configured".equalsIgnoreCase(number.trim());
        }
    }

    public interface SettingsListener {
        void onSettingsChanged(Provider provider, ProviderSetting setting);
    }

    private static SettingsRepository instance;

    private final Context appContext;
    private final SharedPreferences prefs;
    private final Map<Provider, ProviderSetting> settingsCache = new HashMap<>();
    private final List<SettingsListener> listeners = new ArrayList<>();
    private final Map<DatabaseReference, ValueEventListener> activeDbListeners = new HashMap<>();

    public static synchronized SettingsRepository getInstance(Context context) {
        if (instance == null) {
            instance = new SettingsRepository(context.getApplicationContext());
        }
        return instance;
    }

    private SettingsRepository(Context context) {
        this.appContext = context;
        this.prefs = context.getSharedPreferences("gwm_payment_settings", Context.MODE_PRIVATE);

        // Load local cached settings from SharedPreferences
        for (Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
            String num = prefs.getString(p.getSettingsKey() + "_num", "Not configured");
            boolean configured = num != null && !num.trim().isEmpty() && !"Not configured".equalsIgnoreCase(num.trim());
            boolean en = prefs.getBoolean(p.getSettingsKey() + "_en", configured);
            settingsCache.put(p, new ProviderSetting(num, en));
        }

        FirebaseDatabase db = FirebaseProvider.getInstance(context).getDatabase();
        if (db != null) {
            startRealtimeListeners(db);
        }
    }

    public synchronized void addListener(SettingsListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
            for (Map.Entry<Provider, ProviderSetting> entry : settingsCache.entrySet()) {
                listener.onSettingsChanged(entry.getKey(), entry.getValue());
            }
        }
    }

    public synchronized void removeListener(SettingsListener listener) {
        listeners.remove(listener);
    }

    public synchronized ProviderSetting getSetting(Provider provider) {
        if (provider == null) {
            return new ProviderSetting("Not configured", false);
        }
        ProviderSetting setting = settingsCache.get(provider);
        if (setting == null) {
            return new ProviderSetting("Not configured", false);
        }
        return setting;
    }

    public boolean isProviderEnabled(Provider provider) {
        return getSetting(provider).isEnabled();
    }

    public String getProviderNumber(Provider provider) {
        return getSetting(provider).getNumber();
    }

    /**
     * Reconnects settings listeners to a new Firebase database instance upon project switch.
     */
    public synchronized void reconnect(@NonNull FirebaseDatabase newDatabase) {
        AppLogger.log("Reconnecting paymentSettings listeners to new Firebase Database...");
        detachCurrentListeners();
        startRealtimeListeners(newDatabase);
    }

    private synchronized void detachCurrentListeners() {
        for (Map.Entry<DatabaseReference, ValueEventListener> entry : activeDbListeners.entrySet()) {
            try {
                entry.getKey().removeEventListener(entry.getValue());
            } catch (Exception ignored) {}
        }
        activeDbListeners.clear();
    }

    private synchronized void startRealtimeListeners(@NonNull FirebaseDatabase database) {
        // 1. Root listener on standard path: paymentSettings
        attachSettingsTreeListener(database.getReference(AppConfig.PATH_SETTINGS), "paymentSettings");

        // 2. Also listen to alternative paths in case Admin panel uses them
        attachSettingsTreeListener(database.getReference("payment_settings"), "payment_settings");
        attachSettingsTreeListener(database.getReference("settings"), "settings");
        attachSettingsTreeListener(database.getReference("paymentMethods"), "paymentMethods");
        attachSettingsTreeListener(database.getReference("admin/paymentSettings"), "admin/paymentSettings");

        // 3. Attach targeted child listeners for both lowercase and capitalized keys
        // (e.g. bkash & bKash, nagad & Nagad, rocket & Rocket, upay & Upay)
        DatabaseReference settingsRoot = database.getReference(AppConfig.PATH_SETTINGS);
        for (final Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
            String[] targetChildKeys = new String[]{
                    p.getSettingsKey(),                      // e.g. "bkash"
                    p.getDisplayName(),                      // e.g. "bKash"
                    capitalize(p.getSettingsKey()),          // e.g. "Bkash"
                    p.name()                                 // e.g. "BKASH"
            };

            for (String childKey : targetChildKeys) {
                final DatabaseReference childRef = settingsRoot.child(childKey);
                ValueEventListener childListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            ProviderSetting setting = extractSettingFromSnapshot(snapshot);
                            if (setting.isConfigured()) {
                                updateProviderSetting(p, setting);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Handled by root listener
                    }
                };

                childRef.addValueEventListener(childListener);
                activeDbListeners.put(childRef, childListener);
            }
        }
    }

    private void attachSettingsTreeListener(final DatabaseReference ref, final String pathName) {
        ValueEventListener treeListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot rootSnapshot) {
                if (!rootSnapshot.exists()) {
                    AppLogger.log("Node " + pathName + " is empty or does not exist in Firebase.");
                    if (AppConfig.PATH_SETTINGS.equals(pathName)) {
                        // Only reset if standard paymentSettings root was checked and is empty
                        for (Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
                            updateProviderSetting(p, new ProviderSetting("Not configured", false));
                        }
                    }
                    return;
                }

                // Log child keys found for debugging and visibility
                StringBuilder childKeys = new StringBuilder();
                for (DataSnapshot child : rootSnapshot.getChildren()) {
                    if (childKeys.length() > 0) childKeys.append(", ");
                    childKeys.append(child.getKey());
                }
                AppLogger.log("Loaded " + pathName + " -> found keys: [" + childKeys.toString() + "]");

                // Process all supported providers
                for (Provider p : new Provider[]{Provider.BKASH, Provider.NAGAD, Provider.ROCKET, Provider.UPAY}) {
                    DataSnapshot pSnapshot = findSnapshotForProvider(rootSnapshot, p);
                    if (pSnapshot != null && pSnapshot.exists()) {
                        ProviderSetting setting = extractSettingFromSnapshot(pSnapshot);
                        if (setting.isConfigured()) {
                            updateProviderSetting(p, setting);
                        } else if (AppConfig.PATH_SETTINGS.equals(pathName)) {
                            updateProviderSetting(p, new ProviderSetting("Not configured", false));
                        }
                    } else if (AppConfig.PATH_SETTINGS.equals(pathName)) {
                        // Not present under paymentSettings -> marked as Not configured
                        updateProviderSetting(p, new ProviderSetting("Not configured", false));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                AppLogger.error("Failed to read settings from " + pathName + ": " + error.getMessage(), error.toException());
            }
        };

        ref.addValueEventListener(treeListener);
        activeDbListeners.put(ref, treeListener);
    }

    /**
     * Finds the DataSnapshot corresponding to a specific Provider within the root settings snapshot,
     * checking candidate keys and prioritizing any candidate that has a configured number.
     */
    @Nullable
    private DataSnapshot findSnapshotForProvider(@NonNull DataSnapshot rootSnapshot, @NonNull Provider provider) {
        DataSnapshot bestFallback = null;

        // 1. Direct candidate keys
        String[] directKeys = new String[]{
                provider.getSettingsKey(),                      // e.g. "bkash"
                provider.getDisplayName(),                      // e.g. "bKash"
                capitalize(provider.getSettingsKey()),          // e.g. "Bkash"
                provider.name(),                                // e.g. "BKASH"
                provider.getSettingsKey().toUpperCase()
        };

        for (String key : directKeys) {
            if (rootSnapshot.hasChild(key)) {
                DataSnapshot child = rootSnapshot.child(key);
                if (child.exists()) {
                    ProviderSetting setting = extractSettingFromSnapshot(child);
                    if (setting.isConfigured()) {
                        return child; // Found candidate with valid number!
                    }
                    if (bestFallback == null) {
                        bestFallback = child;
                    }
                }
            }
        }

        // 2. Iterate through all children to support case-insensitive, prefix/suffix, or metadata keys
        for (DataSnapshot child : rootSnapshot.getChildren()) {
            String childKey = child.getKey();
            if (childKey == null) continue;

            boolean keyMatches = matchesProviderKey(provider, childKey);
            if (!keyMatches) {
                // Check if child has metadata: provider, name, or type
                if (child.hasChild("provider")) {
                    String provVal = String.valueOf(child.child("provider").getValue());
                    keyMatches = matchesProviderKey(provider, provVal);
                }
                if (!keyMatches && child.hasChild("name")) {
                    String nameVal = String.valueOf(child.child("name").getValue());
                    keyMatches = matchesProviderKey(provider, nameVal);
                }
                if (!keyMatches && child.hasChild("type")) {
                    String typeVal = String.valueOf(child.child("type").getValue());
                    keyMatches = provider.getTypeCode().equalsIgnoreCase(typeVal);
                }
            }

            if (keyMatches) {
                ProviderSetting setting = extractSettingFromSnapshot(child);
                if (setting.isConfigured()) {
                    return child; // Match with valid number!
                }
                if (bestFallback == null) {
                    bestFallback = child;
                }
            }
        }

        return bestFallback;
    }

    /**
     * Checks if a string key matches a provider regardless of casing, underscores, or hyphens.
     */
    public static boolean matchesProviderKey(@NonNull Provider provider, @Nullable String key) {
        if (key == null) return false;
        String cleanKey = key.trim().toLowerCase().replaceAll("[^a-z0-9]", "");
        String provKey = provider.getSettingsKey().toLowerCase(); // e.g. "bkash"
        String provName = provider.getDisplayName().toLowerCase().replaceAll("[^a-z0-9]", "");

        if (cleanKey.equals(provKey) || cleanKey.equals(provName)) {
            return true;
        }

        if (cleanKey.startsWith(provKey) || cleanKey.endsWith(provKey) || cleanKey.contains(provKey)) {
            return true;
        }

        return false;
    }

    /**
     * Extracts number and enabled state from a provider DataSnapshot with maximum flexibility:
     * - Primitive value (String or Long/Double/Integer)
     * - Child fields: number, phone, mobile, account, admin_number, personal, agent, merchant, etc.
     * - Nested objects (e.g. personal: { number: "..." })
     * - Recursive deep search for phone number pattern if standard field names aren't used.
     */
    @NonNull
    private ProviderSetting extractSettingFromSnapshot(@Nullable DataSnapshot snapshot) {
        if (snapshot == null || !snapshot.exists()) {
            return new ProviderSetting("Not configured", false);
        }

        String number = null;
        Boolean enabled = null;

        // 1. Primitive value check
        Object directVal = snapshot.getValue();
        if (directVal instanceof String) {
            String s = ((String) directVal).trim();
            if (isValidNumberCandidate(s)) {
                return new ProviderSetting(s, true);
            }
        } else if (directVal instanceof Number) {
            String formatted = formatPhoneCandidate(String.valueOf(directVal));
            if (isValidNumberCandidate(formatted)) {
                return new ProviderSetting(formatted, true);
            }
        }

        // 2. Child fields check
        for (DataSnapshot child : snapshot.getChildren()) {
            String childKey = child.getKey();
            if (childKey == null) continue;
            String cleanChildKey = childKey.trim().toLowerCase().replaceAll("[^a-z0-9]", "");

            // Enabled / status field
            if (cleanChildKey.equals("enabled") || cleanChildKey.equals("active") ||
                    cleanChildKey.equals("isactive") || cleanChildKey.equals("status") ||
                    cleanChildKey.equals("state")) {
                Object val = child.getValue();
                if (val instanceof Boolean) {
                    enabled = (Boolean) val;
                } else if (val != null) {
                    String str = String.valueOf(val).trim().toLowerCase();
                    enabled = str.equals("true") || str.equals("active") || str.equals("enabled") ||
                            str.equals("1") || str.equals("on");
                }
            }

            // Number field
            if (number == null && isNumberFieldKey(cleanChildKey)) {
                if (child.hasChildren()) {
                    // Nested object like personal: { number: "017..." }
                    ProviderSetting nested = extractSettingFromSnapshot(child);
                    if (nested.isConfigured()) {
                        number = nested.getNumber();
                    }
                } else {
                    Object val = child.getValue();
                    if (val != null) {
                        String candidate = formatPhoneCandidate(String.valueOf(val).trim());
                        if (isValidNumberCandidate(candidate)) {
                            number = candidate;
                        }
                    }
                }
            }
        }

        // 3. Fallback: deep search for 11 or 12 digit phone/account number
        if (number == null) {
            number = findPhoneNumberDeep(snapshot);
        }

        if (number == null || number.trim().isEmpty() || "Not configured".equalsIgnoreCase(number.trim())) {
            return new ProviderSetting("Not configured", false);
        }

        boolean isEnabled = enabled != null ? enabled : true;
        return new ProviderSetting(number, isEnabled);
    }

    private static boolean isNumberFieldKey(@NonNull String cleanKey) {
        return cleanKey.equals("number") ||
                cleanKey.equals("phone") ||
                cleanKey.equals("mobile") ||
                cleanKey.equals("account") ||
                cleanKey.equals("accountnumber") ||
                cleanKey.equals("adminnumber") ||
                cleanKey.equals("adminphone") ||
                cleanKey.equals("personal") ||
                cleanKey.equals("agent") ||
                cleanKey.equals("merchant") ||
                cleanKey.equals("wallet") ||
                cleanKey.equals("walletnumber") ||
                cleanKey.equals("num") ||
                cleanKey.equals("no") ||
                cleanKey.equals("contact") ||
                cleanKey.equals("target") ||
                cleanKey.equals("sim") ||
                cleanKey.equals("sim1") ||
                cleanKey.equals("sim2") ||
                cleanKey.equals("value") ||
                cleanKey.equals("val") ||
                cleanKey.equals("bkash") ||
                cleanKey.equals("nagad") ||
                cleanKey.equals("rocket") ||
                cleanKey.equals("upay");
    }

    private static String formatPhoneCandidate(@Nullable String raw) {
        if (raw == null) return null;
        String clean = raw.trim();
        if (clean.isEmpty() || "Not configured".equalsIgnoreCase(clean) || "null".equalsIgnoreCase(clean)) {
            return null;
        }

        // Strip formatting characters
        String digits = clean.replaceAll("[\\s\\-\\(\\)]", "");
        if (digits.startsWith("+8801") && digits.length() >= 14) {
            return digits.substring(3);
        }
        if (digits.startsWith("8801") && digits.length() >= 13) {
            return digits.substring(2);
        }
        if (digits.startsWith("1") && digits.length() == 10) {
            return "0" + digits;
        }
        return digits;
    }

    private static boolean isValidNumberCandidate(@Nullable String val) {
        if (val == null || val.trim().isEmpty()) return false;
        String s = val.trim();
        if ("Not configured".equalsIgnoreCase(s) || "null".equalsIgnoreCase(s)) return false;
        // 11-digit BD mobile or 12-digit Rocket account or standard digits
        return s.matches("^01[3-9]\\d{8,9}$") ||
                s.matches("^\\+?8801[3-9]\\d{8,9}$") ||
                (s.length() >= 6 && s.matches(".*\\d.*"));
    }

    @Nullable
    private static String findPhoneNumberDeep(@Nullable DataSnapshot snapshot) {
        if (snapshot == null || !snapshot.exists()) return null;
        for (DataSnapshot child : snapshot.getChildren()) {
            if (child.hasChildren()) {
                String nested = findPhoneNumberDeep(child);
                if (nested != null) return nested;
            } else {
                Object val = child.getValue();
                if (val != null) {
                    String candidate = formatPhoneCandidate(String.valueOf(val).trim());
                    if (candidate != null && (candidate.matches("^01[3-9]\\d{8,9}$") || candidate.matches("^\\+?8801[3-9]\\d{8,9}$"))) {
                        return candidate;
                    }
                }
            }
        }
        return null;
    }

    private static String capitalize(@NonNull String str) {
        if (str.isEmpty()) return "";
        return Character.toUpperCase(str.charAt(0)) + str.substring(1);
    }

    private synchronized void updateProviderSetting(@NonNull Provider p, @NonNull ProviderSetting newSetting) {
        ProviderSetting oldSetting = settingsCache.get(p);

        // If newSetting is NOT configured ("Not configured"), BUT we already have a valid local number in oldSetting/prefs,
        // PRESERVE the local configured number so numbers never vanish during reconnects or initial snapshot loads!
        if (!newSetting.isConfigured() && oldSetting != null && oldSetting.isConfigured()) {
            return;
        }

        boolean changed = oldSetting == null ||
                !oldSetting.getNumber().equals(newSetting.getNumber()) ||
                oldSetting.isEnabled() != newSetting.isEnabled();

        settingsCache.put(p, newSetting);

        // Persist to local preferences
        if (newSetting.isConfigured()) {
            prefs.edit()
                    .putString(p.getSettingsKey() + "_num", newSetting.getNumber())
                    .putBoolean(p.getSettingsKey() + "_en", newSetting.isEnabled())
                    .apply();
        }

        if (changed) {
            AppLogger.log("Payment setting updated for " + p.getDisplayName() +
                    " -> Num: " + newSetting.getNumber() + " (" + (newSetting.isEnabled() ? "ENABLED" : "DISABLED") + ")");
            for (SettingsListener l : listeners) {
                try {
                    l.onSettingsChanged(p, newSetting);
                } catch (Exception e) {
                    AppLogger.error("Error notifying listener for " + p.getDisplayName(), e);
                }
            }
        }
    }
}
