package com.sms.reader.com;

import androidx.annotation.NonNull;

/**
 * Data Entity for persistent offline payment SMS queue.
 * Stores eligible payment SMS records for durable at-least-once delivery,
 * automatic server recovery, and manual retries.
 */
public class SmsSyncEntity {

    private long id;

    @NonNull
    private String idempotencyKey = "";

    @NonNull
    private String deviceId = "";

    @NonNull
    private String provider = ""; // BKASH, NAGAD, ROCKET, UPAY

    @NonNull
    private String receivingNumber = "";

    @NonNull
    private String sender = "";

    @NonNull
    private String amount = "";

    @NonNull
    private String txid = "";

    private long timestamp;

    @NonNull
    private String rawSms = "";

    @NonNull
    private String backendMode = "FIREBASE"; // FIREBASE or PHP_MYSQL

    @NonNull
    private String status = "PENDING"; // OFFLINE, SERVER_FAILED, PENDING, SYNCING, SYNCED, NEEDS_ATTENTION

    @NonNull
    private String failureReason = "";

    private int retryCount = 0;

    private long nextRetryTime = 0L;

    private long syncedTimestamp = 0L;

    @NonNull
    private String serverAckMetadata = "";

    public SmsSyncEntity() {}

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    @NonNull
    public String getIdempotencyKey() { return idempotencyKey; }
    public void setIdempotencyKey(@NonNull String idempotencyKey) { this.idempotencyKey = idempotencyKey; }

    @NonNull
    public String getDeviceId() { return deviceId; }
    public void setDeviceId(@NonNull String deviceId) { this.deviceId = deviceId; }

    @NonNull
    public String getProvider() { return provider; }
    public void setProvider(@NonNull String provider) { this.provider = provider; }

    @NonNull
    public String getReceivingNumber() { return receivingNumber; }
    public void setReceivingNumber(@NonNull String receivingNumber) { this.receivingNumber = receivingNumber; }

    @NonNull
    public String getSender() { return sender; }
    public void setSender(@NonNull String sender) { this.sender = sender; }

    @NonNull
    public String getAmount() { return amount; }
    public void setAmount(@NonNull String amount) { this.amount = amount; }

    @NonNull
    public String getTxid() { return txid; }
    public void setTxid(@NonNull String txid) { this.txid = txid; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    @NonNull
    public String getRawSms() { return rawSms; }
    public void setRawSms(@NonNull String rawSms) { this.rawSms = rawSms; }

    @NonNull
    public String getBackendMode() { return backendMode; }
    public void setBackendMode(@NonNull String backendMode) { this.backendMode = backendMode; }

    @NonNull
    public String getStatus() { return status; }
    public void setStatus(@NonNull String status) { this.status = status; }

    @NonNull
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(@NonNull String failureReason) { this.failureReason = failureReason; }

    public int getRetryCount() { return retryCount; }
    public void setRetryCount(int retryCount) { this.retryCount = retryCount; }

    public long getNextRetryTime() { return nextRetryTime; }
    public void setNextRetryTime(long nextRetryTime) { this.nextRetryTime = nextRetryTime; }

    public long getSyncedTimestamp() { return syncedTimestamp; }
    public void setSyncedTimestamp(long syncedTimestamp) { this.syncedTimestamp = syncedTimestamp; }

    @NonNull
    public String getServerAckMetadata() { return serverAckMetadata; }
    public void setServerAckMetadata(@NonNull String serverAckMetadata) { this.serverAckMetadata = serverAckMetadata; }
}
