# =============================================================================
# R8 / ProGuard Obfuscation & Security Rules
# SMS Reader Platform - Production Security Configuration
# =============================================================================

# Preserve SourceFile & LineNumberTable for crash stacktraces while obfuscating class names
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute ""

# Keep Data Models & Serialized Objects
-keep class com.sms.reader.com.PaymentData { *; }
-keep class com.sms.reader.com.Provider { *; }
-keep class com.sms.reader.com.FirebaseConfig { *; }
-keep class com.sms.reader.com.PhpConfig { *; }
-keep class com.sms.reader.com.SettingsRepository$ProviderSetting { *; }

# Keep Firebase SDK classes & annotations
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# Keep AndroidX & Material Components
-keep class androidx.appcompat.** { *; }
-keep class com.google.android.material.** { *; }

# Security: Strip Log.v and Log.d calls in Release build
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}

# Preserve Native & Keystore methods
-keepclasseswithmembernames class * {
    native <methods>;
}
