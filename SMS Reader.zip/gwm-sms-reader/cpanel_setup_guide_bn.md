# GWM SMS READER — cPanel MySQL & PHP Backend Setup Guide (বাংলা গাইড)

এই গাইড অনুসরণ করে আপনি আপনার cPanel হোস্টের সাথে **GWM SMS Reader** অ্যান্ড্রয়েড অ্যাপের **PHP MySQL API Backend Mode** সম্পূর্ণ সেটআপ করতে পারবেন।

---

### ধাপ ১: MySQL ডেটাবেস তৈরি করা (cPanel Database Setup)
1. cPanel এ লগইন করুন।
2. **Databases** সেকশনে গিয়ে **MySQL Database Wizard** অপশনে ক্লিক করুন।
3. নতুন ডেটাবেসের নাম দিন (যেমন: `gwm_sms_db`) এবং **Next Step** এ ক্লিক করুন।
4. একজন নতুন Database User তৈরি করুন (যেমন: `gwm_user`) এবং একটি স্ট্রং পাসওয়ার্ড দিন।
5. **All Privileges** অপশনে টিক দিয়ে **Make Changes** এ ক্লিক করুন।

---

### ধাপ ২: SQL স্কিমা ইম্পোর্ট করা (phpMyAdmin Import)
1. cPanel হোম থেকে **phpMyAdmin** অপশনে ক্লিক করুন।
2. বাঁপাশের তালিকা থেকে সদ্য তৈরি করা ডেটাবেসটি নির্বাচন করুন।
3. ওপরের মেনু থেকে **Import** বাটনে ক্লিক করুন।
4. **Choose File** এ ক্লিক করে প্রজেক্টের **`gwm_sms_reader_mysql.sql`** ফাইলটি সিলেক্ট করুন।
5. একদম নিচে গিয়ে **Go** বাটনে ক্লিক করুন। সফলভাবে সব টেবল ইম্পোর্ট হবে।

---

### ধাপ ৩: PHP API ফাইল আপলোড করা (File Manager Upload)
1. cPanel থেকে **File Manager** ওপেন করুন।
2. `public_html` অথবা যেকোনো সাবডোমেইন ফোল্ডারে (যেমন: `public_html/api/` বা `api.yourdomain.com`) যান।
3. প্রজেক্টের **`php_backend`** ফোল্ডারের ফাইলগুলো জিওপি/আপলোড করুন।

---

### ধাপ ৪: ডেটাবেস কানেকশন কনফিগার করা (`db_config.php`)
1. `db_config.php` ফাইলটি Edit করুন।
2. নিচের লাইনগুলোতে আপনার cPanel ডেটাবেস তথ্য বসিয়ে Save করুন:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'yourcpanel_gwm_sms_db');
define('DB_USER', 'yourcpanel_gwm_user');
define('DB_PASS', 'YourStrongPassword123!');

define('MASTER_DEVICE_SECRET', 'GWM_READER_SECRET_KEY_2025');
```

---

### ধাপ ৫: অ্যান্ড্রয়েড অ্যাপে PHP Mode সক্রিয় করা
1. আপনার ফোনে **GWM SMS Reader** অ্যাপটি চালু করুন।
2. ওপরের ডানপাশের **PHP/API আইকন** (Upload Icon) এ ক্লিক করুন।
3. **PHP API Base URL** এর ঘরে আপনার API লিঙ্কটি দিন:
   `https://yourdomain.com/api/`
4. **Device Pairing Key / Secret** এর ঘরে আপনার `MASTER_DEVICE_SECRET` (যেমন: `GWM_READER_SECRET_KEY_2025`) দিন।
5. **TEST & ACTIVATE PHP MYSQL MODE** বাটনে ক্লিক করুন।
6. কানেকশন ভেরিফাইড হলে অ্যাপটি সাকসেস মেসেজ দেখাবে এবং সমস্ত পেমেন্ট সরাসরি আপনার MySQL ডেটাবেসে জমা হতে থাকবে।

---

### ধাপ ৬: ওয়েবসাইটের সাথে অটো পেমেন্ট সেটেলমেন্ট বা কাস্টমার ক্রেডিট টেস্ট করা
1. টেস্ট পেমেন্ট মেসেজ রিসিভ হলে অ্যাপটি অটোমেটিক `payment_receiver.php` এন্ডপয়েন্টে ডেটা পাঠাবে।
2. আপনার ওয়েবসাইট বা প্যানেল `payment_status.php?txid=DJ118THL8D` এন্ডপয়েন্ট কল করে TrxID, Amount, Status চেক করে কাস্টমারের ওয়ালেট বা অর্ডার অটোমেটিক ক্রেডিট করে নিতে পারবে।
3. কোনো কারণে Firebase এ ব্যাক করতে চাইলে অ্যাপের PHP Config ডায়ালগ থেকে **"SWITCH BACK TO FIREBASE MODE"** বাটনে ক্লিক করলে নিমিষেই Firebase Mode এ ফিরে যাবে।

---

## 🛡️ Imunify360 / Bot Protection ব্লক হলে কী করবেন

অ্যাপ এখন API রিকোয়েস্ট একটি হিডেন Chromium WebView দিয়ে পাঠায় এবং ব্লক হলে SMS কিউতে রেখে ব্যাকঅফ দিয়ে আবার চেষ্টা করে। তবুও কোনো হোস্টিং-এর ফায়ারওয়াল শক্ত হলে নিচের যেকোনো একটি করুন:

1. **হোস্টিং সাপোর্টকে লিখুন:** "Please whitelist the URI path `/api/` (payment_receiver.php, connection_test.php) in Imunify360 / ModSecurity for all IPs. It is called by my Android app, not a browser."
2. **Cloudflare (ফ্রি):** ডোমেইন Cloudflare-এ রেখে WAF → Custom rules → `URI Path contains /api/` → Action: **Skip** (Bot Fight Mode সহ)।
3. **অ্যাপ থেকে:** PHP MySQL ট্যাবে **VERIFY & UNBLOCK SERVER FIREWALL** চাপুন। `connection_test.php` লোড হবে, ক্যাপচা এলে সলভ করুন; সার্ভারের JSON উত্তর পেলে উইন্ডো নিজে বন্ধ হবে। (IP বদলালে আবার করতে হতে পারে — তাই স্থায়ী সমাধান ১ বা ২।)

**গুরুত্বপূর্ণ:** `api/` ফোল্ডারে `connection_test.php` অবশ্যই আপলোড থাকতে হবে। ব্রাউজারে শুধু `/api/` খুললে 404 আসা স্বাভাবিক।
