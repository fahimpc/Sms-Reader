-- =============================================================================
-- GWM SMS READER — PRODUCTION MYSQL DATABASE SCHEMA
-- Compatible with MySQL 8.0+, MariaDB 10.3+, and cPanel Shared Hosting
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET TIME_ZONE = "+06:00";

-- -----------------------------------------------------------------------------
-- 1. TABLE: devices
-- Stores registered Android SMS Reader devices
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `devices` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `device_id` VARCHAR(64) NOT NULL,
  `device_name` VARCHAR(128) DEFAULT 'Android Reader Device',
  `app_version` VARCHAR(32) DEFAULT '1.0',
  `status` ENUM('ACTIVE', 'PENDING', 'SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_active_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id` (`device_id`),
  KEY `idx_device_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. TABLE: device_credentials
-- Stores per-device authentication secrets/tokens
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `device_credentials` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `device_id` VARCHAR(64) NOT NULL,
  `device_secret_hash` VARCHAR(255) NOT NULL,
  `token_issued_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME DEFAULT NULL,
  `is_revoked` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cred_device_id` (`device_id`),
  CONSTRAINT `fk_cred_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. TABLE: sms_payment_events
-- Raw payment SMS events uploaded by Android devices
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sms_payment_events` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_event_id` VARCHAR(128) NOT NULL,
  `device_id` VARCHAR(64) NOT NULL,
  `provider` VARCHAR(32) NOT NULL,
  `provider_code` VARCHAR(32) NOT NULL,
  `sender` VARCHAR(32) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `txid` VARCHAR(64) NOT NULL,
  `received_account` VARCHAR(32) DEFAULT NULL,
  `raw_sms` TEXT DEFAULT NULL,
  `sms_timestamp` BIGINT UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_client_event_id` (`client_event_id`),
  KEY `idx_event_txid_provider` (`provider_code`, `txid`),
  KEY `idx_event_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. TABLE: payment_transactions
-- Authoritative, deduplicated payment transaction records for automatic settlement
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `provider` VARCHAR(32) NOT NULL,
  `provider_code` VARCHAR(32) NOT NULL,
  `txid` VARCHAR(64) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `sender_number` VARCHAR(32) DEFAULT NULL,
  `received_account` VARCHAR(32) DEFAULT NULL,
  `device_id` VARCHAR(64) NOT NULL,
  `status` ENUM('PENDING', 'USED', 'EXPIRED', 'FAILED') NOT NULL DEFAULT 'PENDING',
  `used_by` VARCHAR(128) DEFAULT NULL,
  `used_at` DATETIME DEFAULT NULL,
  `received_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_txid` (`provider_code`, `txid`),
  KEY `idx_txid` (`txid`),
  KEY `idx_status` (`status`),
  KEY `idx_received_at` (`received_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. TABLE: payment_processing_logs
-- Detailed audit trail of all payment processing steps
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payment_processing_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `txid` VARCHAR(64) NOT NULL,
  `provider` VARCHAR(32) NOT NULL,
  `action` VARCHAR(64) NOT NULL,
  `message` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_txid` (`txid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 6. TABLE: idempotency_records
-- Replay protection for Android uploads
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `idempotency_records` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `idempotency_key` VARCHAR(128) NOT NULL,
  `request_hash` VARCHAR(64) NOT NULL,
  `response_body` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_idempotency_key` (`idempotency_key`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 7. TABLE: security_audit_logs
-- Security logging for authentication failures, IP rate limiting, and attacks
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `security_audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_type` VARCHAR(64) NOT NULL,
  `device_id` VARCHAR(64) DEFAULT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sec_event` (`event_type`),
  KEY `idx_sec_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
