# Firewall / Imunify360 fix (changes in this build)

- NEW PhpWebTransport.java: API POST now goes through a hidden real Chromium WebView (fetch), sharing cookies via CookieManager.
- PhpWriter.java: WebView first; if the firewall blocks, fail fast (no hammering; existing SmsSyncManager backoff 15s/45s/2m/5m + SQLite queue keeps the SMS). If WebView fails for another reason, HttpURLConnection fallback now sends the saved Cookie header (it never did before) and the WebView's real User-Agent (fake Chrome UA removed).
- PhpBypassWebViewDialog.java: loads connection_test.php (the bare /api/ folder gave 404), closes itself when the API's JSON arrives, reports 404 clearly, has a DONE button, no fake User-Agent.
- php_backend/db_config.php: getJsonInput() now decodes the app's {"b64": ...} wrapper (plain JSON still works).
- cpanel_setup_guide_bn.md: firewall section added.

NOT changed: duplicate secret fields in the payload (server side unknown), Firebase<->PHP automatic fallback (BackendManager clears the other mode's config on switch).
Not compiled or run: build in Android Studio and test on the shop WiFi.
